"""
modules/correlation.py
Bivariate Correlation engine — Inferential Statistics by MA.
Per-pair recommendation: normality + linearity + outlier + stability.
Returns bivariate_assumptions, rich pairwise table, basis text per pair.
"""
import numpy as np
import pandas as pd
from itertools import combinations
from scipy import stats as scipy_stats

try:
    from modules.normality import test_normality
except Exception:
    test_normality = None

try:
    from modules.nonparametric import spearman_correlation, kendall_tau_correlation
except Exception:
    spearman_correlation = None
    kendall_tau_correlation = None


# ── helpers ───────────────────────────────────────────────────────────────────

def _strength_label(r):
    a = abs(r) if r is not None and not np.isnan(r) else 0
    if a < 0.10: return "negligible"
    if a < 0.30: return "weak"
    if a < 0.50: return "moderate"
    if a < 0.70: return "strong"
    return "very strong"

def _direction_label(r):
    if r is None or np.isnan(r): return "no"
    return "positive" if r > 0 else "negative" if r < 0 else "no"

def _sig_stars(p):
    if p is None or np.isnan(p): return ""
    return "***" if p < .001 else "**" if p < .01 else "*" if p < .05 else "n.s."

def _fisher_ci(r, n, alpha=0.05, se_factor=1.0):
    if n < 4 or r is None or np.isnan(r):
        return np.nan, np.nan, np.nan
    r  = max(min(float(r), 0.9999), -0.9999)
    z  = np.arctanh(r)
    se = se_factor / np.sqrt(n - 3)
    zc = scipy_stats.norm.ppf(1 - alpha / 2)
    return float(np.tanh(z - zc * se)), float(np.tanh(z + zc * se)), float(se)

def _bootstrap_ci(x, y, fn, n_boot=2000, alpha=0.05, seed=42):
    rng = np.random.default_rng(seed)
    n   = len(x)
    if n < 4: return np.nan, np.nan
    vals = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        try:
            v = fn(x[idx], y[idx])
            if v is not None and not np.isnan(v): vals.append(v)
        except Exception: pass
    if len(vals) < 20: return np.nan, np.nan
    return float(np.percentile(vals, 100*alpha/2)), float(np.percentile(vals, 100*(1-alpha/2)))

def _linear_ok(x, y):
    try:
        n = len(x)
        if n < 5: return True
        ss = np.sum((y - y.mean())**2)
        if ss == 0: return True
        b1 = np.polyfit(x, y, 1)
        r1 = 1 - np.sum((y - np.polyval(b1, x))**2) / ss
        b2 = np.polyfit(x, y, 2)
        r2 = 1 - np.sum((y - np.polyval(b2, x))**2) / ss
        return (r2 - r1) < 0.04
    except Exception:
        return True

def _outlier_check(x, y):
    try:
        data = np.column_stack([x, y]).astype(float)
        cov  = np.cov(data.T)
        if np.linalg.matrix_rank(cov) < 2 or abs(np.linalg.det(cov)) < 1e-12:
            return False, 0
        inv  = np.linalg.inv(cov)
        d    = data - data.mean(axis=0)
        mah  = np.einsum("ij,jk,ik->i", d, inv, d)
        thr  = scipy_stats.chi2.ppf(0.999, df=2)
        n    = int(np.sum(mah > thr))
        return n > 0, n
    except Exception:
        return False, 0

def _all_coeffs(x, y, alpha=0.05):
    out = {}
    try:
        r, p = scipy_stats.pearsonr(x, y)
        out["pearson"] = (float(r), float(p))
    except Exception:
        out["pearson"] = (np.nan, np.nan)

    if spearman_correlation is not None:
        try:
            s = spearman_correlation(x, y, alpha=alpha)
            out["spearman"]     = (s["coefficient"], s["p_value"])
            out["_spearman_ci"] = (s.get("ci_lower", np.nan), s.get("ci_upper", np.nan))
            out["_spearman_se"] = s.get("se", np.nan)
        except Exception:
            out["spearman"] = (np.nan, np.nan)
            out["_spearman_ci"] = (np.nan, np.nan)
            out["_spearman_se"] = np.nan
    else:
        try:
            rho, p = scipy_stats.spearmanr(x, y)
            out["spearman"] = (float(rho), float(p))
        except Exception:
            out["spearman"] = (np.nan, np.nan)
        rho_v = out["spearman"][0]
        n     = len(x)
        if not np.isnan(rho_v) and n > 3:
            lo, hi, se = _fisher_ci(rho_v, n, alpha, se_factor=1.03)
            out["_spearman_ci"] = (lo, hi)
            out["_spearman_se"] = se
        else:
            out["_spearman_ci"] = (np.nan, np.nan)
            out["_spearman_se"] = np.nan

    try:
        tau, p = scipy_stats.kendalltau(x, y, variant="b")
        out["kendall"] = (float(tau), float(p))
    except Exception:
        out["kendall"] = (np.nan, np.nan)

    return out

def _kendall_ci(x, y, alpha=0.05, n_boot=2000):
    if kendall_tau_correlation is not None:
        try:
            k = kendall_tau_correlation(x, y, alpha=alpha, n_boot=n_boot)
            return k["ci_lower"], k["ci_upper"]
        except Exception:
            pass
    return _bootstrap_ci(
        x, y, lambda a, b: scipy_stats.kendalltau(a, b, variant="b")[0],
        n_boot=n_boot, alpha=alpha)

def _kendall_se(N):
    if N < 2: return np.nan
    return float(np.sqrt(2*(2*N+5) / (9*N*(N-1))))

def _fallback_normality(col, name, N):
    col = np.asarray(col, dtype=float); n = len(col)
    try:   sw_W, sw_p = scipy_stats.shapiro(col)
    except Exception: sw_W, sw_p = np.nan, np.nan
    try:
        z = (col - col.mean()) / max(col.std(ddof=1), 1e-12)
        ks_D, ks_p = scipy_stats.kstest(z, "norm")
    except Exception: ks_D, ks_p = np.nan, np.nan
    if N < 50:
        plabel = "Shapiro-Wilk"
        passed = not np.isnan(sw_p) and sw_p > 0.05
    else:
        plabel = "Kolmogorov-Smirnov"
        passed = not np.isnan(ks_p) and ks_p >= 0.05
    return {"label": name, "n": n, "total_n": N,
            "sw_W": float(sw_W) if not np.isnan(sw_W) else np.nan,
            "sw_p": float(sw_p) if not np.isnan(sw_p) else np.nan,
            "ks_D": float(ks_D) if not np.isnan(ks_D) else np.nan,
            "ks_p": float(ks_p) if not np.isnan(ks_p) else np.nan,
            "primary_label": plabel, "pass": passed}

def _descriptives(matrix, var_names, alpha=0.05):
    pct  = int((1-alpha)*100)
    rows = []
    for j, name in enumerate(var_names):
        d = matrix[:, j]; n = len(d)
        m  = float(np.mean(d))
        sd = float(np.std(d, ddof=1)) if n > 1 else np.nan
        se = float(scipy_stats.sem(d))  if n > 1 else np.nan
        tc = scipy_stats.t.ppf(1-alpha/2, n-1) if n > 1 else np.nan
        ci_l = m - tc*se if not np.isnan(se) else np.nan
        ci_u = m + tc*se if not np.isnan(se) else np.nan
        skew = float(scipy_stats.skew(d, bias=False))     if n > 2 else np.nan
        kurt = float(scipy_stats.kurtosis(d, bias=False)) if n > 3 else np.nan
        se_sk = float(np.sqrt(6*n*(n-1)/((n-2)*(n+1)*(n+3)))) if n > 3 else np.nan
        se_ku = float(2*se_sk*np.sqrt((n*n-1)/((n-3)*(n+5)))) if n > 4 and not np.isnan(se_sk) else np.nan
        rows.append({"Variable": name, "N": n,
            "Mean": round(m,3), "Median": round(float(np.median(d)),3),
            "Std. Deviation": round(sd,3) if not np.isnan(sd) else np.nan,
            "Std. Error Mean": round(se,3) if not np.isnan(se) else np.nan,
            f"{pct}% CI Lower": round(ci_l,3) if not np.isnan(ci_l) else np.nan,
            f"{pct}% CI Upper": round(ci_u,3) if not np.isnan(ci_u) else np.nan,
            "Variance": round(float(np.var(d,ddof=1)),3) if n>1 else np.nan,
            "Minimum": round(float(np.min(d)),3), "Maximum": round(float(np.max(d)),3),
            "Range": round(float(np.max(d)-np.min(d)),3),
            "Skewness": round(skew,3) if not np.isnan(skew) else np.nan,
            "Std. Error of Skewness": round(se_sk,3) if not np.isnan(se_sk) else np.nan,
            "Kurtosis": round(kurt,3) if not np.isnan(kurt) else np.nan,
            "Std. Error of Kurtosis": round(se_ku,3) if not np.isnan(se_ku) else np.nan})
    return pd.DataFrame(rows)

def _basis_text(v1, v2, normal_pair, normal_v1, normal_v2,
                linear, has_out, n_out, N, n_ties, rec):
    lines = []
    if normal_pair:
        lines.append(f"Both {v1} and {v2} satisfy the normality assumption (p > .05).")
    elif normal_v1 and not normal_v2:
        lines.append(f"{v2} violates the normality assumption (p ≤ .05), requiring a rank-based coefficient.")
    elif normal_v2 and not normal_v1:
        lines.append(f"{v1} violates the normality assumption (p ≤ .05), requiring a rank-based coefficient.")
    else:
        lines.append(f"Both {v1} and {v2} violate the normality assumption (p ≤ .05 for both).")
    if linear:
        lines.append("The bivariate relationship is approximately linear (quadratic R² improvement < 0.04).")
    else:
        lines.append("The bivariate relationship is non-linear (quadratic R² improvement ≥ 0.04), as visible in the scatterplot; a monotonic rank-based coefficient is more appropriate.")
    if has_out:
        lines.append(f"{n_out} bivariate outlier(s) detected via Mahalanobis distance (χ², df=2, p < .001), which can distort Pearson r; rank-based coefficients are more robust.")
    else:
        lines.append("No bivariate outliers detected (Mahalanobis, χ², df=2, p > .001).")
    if rec == "kendall":
        if N < 20:
            lines.append(f"Small sample (N={N}): Kendall's τ₂ is preferred over Spearman's ρ for more stable estimation.")
        if n_ties > N * 0.5:
            lines.append(f"Many tied ranks ({n_ties} ties): Kendall's τ₂ correction for ties makes it more appropriate than Spearman's ρ.")
    rec_full = {"pearson": "Pearson r", "spearman": "Spearman ρ", "kendall": "Kendall's τ₂"}[rec]
    lines.append(f"Conclusion: {rec_full} is recommended for this pair.")
    return " ".join(lines)


# ── main ──────────────────────────────────────────────────────────────────────

def run_correlation(matrix, var_names, alpha=0.05, forced_method=None, n_boot=2000):
    matrix    = np.asarray(matrix, dtype=float)
    matrix    = matrix[~np.isnan(matrix).any(axis=1)]
    N, p      = matrix.shape
    var_names = list(var_names)
    methods   = ["pearson", "spearman", "kendall"]
    pct       = int((1-alpha)*100)

    # normality
    normality = {}
    for j, name in enumerate(var_names):
        col = matrix[:, j]
        if test_normality is not None:
            try:   normality[name] = test_normality(col, label=name, total_n=N)
            except Exception: normality[name] = _fallback_normality(col, name, N)
        else:
            normality[name] = _fallback_normality(col, name, N)
    all_normal = all(normality[v].get("pass", False) for v in var_names)

    descriptives = _descriptives(matrix, var_names, alpha)

    coef_mat = {m: np.full((p,p), np.nan) for m in methods}
    pval_mat = {m: np.full((p,p), np.nan) for m in methods}
    for i in range(p):
        for m in methods:
            coef_mat[m][i,i] = 1.0
            pval_mat[m][i,i] = 0.0

    pair_rows    = []
    interp_pairs = []   # per-pair method
    interp_overall = [] # overall method (consistent across all pairs)
    bva_list     = []
    methods_used = set()

    for i, jx in combinations(range(p), 2):
        x = matrix[:, i]; y = matrix[:, jx]
        v1 = var_names[i]; v2 = var_names[jx]
        coeffs = _all_coeffs(x, y, alpha=alpha)
        for m in methods:
            r, pv = coeffs[m]
            coef_mat[m][i,jx] = coef_mat[m][jx,i] = r
            pval_mat[m][i,jx] = pval_mat[m][jx,i] = pv

        normal_v1   = normality[v1].get("pass", False)
        normal_v2   = normality[v2].get("pass", False)
        normal_pair = normal_v1 and normal_v2
        linear      = _linear_ok(x, y)
        has_out, n_out = _outlier_check(x, y)
        n_ties      = (len(x)-len(np.unique(x))) + (len(y)-len(np.unique(y)))

        # per-pair recommendation
        if forced_method in methods:
            rec = forced_method
        elif normal_pair and linear and not has_out:
            rec = "pearson"
        elif normal_pair and linear and has_out:
            rec = "spearman"
        elif not linear and normal_pair:
            rec = "spearman"
        else:
            rec = "kendall" if (N < 20 or n_ties > N*0.5) else "spearman"
        methods_used.add(rec)

        # CI for recommended
        r_rec, p_rec = coeffs[rec]
        if rec == "pearson":
            ci_lo, ci_hi, se_rec = _fisher_ci(r_rec, N, alpha, 1.0)
        elif rec == "spearman":
            ci_lo, ci_hi = coeffs.get("_spearman_ci", (np.nan, np.nan))
            se_rec        = coeffs.get("_spearman_se", np.nan)
        else:
            ci_lo, ci_hi = _kendall_ci(x, y, alpha=alpha, n_boot=n_boot)
            se_rec        = _kendall_se(N)

        # CIs for all 3 (display)
        r_p, p_p = coeffs["pearson"]
        r_s, p_s = coeffs["spearman"]
        r_k, p_k = coeffs["kendall"]
        ci_p_lo, ci_p_hi, se_p = _fisher_ci(r_p, N, alpha, 1.0)
        ci_s_lo, ci_s_hi        = coeffs.get("_spearman_ci", (np.nan, np.nan))
        se_s                    = coeffs.get("_spearman_se", np.nan)
        se_k                    = _kendall_se(N)

        rec_label = {"pearson": "Pearson r", "spearman": "Spearman ρ",
                     "kendall": "Kendall τ₂"}[rec]
        sig = not np.isnan(p_rec) and p_rec < alpha

        basis = _basis_text(v1, v2, normal_pair, normal_v1, normal_v2,
                            linear, has_out, n_out, N, n_ties, rec)

        pair_rows.append({
            "Variable 1":   v1, "Variable 2": v2,
            "Recommended":  rec_label,
            "r (rec)":      round(r_rec,  3) if not np.isnan(r_rec)  else np.nan,
            "SE (rec)":     round(se_rec, 4) if not np.isnan(se_rec) else np.nan,
            f"{pct}% CI Lower": round(ci_lo, 3) if not np.isnan(ci_lo) else np.nan,
            f"{pct}% CI Upper": round(ci_hi, 3) if not np.isnan(ci_hi) else np.nan,
            "p (2-tailed)": round(p_rec,  4) if not np.isnan(p_rec)  else np.nan,
            "Sig.":         _sig_stars(p_rec),
            "Normal?":      "✓" if normal_pair else "✗",
            "Linear?":      "✓" if linear      else "✗",
            "Outliers?":    f"⚠ {n_out}" if has_out else "✓",
            "Pearson r":    round(r_p, 3) if not np.isnan(r_p) else np.nan,
            "SE (Pearson)": round(se_p, 4) if not np.isnan(se_p) else np.nan,
            f"CI {pct}% [Pearson]": (f"[{ci_p_lo:.3f}, {ci_p_hi:.3f}]"
                                      if not np.isnan(ci_p_lo) else "—"),
            "p (Pearson)":  round(p_p, 4) if not np.isnan(p_p) else np.nan,
            "Spearman ρ":   round(r_s, 3) if not np.isnan(r_s) else np.nan,
            "SE (Spearman)":round(se_s, 4) if not np.isnan(se_s) else np.nan,
            f"CI {pct}% [Spearman]": (f"[{ci_s_lo:.3f}, {ci_s_hi:.3f}]"
                                       if not np.isnan(ci_s_lo) else "—"),
            "p (Spearman)": round(p_s, 4) if not np.isnan(p_s) else np.nan,
            "Kendall τ₂":   round(r_k, 3) if not np.isnan(r_k) else np.nan,
            "SE (Kendall)": round(se_k, 4) if not np.isnan(se_k) else np.nan,
            "p (Kendall)":  round(p_k, 4) if not np.isnan(p_k) else np.nan,
            "N":            N,
            "_basis":       basis,
            "_normal":      normal_pair,
            "_linear":      linear,
            "_outlier":     has_out,
            "_n_out":       n_out,
        })

        # interpretation text helper
        def _make_text(r_val, p_val, method_lbl, ci_l, ci_h, is_pearson):
            strength  = _strength_label(r_val)
            direction = _direction_label(r_val)
            s_flag    = not np.isnan(p_val) and p_val < alpha
            if s_flag:
                p_str  = "< .001" if p_val < .001 else f"= {p_val:.3f}"
                s_txt  = f"statistically significant (p {p_str})"
            else:
                s_txt  = f"not statistically significant (p = {p_val:.3f})"
            ci_txt = ""
            if not np.isnan(ci_l) and not np.isnan(ci_h):
                excl   = ci_l > 0 or ci_h < 0
                ci_txt = (f" The {pct}% CI [{ci_l:.3f}, {ci_h:.3f}] "
                          f"{'excludes' if excl else 'includes'} zero.")
            r2_txt = (f" Approximately {r_val**2*100:.1f}% of the variance is "
                      f"shared (r² = {r_val**2:.3f})." if is_pearson else "")
            return (f"There is a {strength} {direction} correlation between "
                    f"<b>{v1}</b> and <b>{v2}</b> "
                    f"({method_lbl} = {r_val:.3f}), which is {s_txt}."
                    + ci_txt + r2_txt)

        # Model 1: per-pair recommended
        interp_pairs.append({
            "pair":    f"{v1} – {v2}",
            "method":  rec_label,
            "r":       r_rec,
            "sig":     sig,
            "normal":  normal_pair,
            "linear":  linear,
            "outlier": has_out,
            "n_out":   n_out,
            "basis":   basis,
            "text":    _make_text(r_rec, p_rec, rec_label, ci_lo, ci_hi,
                                  rec == "pearson"),
        })

        bva_list.append({
            "pair":        f"{v1} – {v2}",
            "normal":      normal_pair,
            "normal_v1":   normal_v1,
            "normal_v2":   normal_v2,
            "linear":      linear,
            "outlier":     has_out,
            "n_outliers":  n_out,
            "recommended": rec_label,
            "basis":       basis,
        })

    pairwise_df = pd.DataFrame(pair_rows)

    # Overall method (majority vote)
    if forced_method in methods:
        overall_method = forced_method
    elif pair_rows:
        from collections import Counter
        _rev = {"Pearson r": "pearson", "Spearman ρ": "spearman", "Kendall τ₂": "kendall"}
        overall_method = _rev.get(
            Counter(r["Recommended"] for r in pair_rows).most_common(1)[0][0], "pearson")
    elif all_normal:
        overall_method = "pearson"
    else:
        overall_method = "spearman"

    # Model 2: overall method — consistent single method for ALL pairs
    ovr_label = {"pearson": "Pearson r", "spearman": "Spearman ρ",
                 "kendall": "Kendall τ₂"}[overall_method]
    for row in pair_rows:
        v1o = row["Variable 1"]; v2o = row["Variable 2"]
        x = matrix[:, var_names.index(v1o)]
        y = matrix[:, var_names.index(v2o)]
        coeffs_o = _all_coeffs(x, y, alpha=alpha)
        r_o, p_o = coeffs_o[overall_method]
        if overall_method == "pearson":
            ci_lo_o, ci_hi_o, _ = _fisher_ci(r_o, N, alpha, 1.0)
        elif overall_method == "spearman":
            ci_lo_o, ci_hi_o = coeffs_o.get("_spearman_ci", (np.nan, np.nan))
        else:
            ci_lo_o, ci_hi_o = _kendall_ci(x, y, alpha=alpha, n_boot=n_boot)
        sig_o = not np.isnan(p_o) and p_o < alpha
        strength_o  = _strength_label(r_o)
        direction_o = _direction_label(r_o)
        if sig_o:
            p_str_o = "< .001" if p_o < .001 else f"= {p_o:.3f}"
            s_txt_o = f"statistically significant (p {p_str_o})"
        else:
            s_txt_o = f"not statistically significant (p = {p_o:.3f})"
        ci_txt_o = ""
        if not np.isnan(ci_lo_o) and not np.isnan(ci_hi_o):
            excl_o   = ci_lo_o > 0 or ci_hi_o < 0
            ci_txt_o = (f" The {pct}% CI [{ci_lo_o:.3f}, {ci_hi_o:.3f}] "
                        f"{'excludes' if excl_o else 'includes'} zero.")
        r2_txt_o = (f" Approximately {r_o**2*100:.1f}% of the variance is "
                    f"shared (r² = {r_o**2:.3f})."
                    if overall_method == "pearson" else "")
        interp_overall.append({
            "pair":   f"{v1o} – {v2o}",
            "method": ovr_label,
            "r":      r_o,
            "sig":    sig_o,
            "text": (f"There is a {strength_o} {direction_o} correlation between "
                     f"<b>{v1o}</b> and <b>{v2o}</b> "
                     f"({ovr_label} = {r_o:.3f}), which is {s_txt_o}."
                     + ci_txt_o + r2_txt_o),
        })

    # matrices
    def _mat_df(arr):
        return pd.DataFrame(np.round(arr, 3), index=var_names, columns=var_names)
    coef_dfs = {m: _mat_df(coef_mat[m]) for m in methods}
    pval_dfs = {m: _mat_df(pval_mat[m]) for m in methods}

    cov     = np.cov(matrix, rowvar=False, ddof=1)
    cov_df  = pd.DataFrame(np.round(cov,       3), index=var_names, columns=var_names)
    sscp_df = pd.DataFrame(np.round(cov*(N-1), 3), index=var_names, columns=var_names)

    # rationale
    nonnormal = [v for v in var_names if not normality[v].get("pass", False)]
    if forced_method in methods:
        rationale = f"Coefficient manually overridden to {ovr_label}."
    elif all_normal:
        rationale = ("All variables satisfy the normality assumption (p > .05). "
                     "<b>Pearson r</b> is recommended for pairs that also exhibit "
                     "linear relationships without bivariate outliers. "
                     "See the Bivariate Assumption Checks for pair-specific details.")
    else:
        rationale = ("Normality violated for: "
                     + ", ".join(f"<b>{v}</b>" for v in nonnormal)
                     + ". A rank-based coefficient is recommended for affected pairs. "
                     "See the Bivariate Assumption Checks for pair-specific details.")

    return {
        "type": "Bivariate Correlation",
        "n": N, "p": p, "alpha": alpha,
        "var_names":    var_names,
        "descriptives": descriptives,
        "normality":    normality,
        "all_normal":   all_normal,
        "pairwise":     pairwise_df,
        "coef_pearson":  coef_dfs["pearson"],
        "coef_spearman": coef_dfs["spearman"],
        "coef_kendall":  coef_dfs["kendall"],
        "p_pearson":     pval_dfs["pearson"],
        "p_spearman":    pval_dfs["spearman"],
        "p_kendall":     pval_dfs["kendall"],
        "p1_pearson":    pval_dfs["pearson"]  / 2,
        "p1_spearman":   pval_dfs["spearman"] / 2,
        "p1_kendall":    pval_dfs["kendall"]  / 2,
        "covariance":    cov_df,
        "sscp":          sscp_df,
        "recommended_method":  overall_method,
        "overall_method":      overall_method,
        "rationale":           rationale,
        "interpretations":     interp_pairs,    # per-pair method
        "interpretations_overall": interp_overall,  # consistent single method
        "bivariate_assumptions":   bva_list,
        "matrix_data":   matrix,
        "forced_method": forced_method,
        "n_boot":        n_boot,
        "kendall_used":  "kendall" in methods_used,
        "methods_used":  sorted(methods_used),
        "bootstrap_seed": 42,
    }
