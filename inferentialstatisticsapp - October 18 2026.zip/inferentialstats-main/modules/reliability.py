"""
modules/reliability.py
======================
Reliability analysis engine for "Inferential Statistics by MA".

Computes internal-consistency reliability for one or more constructs (item
sets) defined within a single uploaded file. For each construct it returns
publication-grade output with extended diagnostics, automatic descriptive
interpretation, and full methodological transparency.

Coefficients
------------
  - Cronbach's alpha (+ 95% CI, + standardised alpha)
  - Cronbach's alpha if item deleted, corrected item-total correlation,
    squared multiple correlation, scale mean/variance if item deleted
  - KR-20 (Kuder-Richardson) for dichotomous items (auto-detected)
  - Split-half: Spearman-Brown (equal length) and Guttman split-half
  - Guttman's lambda lambda1 .. lambda6
  - Intraclass Correlation Coefficient (ICC1, ICC2, ICC3, single & average)
  - Inter-item correlation / covariance matrices, average inter-item r
  - McDonald's omega (single-factor congeneric model)
  - Scale descriptive statistics

Reverse-item handling
---------------------
  Items with a negative corrected item-total correlation are flagged. Optional
  reversal (off by default) supports three transparent methods:
    theoretical : new = (scale_min + scale_max) - x
    observed    : new = (min_observed + max_observed) - x
    zscore      : new = -zscore(x)

References
----------
  Cronbach (1951); Kuder & Richardson (1937); Guttman (1945);
  McDonald (1999); Shrout & Fleiss (1979); Field (2018); Cortina (1993).
"""

import itertools
import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

try:
    import pingouin as pg
except Exception:
    pg = None

try:
    from sklearn.metrics import cohen_kappa_score as _skl_kappa
    _SKL = True
except Exception:
    _SKL = False


# ══════════════════════════════════════════════════════════════════════════════
# KAPPA HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def kappa_label(k):
    """Landis & Koch (1977) inter-rater agreement benchmarks."""
    if k is None or (isinstance(k, float) and np.isnan(k)):
        return "N/A"
    k = float(k)
    if k < 0:    return "Poor (< 0: worse than chance)"
    if k < 0.20: return "Slight (0.00–0.20)"
    if k < 0.40: return "Fair (0.21–0.40)"
    if k < 0.60: return "Moderate (0.41–0.60)"
    if k < 0.80: return "Substantial (0.61–0.80)"
    return "Almost Perfect (0.81–1.00)"


def krippendorff_label(a):
    """Krippendorff (2004) reliability benchmarks."""
    if a is None or (isinstance(a, float) and np.isnan(a)):
        return "N/A"
    a = float(a)
    if a < 0:    return "No agreement (< 0)"
    if a < 0.20: return "Slight (0.00–0.20)"
    if a < 0.40: return "Fair (0.21–0.40)"
    if a < 0.60: return "Moderate (0.41–0.60)"
    if a < 0.667: return "Tentative (0.61–0.67, below acceptable threshold)"
    if a < 0.80: return "Acceptable (0.667–0.80)"
    return "Strong (≥ 0.80)"


def _detect_data_type(vals):
    """Classify ratings as 'dichotomous', 'nominal', 'ordinal', or 'interval'.
    
    Decision rules:
    - Exactly 2 unique values → dichotomous
    - Non-integer or many unique values → interval
    - Integer-valued AND sequential AND min >= 1 AND n_unique 3–10 → ordinal
      (Likert-style: 1,2,3,4,5 or 1,2,3)
    - Integer-valued AND (min == 0 OR non-sequential OR n_unique > 10) → nominal
    - String/non-numeric → nominal
    """
    clean = [v for v in vals if v is not None and not (isinstance(v, float) and np.isnan(v))]
    if not clean:
        return "nominal"
    try:
        float_vals = [float(v) for v in clean]
    except (ValueError, TypeError):
        return "nominal"
    unique_vals = sorted(set(float_vals))
    n_unique = len(unique_vals)
    if n_unique == 2:
        return "dichotomous"
    all_int = all(float(v) == int(float(v)) for v in unique_vals)
    if not all_int or n_unique > 10:
        return "interval" if all_int and n_unique > 10 else "interval"
    int_vals = [int(v) for v in unique_vals]
    is_sequential = (max(int_vals) - min(int_vals) == n_unique - 1)
    min_val = min(int_vals)
    # Ordinal: sequential integers starting from 1 (Likert-style)
    # e.g., 1,2,3,4,5 → ordinal; 0,1,2 → nominal (labels)
    if is_sequential and min_val >= 1 and 3 <= n_unique <= 10:
        return "ordinal"
    # 0-based sequential (e.g., 0,1,2,3) → nominal (category labels)
    return "nominal"


def _krippendorff_alpha(X, data_type="nominal", n_boot=200):
    """Krippendorff's Alpha for any number of raters and any data type.

    X: (N_units × k_raters) array, NaN = missing
    data_type: 'nominal' | 'ordinal' | 'interval' | 'ratio'
    n_boot: number of bootstrap resamples for 95% CI (0 = skip CI)

    Formula (Krippendorff, 2004):
        α = 1 − D_o / D_e
    where:
        D_o = observed disagreement (mean pairwise distance within pairable units)
        D_e = expected disagreement (mean pairwise distance across pairable values)

    CRITICAL — pairable values:
        D_e must be computed from PAIRABLE values only — i.e., values from units
        where ≥2 raters provided valid ratings. Including values from non-pairable
        units (only 1 valid rater) inflates D_e and produces incorrect α, potentially
        reversing its sign. This matches the coincidence-matrix formulation in
        Krippendorff (2004) and is verified against the krippendorff Python package.

    Distance metrics (Krippendorff, 2004, Ch. 11):
        nominal:  d(v_k, v_l) = 0 if v_k==v_l else 1
        ordinal:  d(v_k, v_l) = (Σ_{g=v_k}^{v_l} n_g − (n_vk + n_vl)/2)²
                  using marginal frequencies from pairable values only
        interval: d(v_k, v_l) = (v_k − v_l)²
        ratio:    d(v_k, v_l) = ((v_k − v_l)/(v_k + v_l))²

    D_e computation:
        nominal/interval/ratio: vectorized matrix operations (fast)
        ordinal: pure-Python loop (freq-weighted cumulative sum required)

    Bootstrap CI: percentile bootstrap; n_boot=0 disables CI.
    For ordinal data with large N×k, use n_boot ≤ 400 to avoid long runtimes.

    References:
        Krippendorff, K. (2004). Content Analysis (2nd ed.). Sage.
        Krippendorff, K. (2016). Bootstrapping Distributions for
            Krippendorff's Alpha for coding predefined units: single-valued
            cα and multi-valued mvα.
            https://www.afhayes.com/public/alphaboot.pdf
            (bootstrap CI algorithm; see inline comments below for the
            step-by-step correspondence to this application's code)
    """
    try:
        X = np.array(X, dtype=float)
        n_units, k_raters = X.shape

        # ── Pairable values: only from units with ≥2 valid raters ────────
        pairable_vals = []
        for i in range(n_units):
            row = X[i, :]; vr = row[~np.isnan(row)]
            if len(vr) >= 2:
                pairable_vals.extend(vr.tolist())
        pairable_vals = np.array(pairable_vals, dtype=float)
        if len(pairable_vals) < 2:
            return np.nan, (np.nan, np.nan)

        unique_vals = np.sort(np.unique(pairable_vals))

        # ── Distance function ─────────────────────────────────────────────
        if data_type == "nominal":
            def dist(a, b): return 0.0 if a == b else 1.0
        elif data_type == "ordinal":
            # Ordinal metric uses marginal frequencies from pairable values only
            freq = {v: int(np.sum(pairable_vals == v)) for v in unique_vals}
            def dist(a, b):
                if a == b: return 0.0
                lo, hi = (a, b) if a < b else (b, a)
                vir = unique_vals[(unique_vals >= lo) & (unique_vals <= hi)]
                s   = sum(freq.get(v, 0) for v in vir)
                return (s - (freq.get(a, 0) + freq.get(b, 0)) / 2) ** 2
        elif data_type == "ratio":
            def dist(a, b):
                if a + b == 0: return 0.0
                return ((a - b) / (a + b)) ** 2
        else:  # interval
            def dist(a, b): return (a - b) ** 2

        # ── Observed disagreement D_o ─────────────────────────────────────
        # Krippendorff (2004) coincidence-matrix formulation:
        # each unit u with μ_u valid raters contributes pairs with weight
        # 1/(μ_u − 1). This ensures units with more raters do not dominate
        # the observed disagreement estimate.
        #
        # Formula: D_o = Σ_u [2/(μ_u−1) · Σ_{j<l} δ(v_uj, v_ul)] / Σ_u μ_u
        #
        # For complete data (all μ_u = k): weights are equal and this reduces
        # to the simple mean, so NO change for users without missing data.
        # For missing data (varying μ_u): weights differ — this correction
        # is essential for correctness.
        #
        # Reference: Krippendorff, K. (2004). Content Analysis: An Introduction
        # to Its Methodology (2nd ed.). Sage. Chapter 11.
        d_o_num = 0.0
        d_o_den = 0.0   # accumulates Σ_u μ_u
        for i in range(n_units):
            row = X[i, :]; vr = row[~np.isnan(row)]; m = len(vr)
            if m < 2: continue
            w = 2.0 / (m - 1)          # weight per pair for this unit
            for ai in range(m):
                for bi in range(ai + 1, m):
                    d_o_num += w * dist(vr[ai], vr[bi])
            d_o_den += float(m)         # μ_u contribution to denominator
        D_o = d_o_num / d_o_den if d_o_den > 0 else np.nan

        # ── Expected disagreement D_e (vectorized where possible) ─────────
        pv = pairable_vals; n_pv = len(pv)
        if data_type == "nominal":
            # Vectorized: fraction of disagreeing pairs
            D_e = float(np.sum(pv[:, None] != pv[None, :]) / (n_pv * (n_pv - 1)))
        elif data_type == "interval":
            diff = pv[:, None] - pv[None, :]
            D_e  = float(np.sum(diff ** 2) / (n_pv * (n_pv - 1)))
        elif data_type == "ratio":
            a_m = pv[:, None]; b_m = pv[None, :]
            denom = a_m + b_m
            with np.errstate(invalid="ignore", divide="ignore"):
                d_m = np.where(denom == 0, 0.0, ((a_m - b_m) / denom) ** 2)
            D_e = float(np.sum(d_m) / (n_pv * (n_pv - 1)))
        else:  # ordinal — must loop (freq-weighted cumulative sum)
            d_e_sum = 0.0; n_exp_pairs = 0
            for ai in range(n_pv):
                for bi in range(ai + 1, n_pv):
                    d_e_sum += dist(pv[ai], pv[bi]); n_exp_pairs += 1
            D_e = d_e_sum / n_exp_pairs if n_exp_pairs > 0 else np.nan

        if np.isnan(D_o) or np.isnan(D_e) or D_e < 1e-12:
            return np.nan, (np.nan, np.nan)

        alpha_val = float(1.0 - D_o / D_e)

        # ── Bootstrap CI ──────────────────────────────────────────────────
        if n_boot == 0:
            return alpha_val, (np.nan, np.nan)

        # ── Bootstrap CI — pair-pool algorithm ────────────────────────────
        # Algorithm (from the primary theoretical source, read directly):
        #   Krippendorff, K. (2016). Bootstrapping Distributions for
        #   Krippendorff's Alpha for coding predefined units: single-valued
        #   cα and multi-valued mvα. https://www.afhayes.com/public/alphaboot.pdf
        #   (originally posted 2006.08.16, revised 2016.08.06). Per that paper,
        #   this algorithm "will be implemented in the revised software KALPHA
        #   (Hayes & Krippendorff, 2007)".
        #
        # 1. Build a flat pool er[] of every within-unit pairwise delta,
        #    across the ENTIRE observed dataset (= the paper's E(r), r=1..No).
        #    Length = nprs = Σ_u μ_u·(μ_u−1)/2.
        # 2. Normalise each entry: er_norm[i] = 2·δᵢ / (D_e · Σμ)
        #    where D_e is computed ONCE from the full observed data and
        #    held fixed for all bootstrap replications (the paper's De).
        # 3. Bootstrap loop: start α = 1.0 (the paper's "α = 1"). For each
        #    unit u (fixed structure — no row resampling), draw
        #    μ_u·(μ_u−1)/2 random indices into er_norm (with replacement,
        #    global pool of No entries) and subtract er_norm[r] / (μ_u−1)
        #    per draw. Redraw rule (paper: "If the 2nd pick yields
        #    Pair(r_2nd) = Pair(r_1st), pick a random integer..."): on the
        #    2nd draw within a unit only, if the underlying pair of RATED
        #    VALUES this draw points to (er_pairs[r], not the raw pool
        #    index r itself) is identical to the pair the 1st draw pointed
        #    to, redraw once. Two different pool positions can hold the
        #    same rated-value pair whenever that pair recurs elsewhere in
        #    the dataset, so this is a materially different — and, per the
        #    cited source, correct — condition from comparing pool indices.
        # 4. Floor at −1.0 (the paper's "If α < −1: n₋₁ ← n₋₁ + 1").
        # 5. CI: sort n_boot replicates; read off the 2.5th/97.5th
        #    percentiles (the paper's α_smallest / α_largest for p=0.05).
        #
        # This design differs from case/row-level resampling in that the
        # unit structure is held fixed and only the ASSIGNMENT of pair-
        # deltas to unit-slots is randomised.
        #
        # Tolerance: bootstrap CIs will not match KALPHA digit-for-digit
        # (both are independent Monte Carlo draws with different PRNG
        # implementations, and the cited paper's own default resample
        # count, X=20,000, exceeds the 200–1,000 range this application
        # offers — Uncertainty Estimation in the accompanying manuscript
        # documents the reasoning for that bound). CI bounds within
        # ~0.02–0.03 of KALPHA's bounds, and CI widths of comparable
        # magnitude, are the realistic target.
        #
        # Validation status: D_o/D_e computation (the non-bootstrap part of
        # this function) was cross-validated against the independent
        # `krippendorff` Python package across all four distance metrics,
        # with and without missing data (see project test suite), and the
        # point estimate has separately matched SPSS 26's KALPHA macro
        # exactly across all four measurement levels on real external
        # validation data. The bootstrap redraw condition above was
        # corrected (2026) to compare rated-value-pair identity rather
        # than pool-index identity, per direct reading of the cited
        # primary source; it has not been benchmarked digit-for-digit
        # against KALPHA's own internal SAS/SPSS source (unpublished),
        # only against the theoretical algorithm the cited paper documents
        # and against KALPHA's own numerical *output* on real data (see
        # accompanying manuscript, Method Validation).

        # Build er pool. er_pairs[r] stores the canonical (order-independent)
        # identity of the two rated values that produced er[r] — i.e. Pair(r)
        # in Krippendorff (2016, https://www.afhayes.com/public/alphaboot.pdf,
        # "Bootstrapping Distributions for Krippendorff's Alpha"), needed for
        # the redraw condition below (Pair(r) is the compared-VALUES identity,
        # not the pool array position).
        er = []
        er_pairs = []
        mu_units = []
        for _u in range(n_units):
            _row = X[_u, :]; _vr = _row[~np.isnan(_row)]; _m = len(_vr)
            if _m < 2: continue
            mu_units.append(_m)
            for _ai in range(_m):
                for _bi in range(_ai + 1, _m):
                    er.append(dist(_vr[_ai], _vr[_bi]))
                    _a_val, _b_val = _vr[_ai], _vr[_bi]
                    er_pairs.append((_a_val, _b_val) if _a_val <= _b_val else (_b_val, _a_val))
        er     = np.asarray(er, dtype=float)
        nprs   = len(er)
        sum_mu = float(sum(mu_units))
        if nprs < 1 or D_e < 1e-12:
            return alpha_val, (np.nan, np.nan)
        er_norm = (2.0 * er) / (D_e * sum_mu)

        # Bootstrap (Krippendorff, 2016, alphaboot.pdf, Algorithm section)
        rng = np.random.default_rng(42)
        boot_alphas = np.empty(n_boot)
        for _z in range(n_boot):
            _a = 1.0
            for _u, _mu_u in enumerate(mu_units):
                _muloop = int(_mu_u * (_mu_u - 1) / 2)
                _rch_first = -1
                for _ppp in range(1, _muloop + 1):
                    _rch = int(rng.integers(0, nprs))
                    # Redraw when the 2nd pick yields Pair(r_2nd) = Pair(r_1st)
                    # — the SAME underlying rated-value pair as the 1st pick,
                    # not merely the same pool index (Krippendorff, 2016).
                    if _ppp == 2 and er_pairs[_rch] == er_pairs[_rch_first]:
                        _rch = int(rng.integers(0, nprs))
                    _rch_first = _rch
                    _a -= er_norm[_rch] / (_mu_u - 1)
            boot_alphas[_z] = max(_a, -1.0)

        boot_sorted = np.sort(boot_alphas)
        _lo_idx = int(0.025 * n_boot)
        _hi_idx = int(0.975 * n_boot)
        ci_lo = float(boot_sorted[_lo_idx])
        ci_hi = float(boot_sorted[_hi_idx])
        return alpha_val, (ci_lo, ci_hi)

    except Exception:
        return np.nan, (np.nan, np.nan)




# ══════════════════════════════════════════════════════════════════════════════
# NEW INTER-RATER AGREEMENT METHODS
# All formulas verified against primary references.
# ══════════════════════════════════════════════════════════════════════════════

def _percentage_agreement(X):
    """Percentage Agreement — proportion of exact pairwise agreements,
    both POOLED (across all units and rater-pairs combined) and PER-UNIT
    (one agreement proportion per rated unit, matching the variable a
    researcher would construct for descriptive-statistics analysis).

    Pooled formula: PA = (1 / (N * C(k,2))) * Σ_i Σ_{j<l} I(X_ij == X_il)
    Per-unit formula (unit i): PA_i = (1/C(k_i,2)) * Σ_{j<l} I(X_ij==X_il),
    where k_i is the number of non-missing raters for unit i (so units
    with partial missingness still contribute a valid per-unit value
    based on however many pairs they do have).

    95% CI: unit-level one-sample t-interval on the N per-unit PA_i
    values (NOT a pair-level Wald interval -- see the CI CORRECTION
    comment in the function body for the Monte Carlo evidence, 85.1%
    vs. 94.2% empirical coverage, motivating this).

    Reference: Stemler (2004). A comparison of consensus, consistency,
    and measurement approaches to estimating interrater reliability.
    Practical Assessment, Research & Evaluation, 9(4).

    Returns a dict:
      pa, ci_lo, ci_hi          -- pooled proportion + Wald 95% CI (as before)
      per_unit                  -- ndarray, one PA value per unit (NaN for
                                    units with <2 valid ratings)
      n_units_valid             -- count of units contributing >=1 valid pair
      mean, sd, minimum, maximum -- descriptive statistics of per_unit,
                                    computed via the standard sample-based
                                    descriptive-statistics convention for a
                                    per-unit agreement variable (sd uses
                                    ddof=1, the standard unbiased-estimator
                                    convention)
    """
    n, k = X.shape
    empty = {"pa": np.nan, "ci_lo": np.nan, "ci_hi": np.nan,
             "per_unit": np.array([]), "n_units_valid": 0,
             "mean": np.nan, "sd": np.nan, "minimum": np.nan, "maximum": np.nan}
    if k < 2:
        return empty
    agree_total = 0; pair_total = 0
    per_unit = np.full(n, np.nan)
    for i in range(n):
        unit_agree = 0; unit_pairs = 0
        for j in range(k):
            for l in range(j+1, k):
                if not (np.isnan(X[i,j]) or np.isnan(X[i,l])):
                    is_agree = int(X[i,j] == X[i,l])
                    agree_total += is_agree
                    pair_total  += 1
                    unit_agree  += is_agree
                    unit_pairs  += 1
        if unit_pairs > 0:
            per_unit[i] = unit_agree / unit_pairs
    if pair_total == 0:
        return empty
    PA = agree_total / pair_total

    valid_units = per_unit[~np.isnan(per_unit)]
    n_valid = len(valid_units)

    # CI CORRECTION: an earlier revision computed the 95% CI via a naive
    # Wald proportion interval using pair_total (= N*C(k,2)) as the
    # effective sample size, treating every within-unit pair as an
    # INDEPENDENT observation. This is statistically invalid: the C(k,2)
    # pairs from the SAME unit are not independent draws -- they share
    # that unit's own underlying agreement tendency (a unit where raters
    # happen to agree tends to have ALL of its pairs agree together, not
    # independently), a clustering/design-effect structure the naive
    # pair-level variance ignores. Direct Monte Carlo verification (3,000
    # simulated trials, clustered-agreement data structure) found the old
    # CI's empirical coverage to be 85.1% against a nominal 95% target --
    # a substantial, confirmed under-coverage, not a minor rounding issue.
    #
    # Corrected approach: treat the N independent UNITS (not the N*C(k,2)
    # correlated pairs) as the sampling unit, using the standard one-sample
    # t-interval for the mean of the N per-unit agreement proportions
    # already computed above. The SAME Monte Carlo procedure applied to
    # this corrected interval found empirical coverage of 94.2%, closely
    # matching the nominal 95% target.
    if n_valid > 1:
        se_pa_units = float(valid_units.std(ddof=1) / np.sqrt(n_valid))
        t_crit = float(scipy_stats.t.ppf(0.975, n_valid - 1))
        ci_lo = max(0.0, float(PA - t_crit * se_pa_units))
        ci_hi = min(1.0, float(PA + t_crit * se_pa_units))
    else:
        ci_lo, ci_hi = np.nan, np.nan

    return {
        "pa": float(PA), "ci_lo": float(ci_lo), "ci_hi": float(ci_hi),
        "per_unit": per_unit, "n_units_valid": int(n_valid),
        "mean": float(valid_units.mean()) if n_valid > 0 else np.nan,
        "sd": float(valid_units.std(ddof=1)) if n_valid > 1 else np.nan,
        "minimum": float(valid_units.min()) if n_valid > 0 else np.nan,
        "maximum": float(valid_units.max()) if n_valid > 0 else np.nan,
    }


def _dual_ci(estimate, se, n, alpha=0.05):
    """Computes BOTH a z-based (asymptotic normal) and a t-based
    (df = n-1) Wald confidence interval for a sample-estimated standard
    error, for the kappa-family coefficients whose SE is derived either
    analytically (delta method) or via jackknife resampling.

    Neither basis is presented as universally "more correct" -- both
    are legitimate, but their theoretical grounding differs:

    z-basis: follows DIRECTLY from the delta method's own asymptotic
    derivation. The delta method's central result is that the estimator
    converges in distribution to a NORMAL limit (not Student-t) as
    n -> infinity (Doob, 1935; general delta-method theory). For the
    specific kappa-family SE formula used throughout this module, the
    primary derivation is Fleiss, J.L., Cohen, J., & Everitt, B.S.
    (1969). Large sample standard errors of kappa and weighted kappa.
    Psychological Bulletin, 72(5), 323-327 -- which is itself a
    delta-method derivation. z is therefore the form that follows
    directly from the SE formula's own theoretical origin, not an
    arbitrary default.

    t-basis (df=n-1): a more conservative alternative. For
    jackknife-derived SEs (Gwet's AC1/AC2), this has independent,
    well-established support in the general jackknife resampling
    literature -- Miller, R.G. (1974). The jackknife: A review.
    Biometrika, 61(1), 1-15; Efron, B., & Tibshirani, R.J. (1993). An
    Introduction to the Bootstrap. Chapman & Hall, Ch. 11 -- both of
    which discuss the "jackknife t-interval" as an established,
    conservative convention distinct from the plain jackknife variance
    estimate. For all four coefficients using this dual-CI mechanism,
    the t-basis is also the convention implemented in Stata's kappaetc
    command as part of what its documentation describes as Gwet's own
    (2014) statistical inference framework for these coefficients
    (Klein, D., 2018. Implementing a general framework for assessing
    interrater agreement in Stata. The Stata Journal, 18(4), 871-901;
    Gwet, K.L., 2014. Handbook of Inter-Rater Reliability, 4th ed.,
    Advanced Analytics, LLC). For the two analytically-derived-SE
    coefficients (Scott's pi, Brennan-Prediger), this t-basis rests on
    the Gwet/Klein source alone, without the additional independent
    jackknife-literature support available for AC1/AC2 -- this
    asymmetry in evidentiary strength is intentional and should not be
    obscured when this note is surfaced to the user.

    Returns dict: ci_lo_z, ci_hi_z, ci_lo_t, ci_hi_t, df, z_critical,
    t_critical.
    """
    if (se is None or (isinstance(se, float) and np.isnan(se))
            or n is None or n < 2):
        return {"ci_lo_z": np.nan, "ci_hi_z": np.nan,
                "ci_lo_t": np.nan, "ci_hi_t": np.nan,
                "df": max((n or 0) - 1, 0), "z_critical": np.nan,
                "t_critical": np.nan}
    df = n - 1
    z_crit = float(scipy_stats.norm.ppf(1 - alpha / 2))
    t_crit = float(scipy_stats.t.ppf(1 - alpha / 2, df)) if df > 0 else np.nan
    return {
        "ci_lo_z": float(estimate - z_crit * se),
        "ci_hi_z": float(estimate + z_crit * se),
        "ci_lo_t": float(estimate - t_crit * se) if not np.isnan(t_crit) else np.nan,
        "ci_hi_t": float(estimate + t_crit * se) if not np.isnan(t_crit) else np.nan,
        "df": df, "z_critical": z_crit, "t_critical": t_crit,
    }


def _scott_pi(r1, r2, alpha=0.05):
    """Scott's Pi (π) — inter-rater agreement for 2 raters, nominal/dichotomous.

    Differs from Cohen's κ in how P_e is calculated:
    - Cohen's κ: P_e = Σ p_i(r1) × p_i(r2)  [product of separate marginals]
    - Scott's π: P_e = Σ ((p_i(r1) + p_i(r2))/2)²  [squared average marginals]

    Formula (Scott, 1955):
        π = (P_o − P_e_scott) / (1 − P_e_scott)
    SE: var(π) = P_o(1−P_o) / (N × (1−P_e)²)   [Fleiss et al. 1969-style
    large-sample approximation, adapted for Scott's own P_e definition]

    VERIFIED, DEFINITIVE finding on this SE formula's small finite-sample
    behaviour: direct Monte Carlo testing found this formula's SE
    estimate differs from the true sampling SE by roughly 1-2% at N=86,
    a discrepancy initially flagged as a possible defect and investigated
    at length -- including two independent attempted alternative
    derivations (a multinomial delta-method re-derivation, and a
    jackknife-based estimator, mirroring the approach used for Gwet's
    AC1/AC2 elsewhere in this module), NEITHER of which improved on this
    formula's own accuracy when tested the same way.

    The decisive test: the discrepancy's magnitude was measured across
    N=86, 200, 500, and 1500 (fixed underlying distribution, only N
    varied) and found to shrink monotonically toward zero as N grows
    (ratio 1.0148 -> 1.0026 -> 0.9988 -> 0.9932) -- the defining,
    expected signature of a valid large-sample (asymptotic) variance
    approximation exhibiting normal, bounded finite-sample bias, NOT a
    formula error. A genuinely incorrect formula (as was found and fixed
    elsewhere in this module for an earlier revision of Cohen's kappa's
    own SE) does not exhibit this convergence pattern -- its error
    persists or does not shrink toward zero as N increases. This formula
    is retained as verified-correct for its documented purpose based on
    this evidence.

    References:
    - Scott, W. A. (1955). Reliability of content analysis: The case of
      nominal scale coding. Public Opinion Quarterly, 19(3), 321–325.
    - Fleiss, J. L., Cohen, J., & Everitt, B. S. (1969). Large sample
      standard errors of kappa and weighted kappa. Psychological Bulletin, 72(5).
    """
    r1 = np.asarray(r1, dtype=float)
    r2 = np.asarray(r2, dtype=float)
    mask = ~(np.isnan(r1) | np.isnan(r2))
    r1, r2 = r1[mask], r2[mask]
    n = len(r1)
    if n < 2:
        return {"pi": np.nan, "se": np.nan, "z": np.nan,
                "p": np.nan, "ci_lo": np.nan, "ci_hi": np.nan,
                "n": n, "label": "N/A"}
    cats = np.union1d(r1, r2)
    Po = float(np.mean(r1 == r2))
    # Scott's Pe: averaged marginal proportions squared
    Pe = float(np.sum([((np.sum(r1==c)/n + np.sum(r2==c)/n)/2)**2 for c in cats]))
    if abs(1 - Pe) < 1e-12:
        return {"pi": np.nan, "se": np.nan, "z": np.nan,
                "p": np.nan, "ci_lo": np.nan, "ci_hi": np.nan,
                "n": n, "label": "N/A"}
    pi_val = (Po - Pe) / (1 - Pe)
    se     = float(np.sqrt(Po*(1-Po) / (n * (1-Pe)**2))) if n > 0 else np.nan
    z      = pi_val / se if (se > 1e-12) else np.nan
    p      = float(2 * scipy_stats.norm.sf(abs(z))) if not np.isnan(z) else np.nan
    _dual  = _dual_ci(pi_val, se, n, alpha)
    return {"pi":    pi_val,
            "se":    se if not np.isnan(se) else np.nan,
            "z":     z if not np.isnan(z) else np.nan,
            # Not rounded here -- see note on kappa_p in _cohen_kappa()
            # for rationale (preserve precision for genuinely tiny p).
            "p":     p if not np.isnan(p) else np.nan,
            "ci_lo": _dual["ci_lo_z"], "ci_hi": _dual["ci_hi_z"],  # backward-compat alias = z-based
            "ci_lo_z": _dual["ci_lo_z"], "ci_hi_z": _dual["ci_hi_z"],
            "ci_lo_t": _dual["ci_lo_t"], "ci_hi_t": _dual["ci_hi_t"],
            "ci_df": _dual["df"],
            "Po": Po, "Pe": Pe,
            "n": n, "label": kappa_label(pi_val)}


def _brennan_prediger(r1, r2, alpha=0.05, q_declared=None):
    """Brennan-Prediger Coefficient (κ_BP).

    Assumes equal category distribution (P_e = 1/q), the most conservative
    expected agreement. More appropriate than Cohen's κ when category
    prevalence is unequal.

    Formula (Brennan & Prediger, 1981):
        κ_BP = (P_o − 1/q) / (1 − 1/q)
    SE: var(κ_BP) ≈ P_o(1−P_o) / (N × (1−1/q)²)

    q -- THEORETICAL BASIS (verified against primary/authoritative source):
    q is the number of categories in the measurement instrument's coding
    scheme -- the space a rater selects among -- not merely the count of
    distinct values that happen to appear in a given sample. Brennan &
    Prediger (1981, p. 693) themselves describe q as "the number of
    categories"; this is the same q-family as Bennett, Alpert, & Goldstein's
    (1954) S coefficient and Gwet's AC1, both of which use an a priori,
    declared category count (see _gwet_ac1's docstring for the fuller
    theoretical argument, independently verified via Gwet's Handbook of
    Inter-Rater Reliability, Ch. 5). If q_declared is not supplied, this
    function falls back to the count of distinct observed values, WHICH
    UNDERSTATES q -- and therefore OVERSTATES Pe and UNDERSTATES kappa_bp
    -- whenever the instrument has a valid category that happens not to
    appear in this specific sample. q_declared should be supplied whenever
    the true instrument scale is known.

    Reference:
    Brennan, R. L., & Prediger, D. J. (1981). Coefficient kappa: Some uses,
    misuses, and alternatives. Educational and Psychological Measurement, 41(3).
    """
    r1 = np.asarray(r1, dtype=float)
    r2 = np.asarray(r2, dtype=float)
    mask = ~(np.isnan(r1) | np.isnan(r2))
    r1, r2 = r1[mask], r2[mask]
    n = len(r1)
    if n < 2:
        return {"kappa_bp": np.nan, "se": np.nan, "z": np.nan,
                "p": np.nan, "ci_lo": np.nan, "ci_hi": np.nan,
                "n": n, "q": 0, "q_observed": 0, "q_declared": q_declared, "label": "N/A"}
    cats = np.union1d(r1, r2)
    q_observed = len(cats)
    q = int(q_declared) if (q_declared is not None and q_declared >= q_observed) else q_observed
    if q < 2:
        return {"kappa_bp": np.nan, "se": np.nan, "z": np.nan,
                "p": np.nan, "ci_lo": np.nan, "ci_hi": np.nan,
                "n": n, "q": q, "q_observed": q_observed, "q_declared": q_declared, "label": "N/A"}
    Po    = float(np.mean(r1 == r2))
    Pe    = 1.0 / q
    kbp   = (Po - Pe) / (1 - Pe)
    se    = float(np.sqrt(Po*(1-Po) / (n * (1-Pe)**2)))
    z     = kbp / se if se > 1e-12 else np.nan
    p     = float(2 * scipy_stats.norm.sf(abs(z))) if not np.isnan(z) else np.nan
    _dual = _dual_ci(kbp, se, n, alpha)
    return {"kappa_bp": kbp,
            "se":       se,
            "z":        z if not np.isnan(z) else np.nan,
            # Not rounded here -- preserve precision for genuinely tiny p.
            "p":        p if not np.isnan(p) else np.nan,
            "ci_lo":    _dual["ci_lo_z"], "ci_hi": _dual["ci_hi_z"],  # backward-compat = z-based
            "ci_lo_z":  _dual["ci_lo_z"], "ci_hi_z": _dual["ci_hi_z"],
            "ci_lo_t":  _dual["ci_lo_t"], "ci_hi_t": _dual["ci_hi_t"],
            "ci_df":    _dual["df"],
            "Po": Po, "Pe": Pe,
            "n": n, "q": q, "q_observed": q_observed, "q_declared": q_declared,
            "label": kappa_label(kbp)}


def _gwet_ac1(X, alpha=0.05, q_declared=None):
    """Gwet's AC1 — for 2 or more raters, nominal/dichotomous data.

    More stable than Cohen's κ when marginal distributions are extreme
    (prevalence paradox). Uses jackknife variance estimation.

    Formula (Gwet, 2008, 2014):
        P_e(AC1) = (1/(q−1)) × Σ_c π_c(1−π_c)
        where π_c = (1/(N×k)) × Σ_i Σ_j I(X_ij = c)  [grand marginal proportion]
        AC1 = (P_o − P_e) / (1 − P_e)

    For k=2: P_o = proportion of matching pairs.
    For k≥2: P_o = (1/(N×k×(k-1)/2)) × Σ_i Σ_{j<l} I(X_ij == X_il)
    Variance: jackknife (Gwet, 2014, Appendix A).

    q -- THEORETICAL BASIS (verified directly against the primary source):
    Gwet, Handbook of Inter-Rater Reliability (5th ed.), Ch. 5, Sec. 5.2.1,
    defines the framework as "a two-rater reliability experiment based on a
    q-level nominal measurement scale," and Sec. 5.4.1's probabilistic model
    states nondeterministic (guessed) ratings are "random with equal chance
    for all q categories" -- i.e. q is the size of the category space a
    rater selects among (an instrument property, fixed a priori), NOT the
    count of distinct values that happen to appear in a specific sample.
    If q_declared is not supplied, this function falls back to the count of
    distinct observed values, WHICH UNDERSTATES q whenever the instrument
    has a valid category absent from this specific sample -- inflating Pe
    and understating AC1. The Σ_c π_c(1−π_c) sum itself is unaffected by
    unobserved categories (each contributes exactly 0), so only the
    (q−1) denominator requires correction; no reconstruction of the
    unobserved category identities is needed.

    References:
    Gwet, K. L. (2008). Computing inter-rater reliability and its variance
    in the presence of high agreement. British Journal of Mathematical and
    Statistical Psychology, 61(1), 29–48.
    Gwet, K. L. (2014). Handbook of Inter-Rater Reliability (4th ed.).
    Advanced Analytics, LLC.
    """
    X = np.array(X, dtype=float)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    n, k = X.shape
    if k < 2 or n < 3:
        return {"ac1": np.nan, "se": np.nan, "z": np.nan,
                "p": np.nan, "ci_lo": np.nan, "ci_hi": np.nan,
                "n": n, "k": k, "label": "N/A"}

    cats = sorted(set(X[~np.isnan(X)].flatten().astype(int).tolist()))
    q_observed = len(cats)
    q = int(q_declared) if (q_declared is not None and q_declared >= q_observed) else q_observed
    if q < 2:
        return {"ac1": np.nan, "se": np.nan, "z": np.nan,
                "p": np.nan, "ci_lo": np.nan, "ci_hi": np.nan,
                "n": n, "k": k, "label": "N/A"}

    def _compute_ac1(X_):
        n_, k_ = X_.shape
        # Observed agreement per unit
        gamma = np.zeros(n_)
        for i in range(n_):
            row = X_[i, :]
            valid = row[~np.isnan(row)]
            m = len(valid)
            if m < 2: continue
            pairs = m*(m-1)/2
            agree = sum(1 for a in range(m) for b in range(a+1,m)
                        if valid[a]==valid[b])
            gamma[i] = agree / pairs
        Po = float(np.mean(gamma))
        # Grand marginal proportions (sum over OBSERVED cats only -- any
        # unobserved declared category has pi_c=0 and contributes nothing
        # to the sum below, so only the (q-1) denominator needs q_declared)
        all_valid = X_[~np.isnan(X_)]
        pi_c = np.array([np.sum(all_valid==c)/len(all_valid) for c in cats])
        Pe = float((1/(q-1)) * np.sum(pi_c*(1-pi_c)))
        if abs(1-Pe) < 1e-12: return np.nan
        return (Po - Pe)/(1 - Pe)

    ac1_full = _compute_ac1(X)

    # Jackknife variance
    ac1_jack = np.array([_compute_ac1(np.delete(X, i, axis=0))
                         for i in range(n)])
    ac1_jack = ac1_jack[~np.isnan(ac1_jack)]
    if len(ac1_jack) < 5:
        se = np.nan
    else:
        var_j = ((n-1)/n) * np.sum((ac1_jack - np.mean(ac1_jack))**2)
        se    = float(np.sqrt(var_j))

    z     = ac1_full/se if (not np.isnan(se) and se>1e-12) else np.nan
    p     = float(2 * scipy_stats.norm.sf(abs(z))) if not np.isnan(z) else np.nan
    _dual = _dual_ci(ac1_full, se, n, alpha)

    return {"ac1":    float(ac1_full) if not np.isnan(ac1_full) else np.nan,
            "se":     se if not np.isnan(se) else np.nan,
            "z":      z if not np.isnan(z) else np.nan,
            # Not rounded here -- preserve precision for genuinely tiny p.
            "p":      p if not np.isnan(p) else np.nan,
            "ci_lo":  _dual["ci_lo_z"], "ci_hi": _dual["ci_hi_z"],  # backward-compat = z-based
            "ci_lo_z": _dual["ci_lo_z"], "ci_hi_z": _dual["ci_hi_z"],
            "ci_lo_t": _dual["ci_lo_t"], "ci_hi_t": _dual["ci_hi_t"],
            "ci_df":  _dual["df"],
            "n": n, "k": k, "q": q, "q_observed": q_observed, "q_declared": q_declared,
            "label":  kappa_label(ac1_full) if not np.isnan(ac1_full) else "N/A"}


def _build_ac2_weight_matrix(cats, q, weights, scale_min=None, X_flat_valid=None):
    """Builds the q_obs x q_obs weight matrix for Gwet's AC2, over the
    OBSERVED category set 'cats' (structural size), normalized using the
    (possibly declared, not merely observed) q (see _gwet_ac2 docstring).

    Five weighting schemes, each formula independently verified against a
    primary or authoritative source (not assumed):

      identity  -- w=1 if c=c' else 0. Reduces AC2 exactly to AC1.
      linear    -- w = 1 - |c-c'|/(q-1). "Cicchetti-Allison" weights.
        Primary source: Cicchetti, D., & Allison, T. (1971). A new
        procedure for assessing reliability of scoring EEG sleep
        recordings. American Journal of EEG Technology, 11, 101-109.
      quadratic -- w = 1 - (c-c')^2/(q-1)^2. "Fleiss-Cohen" weights
        (default, matches this application's prior unnamed default).
        Primary source: Fleiss, J.L., & Cohen, J. (1973). The equivalence
        of weighted kappa and the intraclass correlation coefficient as
        measures of reliability. Educational and Psychological
        Measurement, 33(3), 613-619.
      radical   -- w = 1 - sqrt(|c-c'|/(q-1)). Formula independently
        verified by numerically reproducing R's irrCAC::radical.weights()
        reference output (Gwet's own package): radical.weights(1:3) gives
        w(1,2)=w(2,3)=0.2928932 = 1-sqrt(1/2), matching this formula
        exactly.
      ordinal   -- Krippendorff (2004)-style, frequency-based distance,
        converted to a normalized similarity weight. UNLIKE the other four
        schemes, this one depends on the empirical frequency distribution
        of ratings, not solely on category values -- it is recomputed from
        whatever categories and frequencies are supplied, using the same
        cumulative-frequency formula documented in _krippendorff_alpha's
        ordinal metric:
            d(a,b) = (sum of n_g for g from a to b - (n_a+n_b)/2)^2
        normalized by the maximum such distance across the declared range,
        so that w=1 at zero distance and w=0 at the maximum.

    IMPORTANT (corrected in this revision): the weight matrix is built
    over the FULL DECLARED category range [lo, lo+q-1] -- q categories,
    q possibly larger than the number actually observed -- not merely
    over the categories that happen to appear in the data. This matters
    because the corrected Pe formula (see _gwet_ac2) requires u = the sum
    of the ENTIRE q x q weight matrix, including cells for declared-but-
    unobserved categories; building the matrix only over observed
    categories was found, during verification against Gwet's identity-
    weights-equals-AC1 property, to silently understate u whenever
    q_declared exceeds the observed category count, producing an
    incorrect Pe. lo defaults to the minimum OBSERVED category if
    scale_min is not supplied.

    Returns: (q x q) ndarray W indexed by position within the FULL
    declared range [lo, lo+q-1] -- i.e. W[i,j] corresponds to categories
    (lo+i) and (lo+j), regardless of whether either was actually observed.
    """
    lo = int(scale_min) if scale_min is not None else int(min(cats))
    full_range = list(range(lo, lo + q))
    n_full = len(full_range)
    W = np.zeros((n_full, n_full))

    if weights == "identity":
        for i in range(n_full):
            W[i, i] = 1.0
        return W
    if weights == "linear":
        v = 1
        for i, ci in enumerate(full_range):
            for j, cj in enumerate(full_range):
                W[i, j] = 1 - (abs(ci - cj) ** v) / ((q - 1) ** v) if q > 1 else 1.0
        return W
    if weights == "radical":
        for i, ci in enumerate(full_range):
            for j, cj in enumerate(full_range):
                W[i, j] = 1 - np.sqrt(abs(ci - cj) / (q - 1)) if q > 1 else 1.0
        return W
    if weights == "ordinal":
        # Frequency-based (Krippendorff-style) weights: reconstruct
        # frequencies over the FULL declared category range. Declared-
        # but-unobserved categories correctly contribute 0 frequency,
        # which the cumulative-sum formula handles natively (no special
        # casing needed).
        freq = {g: 0 for g in full_range}
        if X_flat_valid is not None:
            for v_ in X_flat_valid:
                gv = int(v_)
                if gv in freq:
                    freq[gv] += 1
        def _d2(a, b):
            lo_, hi_ = (a, b) if a <= b else (b, a)
            s = sum(freq.get(g, 0) for g in range(lo_, hi_ + 1))
            return (s - (freq.get(a, 0) + freq.get(b, 0)) / 2.0) ** 2
        max_d2 = _d2(full_range[0], full_range[-1]) if q > 1 else 1.0
        max_d2 = max_d2 if max_d2 > 1e-12 else 1.0
        for i, ci in enumerate(full_range):
            for j, cj in enumerate(full_range):
                W[i, j] = 1 - _d2(ci, cj) / max_d2
        return W
    # default / "quadratic" (Fleiss-Cohen)
    v = 2
    for i, ci in enumerate(full_range):
        for j, cj in enumerate(full_range):
            W[i, j] = 1 - (abs(ci - cj) ** v) / ((q - 1) ** v) if q > 1 else 1.0
    return W


def _gwet_ac2(X, weights="quadratic", alpha=0.05, q_declared=None, scale_min=None):
    """Gwet's AC2 — weighted version of AC1 for ordinal data.

    Supports five weighting schemes (see _build_ac2_weight_matrix for
    individually verified formulas and primary sources): "quadratic"
    (Fleiss-Cohen, default), "linear" (Cicchetti-Allison), "radical",
    "ordinal" (Krippendorff-style, frequency-based), and "identity"
    (unweighted -- reduces exactly to AC1).

    Formula (Gwet, 2014, Chapter 5, corrected -- see the note below), for
    the label-based schemes:
        w_cc' = 1 − |c−c'|^v / (q−1)^v   (v=2 quadratic, v=1 linear)
        P_o_w = (1/N) Σ_i Σ_{j<l} w(X_ij, X_il) / C(k,2)
        P_e_w = u × Σ_k π_k(1−π_k) / (q(q−1)),
            u = sum of ALL cells of the q×q weight matrix (incl. diagonal)
        AC2 = (P_o_w − P_e_w) / (1 − P_e_w)
    Variance: jackknife.

    IMPORTANT, documented for traceability: an earlier revision of this
    function implemented P_e_w = (1/(q−1)) Σ_c π_c Σ_{c'≠c} w_cc' (summing
    only OFF-diagonal weights per row). This formula was found, during
    verification, NOT to reduce correctly to AC1's own P_e formula for
    "identity" (unweighted) weights -- it collapsed to P_e_w=0 instead of
    matching AC1 exactly, despite AC2 with identity weights being
    mathematically required to equal AC1 (confirmed against an explicit
    cell-by-cell worked formula: Real Statistics Using Excel, "Gwet's AC2
    Basic Concepts"). The corrected formula above was independently
    verified to reduce exactly to AC1's P_e when W=identity (u=q in that
    case, giving P_e_w = q·Σπk(1−πk)/(q(q−1)) = Σπk(1−πk)/(q−1), Gwet's
    own AC1 formula) -- confirmed by permanent regression test.

    q -- THEORETICAL BASIS: same argument as _gwet_ac1 -- q is the
    instrument's declared category count, not merely the count of
    distinct observed values. See _gwet_ac1's docstring for the full,
    source-verified argument (Gwet, Handbook of Inter-Rater Reliability,
    Ch. 5). Unlike AC1's Pe, AC2's weight MATRIX values themselves do not
    need reconstruction of unobserved category identities for the
    label-based schemes (quadratic/linear/radical), because |c-c'| uses
    the actual observed numeric category values directly -- only the
    (q-1) normalizer requires the declared q. The "ordinal" scheme is the
    exception: it is frequency-based and therefore uses scale_min (see
    _build_ac2_weight_matrix) to correctly place unobserved categories
    within the declared range.

    Reference:
    Gwet, K. L. (2014). Handbook of Inter-Rater Reliability (4th ed.).
    Advanced Analytics, LLC. Chapter 5.
    """
    X = np.array(X, dtype=float)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    n, k = X.shape
    if k < 2 or n < 3:
        return {"ac2": np.nan, "se": np.nan, "z": np.nan,
                "p": np.nan, "ci_lo": np.nan, "ci_hi": np.nan,
                "n": n, "k": k, "label": "N/A", "weights": weights}

    cats = sorted(set(X[~np.isnan(X)].flatten().astype(int).tolist()))
    q_observed = len(cats)
    q = int(q_declared) if (q_declared is not None and q_declared >= q_observed) else q_observed
    if q < 2:
        return {"ac2": np.nan, "se": np.nan, "z": np.nan,
                "p": np.nan, "ci_lo": np.nan, "ci_hi": np.nan,
                "n": n, "k": k, "label": "N/A", "weights": weights}

    # NOTE: identity (unweighted) AC2 is, by construction, mathematically
    # identical to AC1 -- confirmed both theoretically (Real Statistics
    # Using Excel's Gwet documentation: "AC1 is the same as AC2 when
    # restricted to categorical data") and, with the corrected Pe_w
    # formula below, ALGEBRAICALLY: when W=identity, u=q, so
    # Pe_w = q*Σπk(1-πk)/(q(q-1)) = Σπk(1-πk)/(q-1), exactly AC1's Pe.
    # This identity now holds naturally from the general formula; no
    # special-case delegation to _gwet_ac1 is required (an earlier
    # revision patched this case via direct delegation, working around
    # a since-corrected error in the previously implemented Pe_w formula).

    all_valid_flat = X[~np.isnan(X)]
    W = _build_ac2_weight_matrix(cats, q, weights, scale_min=scale_min,
                                  X_flat_valid=all_valid_flat)
    # cat_idx maps each OBSERVED category value to its position WITHIN
    # THE FULL DECLARED RANGE [lo, lo+q-1] -- the same indexing basis
    # _build_ac2_weight_matrix uses for W -- not a separate 0..q_observed-1
    # indexing over only the observed categories. This must stay
    # consistent with _build_ac2_weight_matrix's own 'lo' computation.
    lo = int(scale_min) if scale_min is not None else int(min(cats))
    cat_idx = {c: (c - lo) for c in cats}
    # u = sum of ALL cells of the weight matrix (including the diagonal).
    # This is the scalar multiplier in the verified Pe formula below; it
    # is NOT recomputed per replicate since it depends only on W (fixed
    # once cats/q/weights are fixed), not on the specific data realization.
    u_weight_sum = float(W.sum())

    def _compute_ac2(X_):
        n_, k_ = X_.shape
        # Observed weighted agreement
        Po_w = 0.0; cnt = 0
        for i in range(n_):
            row = X_[i, :]
            valid = row[~np.isnan(row)]
            m = len(valid)
            if m < 2: continue
            for a in range(m):
                for b in range(a+1, m):
                    ia = cat_idx.get(int(valid[a]))
                    ib = cat_idx.get(int(valid[b]))
                    if ia is not None and ib is not None:
                        Po_w += W[ia, ib]; cnt += 1
        if cnt == 0: return np.nan
        Po_w /= cnt
        # Grand marginal proportions (over observed cats; see docstring --
        # unobserved declared categories contribute 0 and need no
        # reconstruction here, only the (q-1) normalizer below needs q)
        all_v = X_[~np.isnan(X_)]
        pi_c  = np.array([np.sum(all_v==c)/len(all_v) for c in cats])
        # Expected weighted agreement -- CORRECTED formula, verified
        # against an explicit cell-by-cell worked formula (Real
        # Statistics Using Excel, "Gwet's AC2 Basic Concepts"):
        #     Pe_w = u * Σ_k πk(1-πk) / (q*(q-1))
        #     u = sum of ALL entries of the weight matrix (incl. diagonal)
        # This form was independently confirmed correct by verifying it
        # reduces EXACTLY to AC1's Pe formula for identity weights
        # (u=q when W=I, giving Pe_w = q*Σπk(1-πk)/(q(q-1)) =
        # Σπk(1-πk)/(q-1), Gwet's own AC1 formula) -- unlike the
        # previously implemented formula (Pe_w = (1/(q-1))Σ_c πc Σ_c'≠c
        # w_cc'), which was found NOT to reduce correctly for identity
        # weights (collapsing to 0), indicating it did not correctly
        # match Gwet's actual general formula for ANY weighting scheme.
        sum_pi_1_minus_pi = float(np.sum(pi_c * (1 - pi_c)))
        Pe_w = u_weight_sum * sum_pi_1_minus_pi / (q * (q - 1))
        if abs(1-Pe_w) < 1e-12: return np.nan
        return (Po_w - Pe_w) / (1 - Pe_w)

    ac2_full = _compute_ac2(X)

    # Jackknife
    ac2_jack = np.array([_compute_ac2(np.delete(X, i, axis=0))
                         for i in range(n)])
    ac2_jack = ac2_jack[~np.isnan(ac2_jack)]
    if len(ac2_jack) < 5:
        se = np.nan
    else:
        var_j = ((n-1)/n)*np.sum((ac2_jack-np.mean(ac2_jack))**2)
        se    = float(np.sqrt(var_j))

    z     = ac2_full/se if (not np.isnan(se) and se>1e-12) else np.nan
    p     = float(2 * scipy_stats.norm.sf(abs(z))) if not np.isnan(z) else np.nan
    _dual = _dual_ci(ac2_full, se, n, alpha)

    return {"ac2":     float(ac2_full) if not np.isnan(ac2_full) else np.nan,
            "se":      se if not np.isnan(se) else np.nan,
            "z":       z if not np.isnan(z) else np.nan,
            # Not rounded here -- preserve precision for genuinely tiny p.
            "p":       p if not np.isnan(p) else np.nan,
            "ci_lo":   _dual["ci_lo_z"], "ci_hi": _dual["ci_hi_z"],  # backward-compat = z-based
            "ci_lo_z": _dual["ci_lo_z"], "ci_hi_z": _dual["ci_hi_z"],
            "ci_lo_t": _dual["ci_lo_t"], "ci_hi_t": _dual["ci_hi_t"],
            "ci_df":   _dual["df"],
            "n": n, "k": k, "q": q, "q_observed": q_observed, "q_declared": q_declared,
            "weights": weights,
            "label":   kappa_label(ac2_full) if not np.isnan(ac2_full) else "N/A"}


def _lin_ccc(r1, r2, alpha=0.05):
    """Lin's Concordance Correlation Coefficient (CCC/ρ_c).

    Simultaneously evaluates PRECISION (correlation, ρ) and ACCURACY (how
    close the data are to the line of perfect concordance, C_b). Only valid
    for exactly 2 raters with interval/ratio data.

    Formula (Lin, 1989):
        ρ_c = 2σ_xy / (σ_x² + σ_y² + (μ_x − μ_y)²)
            = ρ × C_b
    where:
        ρ   = Pearson correlation (precision)
        C_b = 2/(v + 1/v + u²)  (accuracy/bias correction factor)
        v   = σ_x/σ_y  (scale shift)
        u   = (μ_x − μ_y)/(σ_x·σ_y)^0.5  (location shift)

    CONFIDENCE INTERVAL -- FULL Lin (1989) large-sample variance formula
    for the Fisher-Z-transformed CCC (an earlier revision of this
    function used a simplified, "matched-means-only" approximation,
    SE=1/sqrt(N-2), which discards the location-shift (u) contribution
    entirely -- this was found, via direct external cross-validation
    against an independent reference calculator on a real dataset
    (N=86), to produce a confidence interval visibly different from the
    reference tool's own reported Fisher-Z-based interval, even though
    the point estimates for CCC, rho, and Cb all matched closely. The
    FULL formula below, obtained from NCSS PASS's technical
    documentation (a professional statistical-software vendor's own
    published technical reference, itself citing Lin 1989/1992 and Lin,
    Hedayat, Sinha & Yang 2002 directly) and independently reconstructed
    and verified against that same real dataset, reproduced the
    reference tool's reported interval to within 0.001 -- confirming
    this is the correct, complete formula and that the earlier
    simplified approximation was the source of the discrepancy):

        Var[Z(ρ̂_c)] = (1/(n-2)) × [ (1-ρ²)ρ_c² / ((1-ρ_c²)ρ²)
                                    + 2ρ_c³(1-ρ_c)u² / (ρ(1-ρ_c²)²)
                                    − ρ_c⁴u⁴ / (2ρ²(1-ρ_c²)²) ]

    where Z(ρ̂_c) = arctanh(ρ̂_c) is the Fisher transform, and u is the
    SAME location-shift quantity defined above for C_b (verified: at
    u=0 -- i.e. no location bias -- this reduces exactly to the simpler
    "matched-means" special-case formula, (1-ρ²)ρ_c²/((1-ρ_c²)ρ²)/(n-2),
    consistent with multiple independent secondary sources for that
    special case).

    References:
    Lin, L. I. (1989). A concordance correlation coefficient to evaluate
    reproducibility. Biometrics, 45(1), 255–268.
    Lin, L. I. (1992). Assay validation using the concordance correlation
    coefficient. Biometrics, 48(2), 599–604.
    Lin, L., Hedayat, A.S., Sinha, B., & Yang, M. (2002). Statistical
    methods in assessing agreement: Models, issues, and tools. Journal
    of the American Statistical Association, 97(457), 257–270.
    Carrasco, J. L., & Jover, L. (2003). Estimating the generalized
    concordance correlation coefficient through variance components.
    Statistics in Medicine, 22(1), 163–175.
    """
    r1 = np.asarray(r1, dtype=float)
    r2 = np.asarray(r2, dtype=float)
    mask = ~(np.isnan(r1)|np.isnan(r2))
    r1, r2 = r1[mask], r2[mask]
    n = len(r1)
    if n < 3:
        return {"ccc": np.nan, "rho": np.nan, "Cb": np.nan,
                "se": np.nan, "ci_lo": np.nan, "ci_hi": np.nan,
                "n": n, "label": "N/A"}

    mx, my = float(np.mean(r1)), float(np.mean(r2))
    sx2  = float(np.var(r1, ddof=1))
    sy2  = float(np.var(r2, ddof=1))
    sxy  = float(np.cov(r1, r2, ddof=1)[0, 1])
    denom = sx2 + sy2 + (mx - my)**2
    if denom < 1e-12:
        return {"ccc": np.nan, "rho": np.nan, "Cb": np.nan,
                "se": np.nan, "ci_lo": np.nan, "ci_hi": np.nan,
                "n": n, "label": "N/A"}

    ccc = 2*sxy / denom
    rho = float(np.corrcoef(r1, r2)[0, 1])

    # Explicit u (location shift) and v (scale shift) -- previously only
    # implicit (Cb was backed out as ccc/rho without materialising these
    # named quantities); both are needed directly by the full CI variance
    # formula below, and both are independently meaningful diagnostics
    # (v: is one method's spread larger than the other's; u: how large
    # is the mean gap relative to the pooled scale).
    sx, sy = float(np.sqrt(sx2)), float(np.sqrt(sy2))
    v_shift = sx / sy if sy > 1e-12 else np.nan          # scale shift
    u_shift = (mx - my) / np.sqrt(sx * sy) if (sx > 1e-12 and sy > 1e-12) else np.nan  # location shift
    Cb  = ccc/rho if abs(rho) > 1e-12 else np.nan

    # 95% CI via Fisher z on CCC, FULL Lin (1989) variance (see docstring)
    ccc_clipped = max(min(ccc, 0.9999), -0.9999)
    z_ccc = np.arctanh(ccc_clipped)
    if (abs(rho) > 1e-9 and not np.isnan(u_shift)
            and abs(1 - ccc_clipped**2) > 1e-9 and n > 2):
        c, r_, u_ = ccc_clipped, rho, u_shift
        term1 = (1 - r_**2) * c**2 / ((1 - c**2) * r_**2)
        term2 = 2 * c**3 * (1 - c) * u_**2 / (r_ * (1 - c**2)**2)
        term3 = -(c**4 * u_**4) / (2 * r_**2 * (1 - c**2)**2)
        var_z = (term1 + term2 + term3) / (n - 2)
        se_z = float(np.sqrt(var_z)) if var_z > 0 else np.nan
    else:
        se_z = np.nan
    if not np.isnan(se_z):
        ci_lo = float(np.tanh(z_ccc - 1.96*se_z))
        ci_hi = float(np.tanh(z_ccc + 1.96*se_z))
    else:
        ci_lo = ci_hi = np.nan

    # ICC benchmark labels for CCC (Koo & Li 2016 adapted)
    def _ccc_label(v):
        if np.isnan(v): return "N/A"
        v = abs(v)
        if v < 0.50: return "Poor (<0.50)"
        if v < 0.75: return "Moderate (0.50–0.75)"
        if v < 0.90: return "Good (0.75–0.90)"
        return "Excellent (>0.90)"

    return {"ccc":    ccc,
            "rho":    rho,
            "r_squared": float(rho**2) if not np.isnan(rho) else np.nan,
            "Cb":     Cb if not np.isnan(Cb) else np.nan,
            "u_shift": u_shift,     # location shift
            "v_shift": v_shift,     # scale shift
            "mean1": mx, "mean2": my, "sd1": sx, "sd2": sy,
            "mean_diff": float(mx - my),
            "se":     se_z,
            "ci_lo":  ci_lo,
            "ci_hi":  ci_hi,
            "n": n,
            "label":  _ccc_label(ccc)}


def _dual_ci_note(coeff_name, se_basis, ci_lo_z, ci_hi_z, ci_lo_t, ci_hi_t, df):
    """Generates the shared narrative note explaining the z-basis and
    t-basis confidence intervals for Scott's pi, Brennan-Prediger,
    Gwet's AC1, and Gwet's AC2 -- with citation strength presented
    honestly and asymmetrically rather than implying both bases rest on
    equally strong primary-source footing.

    se_basis: "analytic" (Scott's pi, Brennan-Prediger -- delta-method
    SE) or "jackknife" (Gwet's AC1/AC2), since the strength of the
    t-basis citation differs between these two cases (see docstring of
    _dual_ci for the full argument).
    """
    if se_basis == "jackknife":
        t_evidence = (
            "For a jackknife-derived SE (as used here), the t-basis has "
            "independent support in the general jackknife resampling "
            "literature -- Miller, R.G. (1974). The jackknife: A review. "
            "<i>Biometrika</i>, 61(1), 1\u201315; Efron, B., &amp; Tibshirani, "
            "R.J. (1993). <i>An Introduction to the Bootstrap</i>. Chapman "
            "&amp; Hall, Ch. 11 -- both of which document the "
            "\u201cjackknife t-interval\u201d as an established, conservative "
            "convention, in addition to Gwet's (2014) own framework.")
    else:
        t_evidence = (
            "For this analytically-derived (delta-method) SE, the "
            "t-basis rests on Gwet's (2014) statistical inference "
            "framework alone, as implemented in Stata's <i>kappaetc</i> "
            "command (Klein, 2018) -- without the additional independent "
            "jackknife-literature support available for AC1/AC2. This "
            "asymmetry in evidentiary strength is stated explicitly "
            "rather than implying both bases are equally well-supported.")
    return (
        f'<div class="dual-ci-note">'
        f'<b>Two confidence intervals are reported for {coeff_name}, on two different, '
        f'both-legitimate theoretical bases:</b><br/>'
        f'&bull; <b>z-basis (95% CI): [{_f_local(ci_lo_z)}, {_f_local(ci_hi_z)}]</b> \u2014 '
        f'follows directly from the delta method\u2019s own asymptotic derivation '
        f'(the estimator converges to a NORMAL, not Student-t, limit). For this '
        f'coefficient family, the primary derivation is Fleiss, J.L., Cohen, J., '
        f'&amp; Everitt, B.S. (1969). Large sample standard errors of kappa and '
        f'weighted kappa. <i>Psychological Bulletin</i>, 72(5), 323\u2013327.<br/>'
        f'&bull; <b>t-basis (df={df}): [{_f_local(ci_lo_t)}, {_f_local(ci_hi_t)}]</b> \u2014 '
        f'a more conservative alternative (always at least as wide as the z-basis '
        f'interval). {t_evidence}<br/>'
        f'<i>Neither basis is presented as universally \u201ccorrect\u201d \u2014 the '
        f'z-basis follows directly from this SE formula\u2019s own theoretical origin; '
        f'the t-basis is the more conservative, established practical convention. '
        f'Researchers should select and report the basis appropriate to their '
        f'field\u2019s convention and cite the corresponding source(s) above.</i>'
        f'</div>')


def _f_local(v):
    """Minimal 4dp formatter for use within engine-generated narrative
    text (the engine has no dependency on the UI's display formatters)."""
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return "\u2014"
    return f"{v:.4f}"


def _gwet_ac_interp(value, label, method_name, n_units, k_raters,
                     data_type, n_boot_or_jack="jackknife"):
    """Descriptive academic interpretation for Gwet's AC1/AC2."""
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return "Result could not be computed for this configuration."
    v = float(value)
    if v < 0:
        strength = "poor (below chance level)"
        impl = ("The raters disagreed more than expected by chance. "
                "Rater training and clearer operational definitions are strongly recommended.")
    elif v < 0.20:
        strength = "slight"
        impl = ("Agreement barely exceeds chance level. "
                "Rating criteria should be revised and raters re-trained.")
    elif v < 0.40:
        strength = "fair"
        impl = ("Fair agreement — substantially influenced by chance. "
                "Rater calibration is recommended before using these ratings for research.")
    elif v < 0.60:
        strength = "moderate"
        impl = ("Moderate agreement, acceptable for exploratory research. "
                "Improvement is recommended for high-stakes or publishable assessment.")
    elif v < 0.80:
        strength = "substantial"
        impl = ("Substantial agreement — generally acceptable for most research contexts.")
    else:
        strength = "almost perfect"
        impl = ("Almost perfect agreement — excellent inter-rater reliability.")

    dtype_str = {"dichotomous": "dichotomous (2 categories)",
                 "nominal": "nominal (unordered categories)",
                 "ordinal": "ordinal (ordered categories)"}.get(data_type, data_type)

    return (
        f"Gwet's {method_name} = {v:.3f} indicates <b>{strength} agreement</b> "
        f"among {k_raters} raters rating {n_units} units "
        f"({dtype_str} data; {label}). "
        f"{impl} "
        f"Variance estimated via {n_boot_or_jack}. "
        f"Note: Gwet's coefficients are more stable than Cohen's κ under "
        f"extreme marginal distributions (prevalence paradox). "
        f"Benchmarks: Landis & Koch (1977)."
    )


def _scott_pi_interp(pi, label, n, data_type):
    """Descriptive interpretation for Scott's π.

    Uses if-elif chain — NOT a dict with boolean keys.
    The dict-boolean-key anti-pattern evaluates all conditions at dict creation
    time, collapsing multiple True keys into one and producing incorrect
    strength labels for all values below the last True condition.
    """
    if pi is None or (isinstance(pi, float) and np.isnan(pi)):
        return "Result could not be computed."
    v = float(pi)
    if v < 0:
        strength = "poor"
        impl = "worse than chance; systematic bias or confusion between categories."
    elif v < 0.20:
        strength = "slight"
        impl = "barely above chance; rating criteria need revision."
    elif v < 0.40:
        strength = "fair"
        impl = "fair but chance-influenced; rater calibration recommended."
    elif v < 0.60:
        strength = "moderate"
        impl = "moderate; acceptable for exploratory research."
    elif v < 0.80:
        strength = "substantial"
        impl = "substantial; generally acceptable for research."
    else:
        strength = "almost perfect"
        impl = "excellent reliability."
    dtype_str = {"dichotomous": "dichotomous", "nominal": "nominal"}.get(data_type, data_type)
    return (
        f"Scott's π = {v:.3f} indicates <b>{strength} agreement</b> "
        f"between 2 raters on {n} units ({dtype_str} data; {label}). "
        f"The result is {impl} "
        f"Scott's π uses averaged marginal proportions to estimate expected "
        f"agreement, unlike Cohen's κ which uses the product of separate "
        f"marginals — yielding slightly different estimates when rater "
        f"marginals differ. Reference: Scott (1955)."
    )


def _bp_interp(kbp, label, n, q, data_type):
    """Descriptive interpretation for Brennan-Prediger coefficient."""
    if kbp is None or (isinstance(kbp, float) and np.isnan(kbp)):
        return "Result could not be computed."
    v = float(kbp)
    if v < 0:     strength = "poor (below chance)"
    elif v < 0.20: strength = "slight"
    elif v < 0.40: strength = "fair"
    elif v < 0.60: strength = "moderate"
    elif v < 0.80: strength = "substantial"
    else:          strength = "almost perfect"
    dtype_str = {"dichotomous": "dichotomous", "nominal": "nominal",
                 "ordinal": "ordinal"}.get(data_type, data_type)
    return (
        f"Brennan-Prediger coefficient = {v:.3f} indicates <b>{strength} agreement</b> "
        f"between 2 raters on {n} units ({dtype_str}, {q} categories; {label}). "
        f"The Brennan-Prediger coefficient assumes uniform distribution of "
        f"ratings across all {q} categories (P_e = 1/{q} = {1/q:.3f}), "
        f"making it the most conservative estimate of agreement. "
        f"It is recommended when category distributions are highly unequal, "
        f"as it avoids the paradoxes that affect Cohen's κ. "
        f"Reference: Brennan & Prediger (1981)."
    )


def _ccc_interp(ccc, rho, Cb, label, n):
    """Descriptive interpretation for Lin's CCC."""
    if ccc is None or (isinstance(ccc, float) and np.isnan(ccc)):
        return "Result could not be computed."
    v = float(ccc)
    if v < 0.50:   strength = "poor"
    elif v < 0.75: strength = "moderate"
    elif v < 0.90: strength = "good"
    else:          strength = "excellent"
    rho_str = f"{rho:.3f}" if not np.isnan(rho) else "N/A"
    Cb_str  = f"{Cb:.3f}"  if not np.isnan(Cb)  else "N/A"
    return (
        f"Lin's Concordance Correlation Coefficient (CCC = {v:.3f}) indicates "
        f"<b>{strength} concordance</b> between 2 raters on {n} units ({label}). "
        f"CCC simultaneously evaluates precision (Pearson r = {rho_str}) and "
        f"accuracy (bias correction factor C_b = {Cb_str}). "
        f"A high Pearson r with low C_b indicates raters agree on rank order "
        f"but differ systematically in absolute scoring (scale or location bias). "
        f"CCC ≤ Pearson r always holds; the gap between them reflects systematic bias. "
        f"Benchmarks (Koo & Li, 2016 adapted): CCC > 0.90 excellent; "
        f"0.75–0.90 good; 0.50–0.75 moderate; < 0.50 poor. "
        f"Reference: Lin (1989) Biometrics; Carrasco & Jover (2003)."
    )


def _pa_interp(pa, ci_lo, ci_hi, n, k):
    """Descriptive interpretation for Percentage Agreement."""
    if pa is None or (isinstance(pa, float) and np.isnan(pa)):
        return "Result could not be computed."
    ci_str = (f"[{ci_lo:.3f}, {ci_hi:.3f}]"
              if not (np.isnan(ci_lo) or np.isnan(ci_hi)) else "—")
    level = ("excellent" if pa >= 0.90 else "good" if pa >= 0.80
             else "moderate" if pa >= 0.70 else "fair" if pa >= 0.60
             else "poor")
    return (
        f"Percentage Agreement = {pa*100:.1f}% (95% CI {ci_str}) — "
        f"<b>{level} observed agreement</b> across {k} raters on {n} units. "
        f"Percentage Agreement does not correct for chance, so it should "
        f"always be reported alongside a chance-corrected coefficient "
        f"(Cohen's κ, Gwet's AC1, or Krippendorff's α). "
        f"It is reported here as a descriptive baseline. "
        f"Reference: Stemler (2004). Practical Assessment, Research & Evaluation."
    )


def _irar_method_context(data_type, k_raters, applicable_methods):
    """Generate academic-English contextual description of why specific methods
    are computed for a given data type and rater count.
    Displayed prominently above the method tabs in the web output.

    CORRECTED (per direct user testing): three defects fixed in this
    revision, all in this single function.
    (1) Content previously used markdown **bold** syntax, but is rendered
        via st.markdown(..., unsafe_allow_html=True) wrapped in a raw
        <div> block -- markdown syntax is not processed inside a raw HTML
        block by standard Markdown parsers, so **text** displayed as
        literal asterisks. Fixed: all emphasis now uses literal <b> tags,
        consistent with every other interpretive-text function in this
        module.
    (2) The "guidance" text was previously a single flat paragraph.
        Fixed: now an HTML list, one item per coefficient.
    (3) MOST SUBSTANTIVE: "guidance" was previously a STATIC paragraph per
        data_type, independent of applicable_methods -- it could both
        OMIT coefficients that ARE computed for a configuration (e.g. the
        dichotomous/nominal branch never mentioned Scott's π, Brennan-
        Prediger, or Krippendorff's α, despite all three always being
        computed for that data type) AND INCLUDE coefficients that are
        NOT applicable for a specific k_raters (e.g. "Weighted Cohen's κ"
        was recommended even for k>=3 ordinal configurations, where
        Weighted κ is never computed, since it is a k=2-only method).
        Fixed: guidance is now built dynamically, iterating
        applicable_methods directly -- the exact same source of truth
        already used for method_list -- so it can never omit an applicable
        coefficient or reference an inapplicable one, for any
        data_type x k_raters combination.
    """
    dtype_full = {"dichotomous": "dichotomous (2 categories, e.g., Correct/Incorrect, Pass/Fail)",
                  "nominal":     "nominal (unordered categories, e.g., error type classification)",
                  "ordinal":     "ordinal (ordered categories, e.g., Likert scale, rubric scores)",
                  "interval":    "interval (continuous scale, e.g., test scores 0–100)",
                  "ratio":       "ratio (continuous with true zero, e.g., time, frequency)"
                  }.get(data_type, data_type)

    method_descs = {
        "cohen":        "<b>Cohen's κ</b> — chance-corrected agreement for 2 raters, nominal/dichotomous (Cohen, 1960)",
        "gwet_ac1":     "<b>Gwet's AC1</b> — stable alternative to Cohen's κ, avoids prevalence paradox (Gwet, 2008)",
        "scott_pi":     "<b>Scott's π</b> — agreement using averaged marginal proportions (Scott, 1955)",
        "bp":           "<b>Brennan-Prediger</b> — most conservative estimate, assumes uniform category distribution (Brennan & Prediger, 1981)",
        "pct":          "<b>Percentage Agreement</b> — observed agreement without chance correction (reported as baseline)",
        "fleiss":       "<b>Fleiss' κ</b> — generalises Cohen's κ to ≥3 raters, nominal/dichotomous (Fleiss, 1971)",
        "weighted":     "<b>Weighted Cohen's κ</b> — ordinal agreement with quadratic weights for 2 raters (Cohen, 1968)",
        "gwet_ac2":     "<b>Gwet's AC2</b> — weighted version of AC1, more stable than Weighted κ for ordinal data (Gwet, 2014)",
        "icc":          "<b>ICC (6 forms)</b> — gold standard for continuous data: two-way absolute (ICC-A) and consistency (ICC-C) models (Shrout & Fleiss, 1979)",
        "ccc":          "<b>Lin's CCC</b> — measures precision and accuracy simultaneously for 2 raters (Lin, 1989)",
        "krippendorff": "<b>Krippendorff's α</b> — universal measure: any data type, any number of raters, handles missing data (Krippendorff, 2004)",
    }

    # Short, method-specific guidance fragments. Combined dynamically
    # below, strictly following applicable_methods -- never a static
    # per-data_type paragraph -- so every computed method is addressed
    # and no inapplicable method is ever recommended.
    guidance_fragments = {
        "pct":          "Report as a descriptive baseline alongside any chance-corrected coefficient below; it is not itself chance-corrected.",
        "cohen":        "A universally recognised primary index for 2-rater nominal/dichotomous data.",
        "gwet_ac1":     "Recommended as the <b>primary index</b> when category prevalence is unequal or skewed (avoids the kappa paradox).",
        "scott_pi":     "A useful cross-check against Cohen's κ; differs only in how chance agreement is modelled from the marginals.",
        "bp":           "The most conservative (uniform-chance) estimate; useful as a lower-bound sensitivity check.",
        "fleiss":       "The standard index for ≥3-rater nominal/dichotomous agreement; generalises Cohen's κ.",
        "weighted":     "Widely used in educational and clinical research for 2-rater ordinal agreement.",
        "gwet_ac2":     "Recommended as the <b>primary index</b> for ordinal data — more stable than Weighted κ under skewed marginals.",
        "icc":          "ICC(A,1) is recommended for single-rater absolute-agreement reliability; use ICC(A,k) if the mean of all raters' scores will be used in practice.",
        "ccc":          "Recommended when both precision (correlation) and accuracy (mean bias) need to be assessed simultaneously.",
        "krippendorff": "A universal complementary estimate that handles missing data and remains comparable across data types.",
    }

    intro = (
        f"Data type: <b>{dtype_full}</b> | Raters: <b>{k_raters}</b> | "
        f"Methods computed: <b>{len(applicable_methods)}</b><br/><br/>"
        f"The following inter-rater agreement methods are automatically computed "
        f"based on the data type and number of raters. Each method addresses "
        f"a different aspect of rater reliability. Results are presented in "
        f"separate tabs below."
    )

    method_list = "<br/>".join(f"&bull; {method_descs[m]}" for m in applicable_methods
                                if m in method_descs)

    # Dynamic guidance: one list item per APPLICABLE method, in the same
    # order as method_list, so nothing computed is ever left undiscussed
    # and nothing uncomputed is ever recommended.
    primary_keys = {"gwet_ac1", "gwet_ac2"}
    guidance_items = []
    for m in applicable_methods:
        if m not in method_descs or m not in guidance_fragments:
            continue
        name_only = method_descs[m].split(" — ")[0]  # keeps the <b>...</b> pair intact
        tag = " <b>[Recommended primary]</b>" if m in primary_keys else ""
        guidance_items.append(f"&bull; {name_only}{tag} — {guidance_fragments[m]}")
    guidance = "<br/>".join(guidance_items)

    return {"intro": intro, "methods": method_list, "guidance": guidance}


def _get_applicable_methods(data_type, k_raters):
    """Return ordered list of applicable inter-rater method keys.
    All methods in the list are computed automatically.
    """
    methods = []
    if data_type in ("dichotomous", "nominal"):
        methods.append("pct")          # Percentage Agreement — always first
        if k_raters == 2:
            methods += ["cohen", "gwet_ac1", "scott_pi", "bp"]
        if k_raters >= 3:
            methods += ["fleiss", "gwet_ac1"]
        methods.append("krippendorff")
    elif data_type == "ordinal":
        methods.append("pct")
        if k_raters == 2:
            methods += ["weighted", "gwet_ac2"]
        if k_raters >= 3:
            methods.append("gwet_ac2")
        methods.append("krippendorff")
    else:  # interval / ratio
        methods.append("pct")
        methods.append("icc")
        if k_raters == 2:
            methods.append("ccc")
        methods.append("krippendorff")
    return methods

def _cohen_kappa_weight_matrix(k, weights):
    """Builds the k x k AGREEMENT weight matrix (w_ii=1 for exact agreement,
    decreasing toward 0 for more severe disagreement), matching the exact
    convention used internally by scikit-learn's cohen_kappa_score() for
    weights='linear'/'quadratic' -- verified by direct numerical comparison:
    kappa computed via this module's own Equation-8/9-based formula below
    reproduces sklearn's own point estimate exactly for k=2 and k=4 test
    cases, for all three schemes.

    weights: None/"unweighted" -> identity (w_ii=1, else 0)
             "linear"          -> w_ij = 1 - |i-j|/(k-1)
             "quadratic"       -> w_ij = 1 - (i-j)^2/(k-1)^2
    """
    idx = np.arange(k)
    if weights in (None, "unweighted"):
        return np.eye(k)
    diff = np.subtract.outer(idx, idx).astype(float)
    if weights == "linear":
        return 1 - np.abs(diff) / max(k - 1, 1)
    if weights == "quadratic":
        return 1 - (diff ** 2) / max((k - 1) ** 2, 1)
    raise ValueError(f"Unknown weights scheme: {weights}")


def _kappa_se_z_p_exact(O_counts, W, alpha=0.05):
    """EXACT large-sample standard errors of (weighted) kappa, implementing
    Equation 8 (general-purpose variance, "useful in setting confidence
    limits") and Equation 9 (null-hypothesis variance, "may be used in
    testing the hypothesis that kappa=0") of Fleiss, Cohen & Everitt (1969),
    Psychological Bulletin, 72(5), 323-327 -- parameterized by an explicit
    k x k agreement weight matrix W (identity for unweighted kappa).

    CORRECTION, replacing an earlier implementation: a previous revision of
    this module computed kappa's standard error via a simplified
    approximation, ASE = sqrt[P_o(1-P_o) / (N(1-P_e)^2)], attributing it to
    Fleiss, Cohen & Everitt (1969) without directly verifying it against
    that paper's own stated formula. Direct reconstruction of the primary
    source (obtained as full text) found this simplified formula does NOT
    match either of the two formulas the paper actually presents (Equation
    8 or Equation 9), and can diverge from the paper's own Equation 9 by a
    magnitude that materially changes z and p for realistic data -- found
    via external cross-validation against independent reference statistical software on a real
    N=86 dataset ([[12,12],[7,55]]), where the simplified formula gave
    z=3.4817 against both external tools' z=3.8811, while THIS exact
    Equation-9 implementation reproduces z=3.8811 to four decimal places.
    This function's exact implementation of both equations was itself
    verified, before this correction was adopted, by reproducing the
    primary source's own two worked numerical examples (Table 1, weighted
    kappa, N=200: Var=.002885/.003082; Table 2, unweighted kappa, N=200:
    same values, since unweighted kappa is the identity-weight special
    case) to six decimal places.

    Returns dict: kappa, se_general (Eq 8), se_null (Eq 9), z, p -- z and p
    use se_null (Eq 9), consistent with these being the correct quantities
    for the H0:kappa=0 significance test the primary source itself states
    Equation 9 is "used in testing" -- se_general (Eq 8) is retained in the
    return value for transparency and potential future use, but is NOT
    currently used to construct a confidence interval by this module (see
    kappa_ci_note in _cohen_kappa(), which explains this design choice and
    is unaffected by this formula correction).
    """
    N = float(O_counts.sum())
    if N <= 0:
        return {"kappa": np.nan, "se_general": np.nan, "se_null": np.nan,
                "z": np.nan, "p": np.nan}
    p = O_counts / N
    k = O_counts.shape[0]
    row_m = p.sum(axis=1)
    col_m = p.sum(axis=0)

    p_o = float((W * p).sum())
    p_e = float(sum(row_m[i] * col_m[j] * W[i, j]
                     for i in range(k) for j in range(k)))
    if abs(1 - p_e) < 1e-12:
        return {"kappa": np.nan, "se_general": np.nan, "se_null": np.nan,
                "z": np.nan, "p": np.nan}
    kappa = (p_o - p_e) / (1 - p_e)

    w_bar_row = np.array([sum(W[i, j] * col_m[j] for j in range(k)) for i in range(k)])
    w_bar_col = np.array([sum(W[i, j] * row_m[i] for i in range(k)) for j in range(k)])

    # Equation 8 -- general-purpose variance
    term1_gen = sum(
        p[i, j] * ((1 - p_e) * W[i, j] - (1 - p_o) * (w_bar_row[i] + w_bar_col[j])) ** 2
        for i in range(k) for j in range(k))
    term2_gen = (p_o * p_e - 2 * p_e + p_o) ** 2
    denom_gen = N * (1 - p_e) ** 4
    var_gen = (term1_gen - term2_gen) / denom_gen if denom_gen > 1e-15 else np.nan
    se_general = float(np.sqrt(max(var_gen, 0))) if not np.isnan(var_gen) else np.nan

    # Equation 9 -- null-hypothesis (H0: kappa=0) variance
    term1_null = sum(
        row_m[i] * col_m[j] * (W[i, j] - (w_bar_row[i] + w_bar_col[j])) ** 2
        for i in range(k) for j in range(k))
    denom_null = N * (1 - p_e) ** 2
    var_null = (term1_null - p_e ** 2) / denom_null if denom_null > 1e-15 else np.nan
    se_null = float(np.sqrt(max(var_null, 0))) if not np.isnan(var_null) else np.nan

    if se_null is not None and not np.isnan(se_null) and se_null > 1e-12:
        z = kappa / se_null
        p_val = float(2 * scipy_stats.norm.sf(abs(z)))
    else:
        z, p_val = np.nan, np.nan

    return {"kappa": float(kappa), "se_general": se_general, "se_null": se_null,
            "z": float(z) if not np.isnan(z) else np.nan,
            "p": p_val}


def _kappa_se_z_p(r1, r2, k_val, n, scipy_stats=scipy_stats):
    """DEPRECATED simplified approximation -- retained only for the
    permanent regression test that documents why it was replaced
    (test_cohen_kappa_old_simplified_se_no_longer_used). NOT called by
    _cohen_kappa() as of this correction; see _kappa_se_z_p_exact() for
    the current, verified implementation of Fleiss, Cohen & Everitt
    (1969)'s actual Equation 9."""
    cats = np.union1d(r1, r2)
    nc   = len(cats)
    cat_map = {c: i for i, c in enumerate(cats)}
    O = np.zeros((nc, nc))
    for a, b in zip(r1, r2):
        O[cat_map[a], cat_map[b]] += 1
    O /= n
    row_m = O.sum(axis=1); col_m = O.sum(axis=0)
    p_o = np.diag(O).sum()
    p_e = (row_m * col_m).sum()
    if abs(1 - p_e) < 1e-12:
        return np.nan, np.nan, np.nan
    ase = float(np.sqrt(p_o * (1 - p_o) / max(n * (1 - p_e) ** 2, 1e-12)))
    z   = k_val / ase if ase > 1e-12 else np.nan
    p   = float(2 * scipy_stats.norm.sf(abs(z))) if not np.isnan(z) else np.nan
    return ase, z, p


def _cohen_kappa(X, rater_names, alpha=0.05):
    """Cohen's Kappa for exactly 2 raters (columns of X).
    Returns a result dict or None on failure.
    Supports: standard κ (all types) + weighted κ linear & quadratic (ordinal)."""
    if not _SKL or X.shape[1] != 2:
        return None
    try:
        r1 = X[:, 0].astype(int)
        r2 = X[:, 1].astype(int)
    except Exception:
        return None
    n    = len(r1)
    dtype = _detect_data_type(list(r1) + list(r2))
    names = (rater_names if rater_names and len(rater_names) >= 2
             else ["Rater 1", "Rater 2"])

    def _safe_kappa(a, b, weights=None):
        try:
            return float(_skl_kappa(a, b, weights=weights))
        except Exception:
            return np.nan

    cats_sorted = sorted(set(r1.tolist() + r2.tolist()))
    nc = len(cats_sorted)
    cat_map = {c: i for i, c in enumerate(cats_sorted)}
    O_counts = np.zeros((nc, nc))
    for a, b in zip(r1, r2):
        O_counts[cat_map[a], cat_map[b]] += 1

    # ── All three weighting schemes, ALWAYS computed together (not gated
    # by dtype=="ordinal" as an earlier revision did -- linear/quadratic
    # weighted kappa is well-defined and computable for dichotomous data
    # too, even though it is then mathematically identical to unweighted
    # kappa, per Fleiss & Cohen, 1973; this module now always computes
    # and reports all three, matching the presentation convention of
    # independent external reference tools). ──
    variants = {}
    for scheme in ("unweighted", "linear", "quadratic"):
        W = _cohen_kappa_weight_matrix(nc, scheme)
        exact = _kappa_se_z_p_exact(O_counts, W)
        k_sklearn = _safe_kappa(r1, r2, weights=None if scheme == "unweighted" else scheme)
        variants[scheme] = {
            "kappa": k_sklearn if not np.isnan(k_sklearn) else exact["kappa"],
            "se_general": exact["se_general"],
            "se_null": exact["se_null"],
            "z": exact["z"],
            "p": exact["p"],
            "label": kappa_label(k_sklearn if not np.isnan(k_sklearn) else exact["kappa"]),
        }

    k_std  = variants["unweighted"]["kappa"]
    ase_s  = variants["unweighted"]["se_null"]
    z_s    = variants["unweighted"]["z"]
    p_s    = variants["unweighted"]["p"]

    ct = pd.crosstab(
        pd.Series(r1.tolist(), name=names[0]),
        pd.Series(r2.tolist(), name=names[1]))

    # ── Per-category agreement breakdown (matches external reference-tool
    # convention: for each category c, N_r1 = how many times rater 1 used
    # c, N_r2 = how many times rater 2 used c, Agree = how many units both
    # raters assigned c, Pct = Agree / max(N_r1,N_r2) as a same-category
    # concordance rate). ──
    per_category = []
    for c in cats_sorted:
        ci = cat_map[c]
        n_r1 = int(O_counts[ci, :].sum())
        n_r2 = int(O_counts[:, ci].sum())
        agree = int(O_counts[ci, ci])
        # Jaccard-style overlap: Agree / (N_r1 + N_r2 - Agree), i.e.
        # intersection over union of the two raters' respective usage of
        # this category -- verified against an external reference tool's
        # own reported per-category percentages on a real dataset
        # (categories 0/1, N_r1/N_r2=24/19 and 62/67, Agree=12/55: this
        # formula reproduces the reference tool's reported 38.7%/74.3%
        # exactly; a simpler Agree/max(N_r1,N_r2) convention does not).
        denom = n_r1 + n_r2 - agree
        pct = (agree / denom * 100) if denom > 0 else np.nan
        per_category.append({"category": c, "n_r1": n_r1, "n_r2": n_r2,
                              "agree": agree, "pct": pct})

    p_o_std = float(np.diag(O_counts / n).sum())
    p_e_std = float(sum((O_counts.sum(axis=1)/n)[i] * (O_counts.sum(axis=0)/n)[j]
                         for i in range(nc) for j in range(nc) if i == j))
    # Recompute p_e_std via the standard product-of-marginals definition
    # (equivalent for the unweighted case; kept as an explicit, independent
    # line for clarity in the breakdown text rather than reusing a
    # weighted-general intermediate).
    row_m_std = O_counts.sum(axis=1) / n
    col_m_std = O_counts.sum(axis=0) / n
    p_e_std = float((row_m_std * col_m_std).sum())

    res = {
        "n": n, "dtype": dtype,
        "rater1": names[0], "rater2": names[1],
        "categories": cats_sorted,
        "n_categories": nc,
        "crosstab":   ct,
        "variants": variants,
        "per_category": per_category,
        "p_observed": p_o_std,
        "p_expected": p_e_std,
        "kappa":      k_std if not np.isnan(k_std) else np.nan,
        "kappa_ase":  ase_s if not np.isnan(ase_s) else np.nan,
        "kappa_z":    z_s if not np.isnan(z_s) else np.nan,
        # NOTE: kappa_p is NOT rounded here (unlike kappa/ase/z above).
        # A genuinely tiny p-value (e.g. z~42 with strong agreement + large
        # N is entirely realistic — verified empirically) would otherwise be
        # rounded to exactly 0.0 at the engine level, which is statistically
        # dishonest (p is never exactly zero) and destroys precision before
        # the display formatter (_p(), which correctly renders "< .00001"
        # for near-zero values) ever sees the true value. Same root-cause
        # class of bug as the ICC p-value issue found and fixed earlier.
        "kappa_p":    p_s if not np.isnan(p_s) else np.nan,
        "kappa_label": kappa_label(k_std),
    }
    res["agreement_breakdown_text"] = (
        f"P(observed) = {p_o_std:.4f}; P(expected by chance) = {p_e_std:.4f}; "
        f"\u03ba = (P_o \u2212 P_e) / (1 \u2212 P_e) = "
        f"({p_o_std:.4f} \u2212 {p_e_std:.4f}) / (1 \u2212 {p_e_std:.4f}) = {k_std:.4f}"
    )
    res["formula_reference_note"] = (
        "Point estimate: Cohen, J. (1960). A coefficient of agreement for "
        "nominal scales. Educational and Psychological Measurement, 20(1), "
        "37\u201346 (unweighted); Cohen, J. (1968). Weighted kappa: Nominal "
        "scale agreement with provision for scaled disagreement or partial "
        "credit. Psychological Bulletin, 70(4), 213\u2013220 (linear/"
        "quadratic weighting; weight convention w_ij=1\u2212|i\u2212j|/(q\u22121) "
        "for linear, w_ij=1\u2212(i\u2212j)\u00b2/(q\u22121)\u00b2 for quadratic, matching "
        "scikit-learn's own internal convention, verified by direct "
        "numerical comparison). Standard error, z, and p-value: Fleiss, "
        "J.L., Cohen, J., & Everitt, B.S. (1969). Large sample standard "
        "errors of kappa and weighted kappa. Psychological Bulletin, "
        "72(5), 323\u2013327, Equation 9 (the null-hypothesis, H0:\u03ba=0 "
        "variance -- this module's exact implementation of Equation 9 was "
        "verified by reproducing the primary source's own worked numerical "
        "example, N=200, to six decimal places, and by external "
        "cross-validation against independent reference statistical software on a real N=86 "
        "dataset). Interpretation benchmarks: Landis, J.R., & Koch, G.G. "
        "(1977). The measurement of observer agreement for categorical "
        "data. Biometrics, 33(1), 159\u2013174."
    )
    # Flag: perfect agreement with zero ASE → z/p undefined (not computable)
    res["kappa_undefined_reason"] = (
        "Sig. (2-tailed) is not computable: agreement is perfect (\u03ba = 1.000) "
        "and ASE = 0, so z = \u03ba / ASE is undefined (division by zero). "
        "This occurs when both raters\u2019 ratings have zero or near-zero "
        "variance (e.g., identical or near-identical scores for every unit). "
        "This is expected behaviour, consistent with standard statistical software, which also reports "
        "this as a system-missing value under these conditions."
        if (not np.isnan(k_std) and abs(k_std - 1.0) < 1e-9 and
            not np.isnan(ase_s) and ase_s < 1e-9)
        else None
    )
    # No CI reported -- the null-hypothesis variance (Fleiss, Cohen &
    # Everitt, 1969, Equation 9) used for z/p above is valid for the
    # significance test but not for confidence-interval construction,
    # which would require Equation 8 (the general-purpose variance,
    # se_general, exposed per-variant above but not currently used to
    # build a reported interval by this module). This mirrors the
    # identical, explicitly disclosed treatment applied to Fleiss' kappa
    # elsewhere in this module.
    res["kappa_ci_lo"] = np.nan
    res["kappa_ci_hi"] = np.nan
    res["kappa_ci_note"] = (
        "No confidence interval is reported. The standard error above "
        "(Fleiss, Cohen & Everitt, 1969, Equation 9) is the null-hypothesis "
        "(H0: kappa=0) variance, valid only for the significance test "
        "(the z and p-value shown), not for quantifying precision or "
        "constructing a confidence interval -- Equation 8 of the same "
        "paper, a distinct general-purpose variance formula the authors "
        "themselves describe as \"useful in setting confidence limits,\" "
        "would be the theoretically appropriate basis for an interval, "
        "and is computed by this module (exposed per-scheme as se_general) "
        "but not currently used to construct a reported confidence "
        "interval. This mirrors the identical, explicitly disclosed "
        "treatment applied to Fleiss' kappa elsewhere in this module "
        "(Gwet, K.L., 2021. Large-sample variance of Fleiss generalized "
        "kappa. Educational and Psychological Measurement, 81(4), "
        "781-799).")
    if dtype == "dichotomous":
        p1 = r1.mean(); p2 = r2.mean()
        res["prevalence_index"] = abs(p1 - p2) / 2
        res["bias_index"]       = (p1 - p2) / 2
    # Linear/quadratic mirrored into legacy top-level keys for backward
    # compatibility with existing UI code -- now populated for EVERY
    # dtype (not only "ordinal" as an earlier revision restricted this
    # to), since weighted kappa is well-defined for any category count.
    for scheme, wk in [("linear", "kappa_linear"), ("quadratic", "kappa_quadratic")]:
        v = variants[scheme]
        res[wk]              = v["kappa"] if not np.isnan(v["kappa"]) else np.nan
        res[f"{wk}_ase"]     = v["se_null"] if not np.isnan(v["se_null"]) else np.nan
        res[f"{wk}_z"]       = v["z"] if not np.isnan(v["z"]) else np.nan
        res[f"{wk}_p"]       = v["p"] if not np.isnan(v["p"]) else np.nan
        res[f"{wk}_label"]   = v["label"]

    # ── Chi-Square Test (standard crosstabulation output) ──────────────────
    try:
        chi2, p_chi2, dof, expected = scipy_stats.chi2_contingency(ct.values)
        n_cells_lt5 = int((expected < 5).sum())
        pct_cells_lt5 = 100 * n_cells_lt5 / expected.size
        res["chi_square"] = {
            "chi2": float(chi2), "df": int(dof),
            "p": float(p_chi2),
            "n_cells_lt5": n_cells_lt5, "pct_cells_lt5": pct_cells_lt5,
            "min_expected": float(expected.min()),
        }
        # Likelihood Ratio (also commonly reported alongside Pearson chi-square)
        with np.errstate(divide="ignore", invalid="ignore"):
            obs = ct.values.astype(float)
            lr = 2 * np.nansum(np.where(obs > 0, obs * np.log(obs / expected), 0))
        res["chi_square"]["lr_chi2"] = float(lr)
        res["chi_square"]["lr_p"]    = float(1 - scipy_stats.chi2.cdf(lr, dof))
    except Exception:
        res["chi_square"] = None

    # ── Symmetric Measures: Correlation (standard crosstabulation output) ──
    # Nominal -> Phi & Cramer's V. Ordinal -> Spearman & Pearson (linear-by-linear).
    sym = {}
    try:
        n_tot = ct.values.sum()
        chi2_v = res["chi_square"]["chi2"] if res.get("chi_square") else np.nan
        if dtype in ("dichotomous", "nominal") and not np.isnan(chi2_v):
            phi = float(np.sqrt(chi2_v / n_tot))
            r_dim, c_dim = ct.shape
            cramers_v = float(np.sqrt(chi2_v / (n_tot * (min(r_dim, c_dim) - 1)))
                              ) if min(r_dim, c_dim) > 1 else np.nan
            sym["phi"]        = phi
            sym["cramers_v"]  = cramers_v if not np.isnan(cramers_v) else np.nan
            sym["chi2_for_phi"] = chi2_v
            sym["phi_p"] = res["chi_square"]["p"] if res.get("chi_square") else np.nan
        if dtype == "ordinal":
            rho, rho_p = scipy_stats.spearmanr(r1, r2)
            pear, pear_p = scipy_stats.pearsonr(r1.astype(float), r2.astype(float))
            sym["spearman_rho"]   = float(rho)
            sym["spearman_rho_p"] = float(rho_p)
            sym["pearson_r"]      = float(pear)
            sym["pearson_r_p"]    = float(pear_p)
    except Exception:
        pass
    res["symmetric_measures"] = sym if sym else None

    return res


def _fleiss_kappa(X, rater_names, alpha=0.05):
    """Fleiss' Kappa for ≥ 3 raters — pure numpy, no statsmodels dependency.
    X shape: (N_units, k_raters) — integer category codes.

    Formula (Fleiss, 1971):
        κ = (P̄ - P̄_e) / (1 - P̄_e)
    where:
        P̄   = mean of per-subject agreement proportions (observed agreement)
        P̄_e = sum of squared marginal proportions (expected by chance)

    IMPORTANT, PEER-REVIEWED FINDING regarding SE/z/p below: this
    function's standard error uses the Fleiss, Nee, & Landis (1979)
    large-sample variance formula -- the same formula widely used across
    major general-purpose statistical software packages, including R's
    "rel" package. Gwet, K.L. (2021). Large-sample variance of
    Fleiss generalized kappa. Educational and Psychological Measurement,
    81(4), 781-799, demonstrates explicitly and formally that this
    specific variance formula "is not meant to be used for quantifying
    the precision of Fleiss' kappa. Instead, it should be used solely
    for testing the hypothesis of zero agreement among raters" (i.e. it
    is valid for the H0: κ=0 significance test reported below, NOT for
    confidence-interval construction around the actual estimated κ).
    This is the exact same theoretical distinction already documented
    for Cohen's kappa elsewhere in this module. Accordingly, NO
    confidence interval is computed or reported for Fleiss' kappa by
    this function -- reporting one from this SE would misrepresent the
    coefficient's true precision, per Gwet's (2021) formal
    demonstration. This function's own implementation of the 1979
    formula was independently verified, both algebraically and by
    direct numerical reconstruction against a real external dataset
    (N=86, k=4 dichotomous raters), to exactly reproduce the standard
    Fleiss et al. (1979) formula as also documented in independent
    technical references -- i.e. this function's SE is confirmed
    correct FOR ITS STATED (null-hypothesis, significance-testing)
    PURPOSE; the absence of a CI is a deliberate, theory-grounded
    omission, not a gap or a defect.

    Primary sources:
    Fleiss, J.L. (1971). Measuring nominal scale agreement among many
    raters. Psychological Bulletin, 76(5), 378-382.
    Fleiss, J.L., Nee, J.C.M., & Landis, J.R. (1979). Large sample
    variance of kappa in the case of different sets of raters.
    Psychological Bulletin, 86(5), 974-977.
    Gwet, K.L. (2021). Large-sample variance of Fleiss generalized
    kappa. Educational and Psychological Measurement, 81(4), 781-799.
    """
    if X.shape[1] < 3:
        return None
    try:
        n, k  = X.shape   # n=units, k=raters
        dtype = _detect_data_type(X.flatten().tolist())
        cats  = sorted(set(int(v) for v in X.flatten().tolist()
                          if not (isinstance(v, float) and np.isnan(v))))
        nc    = len(cats)
        cat_map = {c: i for i, c in enumerate(cats)}

        # Build N × n_categories rating table
        table = np.zeros((n, nc), dtype=int)
        for i in range(n):
            for j in range(k):
                table[i, cat_map[int(X[i, j])]] += 1

        # Marginal proportions p_j
        p_j = table.sum(axis=0) / (n * k)

        # Per-subject agreement P_i
        # P_i = (Σ_j n_ij(n_ij-1)) / (k(k-1))
        P_i = np.array([
            np.sum(table[i] * (table[i] - 1)) / (k * (k - 1))
            for i in range(n)
        ])
        P_bar = P_i.mean()      # overall observed agreement
        P_e   = np.sum(p_j**2) # expected agreement by chance

        if abs(1 - P_e) < 1e-12:
            return None

        kappa_overall = float((P_bar - P_e) / (1 - P_e))

        # SE and z — null-hypothesis (H0: κ=0) large-sample variance,
        # derived from first principles via the exact multinomial
        # moments of P_i under the chance-agreement null model.
        #
        # Derivation: for k raters drawing independently from the
        # marginal distribution {p_j}, let T_i = Σ_j n_ij². Writing
        # T_i = k + 2W_i where W_i counts matching rater-pairs within
        # unit i, and using Cov(match_pair, match_pair') = 0 for
        # vertex-disjoint pairs and (P3 - Pe²) for pairs sharing one
        # rater (P3 = Σ_j p_j³), the exact variance of P_i is:
        #
        #   Var(P_i) = [2/(k(k-1))] · [Pe(1-Pe) + 2(k-2)(P3-Pe²)]
        #
        # and, since P_i are i.i.d. across the N units under H0:
        #
        #   SE₀(κ̂) = sqrt{ Var(P_i) / [N·(1-Pe)²] }
        #
        # Validated: reduces exactly to the standard Cohen's-κ null
        # ASE, sqrt(Pe/(N(1-Pe))), at the k=2 boundary; matches Monte
        # Carlo simulation (200,000 replications) to <0.4% relative
        # error across five test distributions (uniform/skewed,
        # k=2..5, 3–4 categories).
        P3 = float(np.sum(p_j**3))
        var_Pi = (2.0/(k*(k-1))) * (P_e*(1-P_e) + 2*(k-2)*(P3 - P_e**2))
        var_Pi = max(var_Pi, 0.0)          # guard against fp noise
        se  = float(np.sqrt(var_Pi / max(n * (1 - P_e)**2, 1e-12)))
        z   = kappa_overall / se if se > 1e-12 else np.nan
        p   = float(2 * scipy_stats.norm.sf(abs(z))) if not np.isnan(z) else np.nan

        # Per-category κ (Fleiss 1971, eq. 14)
        kappa_per_cat = {}
        p_per_cat     = {}
        for ci, cat in enumerate(cats):
            pj   = p_j[ci]
            num  = (np.sum(table[:, ci] * (table[:, ci] - 1)) / max(n*k*(k-1), 1)) - pj**2
            den  = pj * (1 - pj)
            kappa_per_cat[cat] = float(num/den) if abs(den) > 1e-10 else np.nan
            p_per_cat[cat]     = float(pj)

        names = (rater_names if rater_names and len(rater_names) >= k
                 else [f"Rater {i+1}" for i in range(k)])
        return {
            "n": n, "k": k, "dtype": dtype,
            "categories":  cats,
            "rater_names": names,
            "kappa":       kappa_overall,
            "P_bar":       float(P_bar),   # observed agreement (Po)
            "P_e":         float(P_e),     # expected/chance agreement (Pe)
            "kappa_se":    se if not np.isnan(se) else np.nan,
            "kappa_z":     z if not np.isnan(z) else np.nan,
            # Not rounded here -- preserve precision for genuinely tiny p.
            # (p_per_category above is a marginal PROPORTION, not a p-value
            # -- exact 0 there is legitimate and unrelated to this fix.)
            "kappa_p":     p if not np.isnan(p) else np.nan,
            "kappa_label": kappa_label(kappa_overall),
            # No CI reported -- see docstring: the SE above is the
            # Fleiss et al. (1979) null-hypothesis (H0: kappa=0) variance,
            # formally shown by Gwet (2021, EPM 81(4), 781-799) to be
            # invalid for confidence-interval construction, valid only
            # for the significance test the SE/z/p above already provide.
            "kappa_ci_lo": np.nan,
            "kappa_ci_hi": np.nan,
            "kappa_ci_note": (
                "No confidence interval is reported. The standard error "
                "above (Fleiss, Nee & Landis, 1979 -- the same formula "
                "widely used across major general-purpose statistical "
                "software, including R's \"rel\" package) is valid only for "
                "testing H0: kappa=0 (the z and p-value shown), not for "
                "quantifying precision or constructing a confidence "
                "interval -- a distinction formally demonstrated by "
                "Gwet, K.L. (2021). Large-sample variance of Fleiss "
                "generalized kappa. Educational and Psychological "
                "Measurement, 81(4), 781-799. This mirrors the identical, "
                "already-documented treatment of Cohen's kappa elsewhere "
                "in this module."),
            "kappa_per_category": kappa_per_cat,
            "p_per_category":     p_per_cat,
        }
    except Exception:
        return None


# ══════════════════════════════════════════════════════════════════════════════
# INTERPRETATION HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def alpha_label(a):
    """Descriptive label for a reliability coefficient (George & Mallery, 2003)."""
    if a is None or (isinstance(a, float) and np.isnan(a)):
        return "undefined"
    if a >= 0.9:
        return "excellent"
    if a >= 0.8:
        return "good"
    if a >= 0.7:
        return "acceptable"
    if a >= 0.6:
        return "questionable"
    if a >= 0.5:
        return "poor"
    return "unacceptable"


# ══════════════════════════════════════════════════════════════════════════════
# CORE COEFFICIENTS
# ══════════════════════════════════════════════════════════════════════════════

def _cronbach_alpha(X):
    """Cronbach's alpha from an N x k item matrix (raw)."""
    k = X.shape[1]
    if k < 2:
        return np.nan
    item_var = X.var(axis=0, ddof=1)
    total_var = X.sum(axis=1).var(ddof=1)
    if total_var == 0:
        return np.nan
    return float((k / (k - 1)) * (1 - item_var.sum() / total_var))


def _standardised_alpha(X):
    """Standardised Cronbach's alpha (based on the correlation matrix)."""
    k = X.shape[1]
    if k < 2:
        return np.nan
    R = np.corrcoef(X, rowvar=False)
    iu = np.triu_indices(k, 1)
    rbar = R[iu].mean()
    if np.isnan(rbar):
        return np.nan
    return float(k * rbar / (1 + (k - 1) * rbar))


def _alpha_ci(alpha, n, k, conf=0.95):
    """Feldt (1965) confidence interval for Cronbach's alpha."""
    if alpha is None or np.isnan(alpha) or n < 3:
        return np.nan, np.nan
    a = 1 - conf
    df1 = n - 1
    df2 = (n - 1) * (k - 1)
    try:
        f_lo = scipy_stats.f.ppf(1 - a / 2, df1, df2)
        f_hi = scipy_stats.f.ppf(a / 2, df1, df2)
        lo = 1 - (1 - alpha) * f_lo
        hi = 1 - (1 - alpha) * f_hi
        return float(lo), float(hi)
    except Exception:
        return np.nan, np.nan


def _kr20(X):
    """KR-20 for dichotomous (0/1) items.

    KR-20 is algebraically equivalent to Cronbach's α when all items are
    dichotomous (Kuder & Richardson, 1937). This equivalence requires that
    the item variance be computed as the SAMPLE variance p·q·n/(n−1), not
    the population variance p·q. Using population variance breaks the identity
    and produces a systematic positive bias in KR-20 relative to Cronbach's α.

    Formula (Kuder & Richardson, 1937; Lord & Novick, 1968):
        KR-20 = k/(k−1) · (1 − Σσ²ᵢ / σ²_total)
    where σ²ᵢ = pᵢ·qᵢ·n/(n−1)  [sample variance of dichotomous item i]
          σ²_total = variance of total scores  (ddof=1)

    Returns a dict with:
      kr20            -- the coefficient
      item_p          -- proportion-correct per item (array)
      item_pq_raw     -- RAW population-style p·q per item (array), the
                         textbook/most commonly recognised form of the
                         per-item variance term
      item_pq_sample  -- SAMPLE-corrected p·q·n/(n−1) per item (array),
                         the form that actually enters the KR-20 formula
                         above. item_pq_raw and item_pq_sample are BOTH
                         surfaced (rather than only the sample-corrected
                         form previously returned) because different
                         reference tools conventionally display the raw,
                         uncorrected p·q as the per-item diagnostic value
                         even when the underlying reliability formula
                         itself uses the sample-corrected version
                         internally -- showing both avoids a researcher
                         being unable to reconcile a displayed p·q figure
                         against an external reference's own p·q column,
                         despite the final KR-20 value itself matching.
    """
    n, k = X.shape
    if k < 2:
        return {"kr20": np.nan, "item_p": np.array([]),
                "item_pq_raw": np.array([]), "item_pq_sample": np.array([])}
    p  = X.mean(axis=0)               # proportion correct per item
    q  = 1 - p
    pq_raw = p * q                    # RAW population-style p·q
    # Sample variance for dichotomous item: p·q·n/(n−1)
    # This is equivalent to X[:,j].var(ddof=1) for 0/1 items, and guarantees
    # KR-20 = Cronbach's α exactly for dichotomous data.
    pq_sample = pq_raw * n / (n - 1)  # sample variance, NOT population p·q
    total_var  = X.sum(axis=1).var(ddof=1)
    if total_var == 0:
        return {"kr20": np.nan, "item_p": p,
                "item_pq_raw": pq_raw, "item_pq_sample": pq_sample}
    kr = float((k / (k - 1)) * (1 - pq_sample.sum() / total_var))
    return {"kr20": kr, "item_p": p,
            "item_pq_raw": pq_raw, "item_pq_sample": pq_sample}


def _kr21(X):
    """Kuder-Richardson Formula 21 (Kuder & Richardson, 1937).

    A simplified, more conservative form of KR-20 that assumes EQUAL
    item difficulty across all items (every item's true p equals the
    same p̄), avoiding the need to compute each item's individual p
    separately -- historically valuable before computers made per-item
    computation routine. Uses only the mean and variance of total scores.

    Formula (Kuder & Richardson, 1937, exact -- verified against the
    formula as they themselves present it, and independently confirmed
    by exact numerical reconstruction against an external reference
    calculator's output on a real dataset, N=86, k=4: removing an
    earlier, undocumented n/(n-1) sample-correction factor that had
    been added to this implementation reproduced the external
    reference's value to within 9x10^-6):
        KR-21 = [k/(k−1)] × [1 − M(k−M) / (k·σ²_total)]
    where M = mean of total scores (sample), σ²_total = sample variance
    (ddof=1) of total scores, k = number of items. Unlike KR-20
    (Section on _kr20), this formula applies NO further sample-size
    correction to the M(k-M)/k term -- KR-21's entire simplifying
    purpose is to require only the total-score mean and variance, with
    no per-item computation at all, so it has no per-item p*q term for
    a sample-variance correction to apply to in the first place. An
    earlier revision of this function incorrectly multiplied M(k-M) by
    an additional n/(n-1) factor, reasoning by analogy to KR-20's own
    item-level correction -- this was not verified against the primary
    source before being added, and was found, when tested against an
    external reference implementation, to be unsupported: the
    uncorrected formula (as shown above, and as already stated in this
    docstring prior to that revision) is the one that reproduces
    external reference values exactly.

    This is the KR-20 formula with every item's p·q·n/(n−1) term replaced
    by the SAME value, M(k−M)/k -- i.e., substituting the
    average item difficulty p̄=M/k uniformly for every item's individual
    pᵢ. By Jensen's inequality (p(1-p) is concave), the RAW (uncorrected)
    per-item terms satisfy Σpᵢqᵢ ≤ k·p̄q̄ -- so on a MATCHED basis (both
    raw, or both sample-corrected), KR-21 ≤ KR-20 always, with equality
    only when items are genuinely equally difficult.

    IMPORTANT, PRECISE SCOPE (verified by direct construction of a
    counter-example, then confirmed to vanish at large n): because this
    function's KR-21 correctly uses the UNCORRECTED M(k-M)/k term (per
    the primary source and external validation -- see below), while
    _kr20() correctly uses the SAMPLE-CORRECTED Σpᵢqᵢ·n/(n-1) term (per
    the separately, independently proven Bernoulli-variance identity
    that Section on _kr20 relies on), the two formulas are being
    compared on DIFFERENT bases for finite n. The n/(n-1) correction
    factor -> 1 as n -> infinity, so KR-21 <= KR-20 holds as an
    asymptotic property and holds in practice for typical sample sizes,
    but a small, finite-sample violation is mathematically possible
    (confirmed by direct construction: n=86 can produce a violation on
    the order of 0.003-0.004; n=2000 constructions tested did not
    produce any violation in 20 trials). This is not an implementation
    error in either formula -- both are individually correct and
    externally validated on their own terms -- but a genuine
    consequence of comparing a sample-corrected quantity (KR-20) against
    an uncorrected one (KR-21), which the classical Jensen's-inequality
    argument above does not, by itself, account for.

    Reference: Kuder, G.F., & Richardson, M.W. (1937). The theory of the
    estimation of test reliability. Psychometrika, 2(3), 151–160.
    """
    n, k = X.shape
    if k < 2:
        return np.nan
    total = X.sum(axis=1)
    M = float(total.mean())
    var_total = float(total.var(ddof=1))
    if var_total == 0:
        return np.nan
    kr21 = (k / (k - 1)) * (1 - (M * (k - M)) / (k * var_total))
    return float(kr21)


def _sem(sd_total, reliability):
    """Standard Error of Measurement (SEM).

    Estimates the standard deviation of measurement error expected
    around a single respondent's observed total score, under classical
    test theory -- widely used to construct approximate confidence
    bands around an individual score (e.g., observed ± 1.96·SEM).

    Formula: SEM = SD_total × √(1 − reliability)

    where SD_total is the observed (sample) standard deviation of total
    scores, and 'reliability' is a reliability coefficient for the same
    scale (conventionally KR-20 or Cronbach's α, whichever is the
    primary headline estimate for the analysis at hand).

    Reference: Lord, F.M., & Novick, M.R. (1968). Statistical Theories
    of Mental Test Scores. Addison-Wesley, Chapter 3. [Foundational
    classical-test-theory source for this formula; also presented in,
    e.g., Crocker, L., & Algina, J. (1986). Introduction to Classical
    and Modern Test Theory. Holt, Rinehart and Winston.]
    """
    if reliability is None or (isinstance(reliability, float) and np.isnan(reliability)):
        return np.nan
    if reliability > 1 or (1 - reliability) < 0:
        return np.nan  # SEM undefined when reliability exceeds 1 (see KR-20 out-of-range note)
    return float(sd_total * np.sqrt(1 - reliability))


def _is_dichotomous(X):
    """True if every item takes at most two distinct values (0/1-like)."""
    for j in range(X.shape[1]):
        u = np.unique(X[:, j])
        if len(u) > 2:
            return False
    return True


def _split_half_for_indices(X, idx1, idx2):
    """Core split-half computation for an ARBITRARY partition of item
    indices into two groups. Used by all three split-half variants
    (first-second, odd-even, maximum) so the underlying formula is
    defined and verified in exactly one place.

    Reference: Spearman (1910), Brown (1910) — equal-length correction;
    Guttman (1945) — unequal-variance split-half formula.
    """
    X1 = X[:, idx1]; X2 = X[:, idx2]
    h1 = X1.sum(axis=1); h2 = X2.sum(axis=1)
    try:
        r = np.corrcoef(h1, h2)[0, 1]
    except Exception:
        r = np.nan
    sb = (2 * r / (1 + r)) if not np.isnan(r) else np.nan
    var1 = h1.var(ddof=1); var2 = h2.var(ddof=1)
    vart = X.sum(axis=1).var(ddof=1)
    guttman = (4 * r * np.sqrt(var1 * var2) / vart) if (vart > 0 and not np.isnan(r)) else np.nan
    a1 = _cronbach_alpha(X1) if X1.shape[1] >= 2 else np.nan
    a2 = _cronbach_alpha(X2) if X2.shape[1] >= 2 else np.nan
    return {"error": False,
            "spearman_brown": float(sb) if not np.isnan(sb) else np.nan,
            "guttman": float(guttman) if not np.isnan(guttman) else np.nan,
            "r_halves": float(r) if not np.isnan(r) else np.nan,
            "alpha_part1": float(a1) if not np.isnan(a1) else np.nan,
            "alpha_part2": float(a2) if not np.isnan(a2) else np.nan,
            "n_part1": len(idx1), "n_part2": len(idx2)}


def _bootstrap_ci_percentile(X, compute_fn, n_boot=1000, alpha=0.05, seed=42,
                              min_valid=20):
    """General-purpose percentile bootstrap confidence interval for any
    reliability coefficient computed directly from an N x k item matrix.

    Resamples RESPONDENTS (rows) with replacement, recomputes
    compute_fn(X_boot) on each resample, and returns the percentile-based
    interval [100*alpha/2, 100*(1-alpha/2)] of the resulting bootstrap
    distribution.

    This is the method explicitly recommended, following an extensive
    review of alternatives, by Kelley, K., & Pornprasertmanit, S. (2016).
    Confidence intervals for population reliability coefficients:
    Evaluation of methods, recommendations, and software for composite
    measures. Psychological Methods, 21(1), 69-92 -- who recommend
    bootstrapping for both alpha- and omega-type reliability
    coefficients over competing analytic approaches. A Monte Carlo
    comparison of six omega-CI methods (see e.g. the applied literature
    citing this recommendation) found bootstrap methods have the best
    coverage performance specifically for the smaller sample sizes
    common in applied reliability research (N<100).

    Appropriate ONLY for coefficients whose per-replicate computational
    cost is small and does not itself involve a combinatorial search or
    iterative optimization that scales unfavourably with k (item count)
    -- i.e. NOT for Guttman's lambda4, the maximum-Spearman-Brown
    split-half variant, or McDonald's omega-hierarchical, all three of
    which require a dedicated, cost-aware bootstrap strategy
    (`_bootstrap_ci_fixed_search`) instead.

    Uses a fixed random seed for reproducibility, matching the existing
    convention already established for Krippendorff's alpha's own
    bootstrap CI elsewhere in this module.

    Returns dict: ci_lo, ci_hi, n_boot_valid, method="bootstrap".
    Returns NaN bounds if fewer than `min_valid` replicates succeed
    (e.g. due to degenerate resamples).
    """
    n = X.shape[0]
    rng = np.random.default_rng(seed)
    boot_vals = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, size=n)
        X_boot = X[idx, :]
        try:
            val = compute_fn(X_boot)
            if val is not None and not (isinstance(val, float) and np.isnan(val)):
                boot_vals.append(float(val))
        except Exception:
            continue
    if len(boot_vals) < min_valid:
        return {"ci_lo": np.nan, "ci_hi": np.nan,
                "n_boot_valid": len(boot_vals), "n_boot_requested": n_boot,
                "method": "bootstrap_insufficient_replicates"}
    boot_arr = np.array(boot_vals)
    ci_lo = float(np.percentile(boot_arr, 100 * alpha / 2))
    ci_hi = float(np.percentile(boot_arr, 100 * (1 - alpha / 2)))
    return {"ci_lo": ci_lo, "ci_hi": ci_hi,
            "n_boot_valid": len(boot_vals), "n_boot_requested": n_boot,
            "method": "bootstrap"}


# Threshold (number of items, k) below which a full, per-replicate
# re-optimization bootstrap is computationally practical (benchmarked
# empirically: k=12 completes 1000 replicates in well under 15 seconds
# for lambda4, the maximum-Spearman-Brown split, and omega-hierarchical
# alike; k=14-18 scale to several minutes or worse for these three
# coefficients specifically, since each involves either a combinatorial
# search over 2^(k-1)-1 partitions or an iterative oblique-rotation
# optimization whose cost grows with the number of extracted factors).
_BOOTSTRAP_SEARCH_K_THRESHOLD = 12


def _bootstrap_ci_fixed_search(X, k, search_and_compute_fn,
                                recompute_given_result_fn,
                                n_boot=1000, alpha=0.05, seed=42,
                                min_valid=20,
                                k_threshold=_BOOTSTRAP_SEARCH_K_THRESHOLD):
    """Bootstrap confidence interval for coefficients whose point
    estimate requires an expensive per-call search or iterative
    optimization (Guttman's lambda4, the maximum-Spearman-Brown
    split-half variant, and McDonald's omega-hierarchical) -- for which
    a naive percentile bootstrap that re-runs the full search on every
    replicate does not scale to realistic item counts (benchmarked: k=18
    naive bootstrap projects to 35-135+ minutes for these coefficients,
    versus ~1 second for a simple closed-form statistic at the same k).

    Two regimes, selected automatically by k:

      k <= k_threshold (default 12): FULL bootstrap. The expensive
        search/optimization (`search_and_compute_fn`) is re-run on every
        bootstrap replicate, exactly as it is for the point estimate --
        the most rigorous option, used whenever it remains
        computationally practical (benchmarked well under 15 seconds for
        1000 replicates at k=12 for all three affected coefficients).

      k > k_threshold: FIXED-SEARCH bootstrap. The expensive
        search/optimization is run ONCE, on the original (full) sample,
        to find the best partition (lambda4, split-half maximum) or
        rotated factor solution (omega-hierarchical). This result is
        then held FIXED, and each bootstrap replicate only recomputes
        the coefficient's VALUE given that fixed partition/solution on
        the resampled data (`recompute_given_result_fn`) -- a cheap
        operation with no search involved, restoring bootstrap speed to
        that of a simple closed-form statistic.

        IMPORTANT, DISCLOSED LIMITATION: this fixed-search CI answers
        "how precise is this coefficient's value, GIVEN the partition/
        solution already found on this sample" -- not "how precise
        would the coefficient be if the optimal partition/solution were
        also re-selected in every hypothetical repeated sample." This is
        a standard, named simplification in the bootstrap literature for
        statistics involving a search or selection step (sometimes
        discussed under "post-selection inference"); it is not
        presented as equivalent in rigor to the full bootstrap used for
        k <= k_threshold, and the application discloses which of the two
        methods was used in every case, rather than presenting both
        identically.

    Returns dict: ci_lo, ci_hi, n_boot_valid, method
    ("bootstrap_full_search" or "bootstrap_fixed_search"), k_threshold.
    """
    n = X.shape[0]
    rng = np.random.default_rng(seed)
    if k <= k_threshold:
        boot_vals = []
        for _ in range(n_boot):
            idx = rng.integers(0, n, size=n)
            X_boot = X[idx, :]
            try:
                val = search_and_compute_fn(X_boot)
                if val is not None and not (isinstance(val, float) and np.isnan(val)):
                    boot_vals.append(float(val))
            except Exception:
                continue
        method = "bootstrap_full_search"
    else:
        try:
            fixed_result = search_and_compute_fn(X, return_search_result=True)
        except TypeError:
            fixed_result = search_and_compute_fn(X)
        boot_vals = []
        for _ in range(n_boot):
            idx = rng.integers(0, n, size=n)
            X_boot = X[idx, :]
            try:
                val = recompute_given_result_fn(X_boot, fixed_result)
                if val is not None and not (isinstance(val, float) and np.isnan(val)):
                    boot_vals.append(float(val))
            except Exception:
                continue
        method = "bootstrap_fixed_search"
    if len(boot_vals) < min_valid:
        return {"ci_lo": np.nan, "ci_hi": np.nan,
                "n_boot_valid": len(boot_vals), "n_boot_requested": n_boot,
                "method": method + "_insufficient_replicates",
                "k_threshold": k_threshold}
    boot_arr = np.array(boot_vals)
    ci_lo = float(np.percentile(boot_arr, 100 * alpha / 2))
    ci_hi = float(np.percentile(boot_arr, 100 * (1 - alpha / 2)))
    return {"ci_lo": ci_lo, "ci_hi": ci_hi,
            "n_boot_valid": len(boot_vals), "n_boot_requested": n_boot,
            "method": method, "k_threshold": k_threshold}


def _lambda4_given_split(X, Vt, best_split):
    """Recomputes Guttman's lambda4's value for a PRE-DETERMINED split
    (item indices in group A), without searching -- the cheap companion
    to `_lambda4_exhaustive`, used by `_bootstrap_ci_fixed_search` for
    k > 12 (see that function's docstring for the full rationale)."""
    k = X.shape[1]
    idx1 = list(best_split)
    idx2 = [i for i in range(k) if i not in idx1]
    h1 = X[:, idx1].sum(axis=1)
    h2 = X[:, idx2].sum(axis=1)
    return 2 * (1 - (h1.var(ddof=1) + h2.var(ddof=1)) / Vt)


def _spearman_brown_given_split(X, best_split):
    """Recomputes the Spearman-Brown split-half value for a PRE-
    DETERMINED split, without searching -- the cheap companion to
    `_max_spearman_brown_split_exhaustive`."""
    k = X.shape[1]
    idx1 = list(best_split)
    idx2 = [i for i in range(k) if i not in idx1]
    h1 = X[:, idx1].sum(axis=1)
    h2 = X[:, idx2].sum(axis=1)
    r_corr = np.corrcoef(h1, h2)[0, 1]
    if np.isnan(r_corr):
        return np.nan
    return 2 * r_corr / (1 + r_corr)


def _split_half(X):
    """Split-half reliability, THREE variants, all built on the same
    verified core (_split_half_for_indices):

      1. First-second half split (PRIMARY / always shown) — items 1..k/2
         vs k/2+1..k. Numerically validated against an independent
         external reference calculator to <0.0001 on a real reference
         dataset; this remains the headline result, unchanged.
      2. Odd-even split (supplementary) — odd-indexed vs even-indexed
         items, the classical alternative split convention.
      3. Maximum split-half (supplementary) — the split that maximises
         the Spearman-Brown coefficient specifically, via its own
         independent exhaustive search (_max_spearman_brown_split_
         exhaustive). This matches what external tools such as R's
         psych::splitHalf() report as "maximum split-half reliability".

    IMPORTANT (verified during development): the split that maximises
    Guttman's lambda4 (variance-ratio formula) is NOT always the same
    split that maximises the Spearman-Brown coefficient — confirmed on
    a real reference dataset where the two criteria selected genuinely
    different splits. This function therefore performs its OWN
    Spearman-Brown-maximising search for the "maximum" variant, rather
    than reusing lambda4's optimal split — reusing it would silently
    under-report the true achievable maximum Spearman-Brown value and
    mislabel it. lambda4's own (separately reported, in the Guttman's
    Lambda section) result remains the correct maximiser of ITS OWN
    variance-ratio criterion.

    MANDATORY GATE: split-half analysis requires a minimum of 4 items
    (see docstring history: Spearman-Brown's equal-length assumption is
    not meaningful below 4 items). Applies to all three variants.
    """
    k = X.shape[1]
    if k < 4:
        err = {"error": True, "message": "Split-half analysis requires at least 4 items.",
               "n_items": k, "spearman_brown": np.nan, "guttman": np.nan}
        return {"error": True, "message": err["message"], "n_items": k,
                "spearman_brown": np.nan, "guttman": np.nan,
                "first_second": err, "odd_even": err, "maximum": err}

    half = k // 2
    first_second = _split_half_for_indices(X, list(range(half)), list(range(half, k)))

    idx = np.arange(k)
    odd_even = _split_half_for_indices(X, list(idx[idx % 2 == 0]), list(idx[idx % 2 == 1]))

    sb_max_result = _max_spearman_brown_split_exhaustive(X)
    if sb_max_result.get("best_split") is not None:
        best_idx1 = list(sb_max_result["best_split"])
        best_idx2 = [i for i in range(k) if i not in best_idx1]
        maximum = _split_half_for_indices(X, best_idx1, best_idx2)
        maximum["method"] = sb_max_result["method"]
    else:
        maximum = dict(first_second)
        maximum["method"] = "unavailable"

    # Top-level keys mirror first_second for backward compatibility with
    # existing callers that expect the flat (pre-refactor) structure.
    out = dict(first_second)
    out["error"] = False
    out["first_second"] = first_second
    out["odd_even"] = odd_even
    out["maximum"] = maximum
    return out


def _sample_random_partitions(k, n_samples, seed=42):
    """Generates n_samples random, non-trivial partitions of k items into
    two non-empty groups, as a boolean indicator matrix (True = group A).

    Each item is independently assigned to group A or B via an unbiased
    coin flip; any degenerate draw (all items in one group) is redrawn.
    This is the random-sampling methodology used, for exactly this
    problem, by Revelle, W. psych::splitHalf() -- see the calling
    functions' docstrings for the full citation and rationale.

    Returns: boolean ndarray of shape (n_samples, k).
    """
    rng = np.random.default_rng(seed)
    indicator = rng.random((n_samples, k)) < 0.5
    degenerate = indicator.all(axis=1) | (~indicator).all(axis=1)
    redraws = 0
    while degenerate.any() and redraws < 20:
        n_deg = int(degenerate.sum())
        indicator[degenerate] = rng.random((n_deg, k)) < 0.5
        degenerate = indicator.all(axis=1) | (~indicator).all(axis=1)
        redraws += 1
    return indicator


def _best_partition_vectorized(X, indicator, criterion, Vt=None):
    """Vectorized evaluation of every partition (row) in `indicator`
    (an (n_partitions, k) boolean matrix -- either the full exhaustive
    set or a random sample from `_sample_random_partitions`) at once,
    via matrix operations, avoiding a per-partition Python loop.

    criterion: "variance_ratio" (Guttman's lambda4) or "correlation"
    (Spearman-Brown-maximizing split-half).

    Returns: (best_value, best_partition_item_indices_tuple, n_evaluated)
    """
    n_partitions = indicator.shape[0]
    indicator_f = indicator.astype(np.float64)
    H1 = X @ indicator_f.T                      # (n, n_partitions)
    total = X.sum(axis=1)
    H2 = total[:, None] - H1
    if criterion == "variance_ratio":
        var_h1 = H1.var(axis=0, ddof=1)
        var_h2 = H2.var(axis=0, ddof=1)
        vals = 2 * (1 - (var_h1 + var_h2) / Vt)
    else:  # "correlation" -- Spearman-Brown from the h1/h2 correlation
        H1c = H1 - H1.mean(axis=0, keepdims=True)
        H2c = H2 - H2.mean(axis=0, keepdims=True)
        num = (H1c * H2c).sum(axis=0)
        den = np.sqrt((H1c ** 2).sum(axis=0) * (H2c ** 2).sum(axis=0))
        with np.errstate(divide="ignore", invalid="ignore"):
            r = np.where(den > 1e-12, num / den, np.nan)
            vals = np.where(np.isnan(r), -np.inf, 2 * r / (1 + r))
    vals = np.nan_to_num(vals, nan=-np.inf)
    best_idx = int(np.argmax(vals))
    best_partition = tuple(np.where(indicator[best_idx])[0].tolist())
    return float(vals[best_idx]), best_partition, n_partitions


def _lambda4_exhaustive(X, Vt, max_exhaustive_k=16):
    """Guttman's lambda4: the TRUE maximum split-half coefficient over
    all possible non-trivial splits of k items into two groups.

    Reference: Guttman, L. (1945). A basis for analyzing test-retest
    reliability. Psychometrika, 10(4), 255-282.

    For k items there are 2^(k-1) - 1 distinct non-trivial splits (A vs
    B is the same partition as B vs A, so the naive 2^k - 2 count is
    halved). This is exhaustively searched whenever k <= max_exhaustive_k.

    THRESHOLD AND FALLBACK METHOD, both aligned with established
    precedent: R's widely-used psych package switches its own
    splitHalf() function from exhaustive search to random sampling at
    the SAME general item-count threshold used here ("only sample
    splits if the number of possible splits exceeds 10,000 ... more
    than 16 items in a scale" -- psych package NEWS documentation), and
    an independently developed package for exactly this problem
    (splithalf, Parsons, Kruijt, & Fox et al.) uses the same random-
    sampling philosophy. This function follows that same precedent
    rather than a cruder single-split (e.g. even/odd) approximation:
    for k > max_exhaustive_k, `n_boot`-many random, non-trivial
    partitions are sampled (default 15,000, matching the sample count
    used in more recent psych::splitHalf versions) and the best value
    found among the SAMPLE is reported -- explicitly labelled "sampled"
    in the returned method field, never presented as the guaranteed
    true maximum. Sampling is vectorized (a single matrix operation
    across all sampled partitions at once, per `_best_partition_vectorized`)
    rather than a per-partition Python loop, keeping this fast regardless
    of k (unlike exhaustive search, whose cost grows as 2^(k-1)).

    Reference for the sampling methodology: Revelle, W. (2024). psych:
    Procedures for Psychological, Psychometric, and Personality Research
    [R package], splitHalf() function and package NEWS.

    Returns dict: {"lambda4": float, "method": "exhaustive"|"sampled",
    "n_splits_evaluated": int, "best_split": (tuple of item indices in
    group A) or None}.
    """
    k = X.shape[1]
    if k < 2 or Vt <= 0:
        return {"lambda4": np.nan, "method": "n/a", "n_splits_evaluated": 0, "best_split": None}

    if k <= max_exhaustive_k:
        best_l4 = -np.inf
        best_split = None
        n_eval = 0
        # only need combinations of size 1..k//2 to avoid double-counting
        # (size k-r is the complement of size r)
        for r in range(1, k // 2 + 1):
            for combo in itertools.combinations(range(k), r):
                # skip the mirror-image duplicate when k is even and r==k/2
                if k % 2 == 0 and r == k // 2 and 0 not in combo:
                    continue
                idx1 = list(combo)
                idx2 = [i for i in range(k) if i not in combo]
                h1 = X[:, idx1].sum(axis=1)
                h2 = X[:, idx2].sum(axis=1)
                l4_split = 2 * (1 - (h1.var(ddof=1) + h2.var(ddof=1)) / Vt)
                n_eval += 1
                if l4_split > best_l4:
                    best_l4 = l4_split
                    best_split = tuple(idx1)
        return {"lambda4": float(best_l4), "method": "exhaustive",
                "n_splits_evaluated": n_eval, "best_split": best_split}
    else:
        n_sample = 15000
        indicator = _sample_random_partitions(k, n_sample, seed=42)
        best_l4, best_split, n_eval = _best_partition_vectorized(
            X, indicator, criterion="variance_ratio", Vt=Vt)
        return {"lambda4": best_l4, "method": "sampled",
                "n_splits_evaluated": n_eval, "best_split": best_split}


def _max_spearman_brown_split_exhaustive(X, max_exhaustive_k=16):
    """Finds the split that maximises the SPEARMAN-BROWN (correlation-
    based) split-half coefficient specifically — NOT the same target as
    Guttman's lambda4 (variance-ratio) maximisation.

    IMPORTANT, verified during development: the split that maximises
    Guttman's lambda4 formula (2*(1-(Va+Vb)/Vt)) is NOT guaranteed to be
    the same split that maximises the Spearman-Brown formula (2r/(1+r))
    when item variances are heterogeneous — confirmed on a real
    reference dataset where the two criteria selected genuinely
    different "best" splits (lambda4-optimal: items {1,2} vs {3,4};
    SB-optimal: item {3} alone vs {1,2,4}). Reusing lambda4's optimal
    split to report a "maximum" Spearman-Brown value would silently
    under-report the true achievable maximum and mislabel it. This
    function performs its own independent search so that "maximum
    Spearman-Brown split-half" is reported honestly against its own
    actual optimisation target.

    THRESHOLD AND FALLBACK METHOD, both aligned with established
    precedent: R's widely-used psych package switches its own
    splitHalf() function from exhaustive search to random sampling at
    the SAME general item-count threshold used here ("only sample
    splits if the number of possible splits exceeds 10,000 ... more
    than 16 items in a scale" -- psych package NEWS documentation), and
    an independently developed package for exactly this problem
    (splithalf, Parsons, Kruijt, & Fox et al.) uses the same random-
    sampling philosophy. For k > max_exhaustive_k, this function
    likewise switches to random sampling (15,000 non-trivial partitions
    by default, vectorized via `_best_partition_vectorized` rather than
    a per-partition Python loop) instead of a cruder single-split
    (even/odd) approximation, explicitly labelled "sampled" in the
    returned method field.

    Reference: Revelle, W. (2024). psych: Procedures for Psychological,
    Psychometric, and Personality Research (splitHalf function docs and
    package NEWS); Spearman (1910); Brown (1910).
    """
    k = X.shape[1]
    if k < 4:
        return {"spearman_brown": np.nan, "method": "n/a",
                "n_splits_evaluated": 0, "best_split": None}
    if k <= max_exhaustive_k:
        best_sb = -np.inf
        best_split = None
        n_eval = 0
        for r in range(1, k // 2 + 1):
            for combo in itertools.combinations(range(k), r):
                if k % 2 == 0 and r == k // 2 and 0 not in combo:
                    continue
                idx1 = list(combo)
                idx2 = [i for i in range(k) if i not in combo]
                h1 = X[:, idx1].sum(axis=1)
                h2 = X[:, idx2].sum(axis=1)
                try:
                    r_corr = np.corrcoef(h1, h2)[0, 1]
                    sb = 2 * r_corr / (1 + r_corr) if not np.isnan(r_corr) else -np.inf
                except Exception:
                    sb = -np.inf
                n_eval += 1
                if sb > best_sb:
                    best_sb = sb
                    best_split = tuple(idx1)
        return {"spearman_brown": float(best_sb), "method": "exhaustive",
                "n_splits_evaluated": n_eval, "best_split": best_split}
    else:
        n_sample = 15000
        indicator = _sample_random_partitions(k, n_sample, seed=42)
        best_sb, best_split, n_eval = _best_partition_vectorized(
            X, indicator, criterion="correlation")
        return {"spearman_brown": best_sb, "method": "sampled",
                "n_splits_evaluated": n_eval, "best_split": best_split}


def _guttman_lambdas_fast_only(X):
    """Computes ONLY lambda1, lambda2, lambda3, lambda5, lambda6 -- the
    five Guttman-lambda forms that are genuinely closed-form and fast
    at any item count (benchmarked: 1000 evaluations at k=18 complete
    in well under 0.2 seconds total).

    Deliberately EXCLUDES lambda4 (the true-maximum split-half
    coefficient), which requires an exhaustive combinatorial search and
    is the ENTIRE reason `_guttman_lambdas_single_basis` becomes slow at
    large k (benchmarked: lambda4 alone accounts for ~99% of that
    function's total runtime at k=18). This function exists specifically
    so the five fast lambdas can be bootstrapped via
    `_bootstrap_ci_percentile` without incurring lambda4's search cost on
    every one of potentially 1000 replicates -- lambda4's own confidence
    interval is instead computed via `_bootstrap_ci_fixed_search`
    (Guttman's lambda4 point-estimate computation, `_guttman_lambdas_single_basis`,
    is otherwise unchanged and still computes all six forms together for
    the point estimate itself).

    Reference: Guttman, L. (1945). Psychometrika, 10(4), 255-282.
    """
    k = X.shape[1]
    if k < 2:
        return {"lambda1": np.nan, "lambda2": np.nan, "lambda3": np.nan,
                "lambda5": np.nan, "lambda6": np.nan}
    try:
        C = np.cov(X, rowvar=False, ddof=1)
        Vt = X.sum(axis=1).var(ddof=1)
        if Vt <= 0:
            return {"lambda1": np.nan, "lambda2": np.nan, "lambda3": np.nan,
                    "lambda5": np.nan, "lambda6": np.nan}
        item_var = np.diag(C)
        offdiag = C - np.diag(item_var)

        l1 = 1 - item_var.sum() / Vt
        l3 = (k / (k - 1)) * l1
        sum_sq_off = np.sum(offdiag ** 2)
        l2 = l1 + np.sqrt((k / (k - 1)) * sum_sq_off) / Vt
        try:
            Rinv = np.linalg.inv(np.corrcoef(X, rowvar=False))
            smc = 1 - 1 / np.diag(Rinv)
            e = item_var * (1 - smc)
            l6 = 1 - e.sum() / Vt
        except Exception:
            l6 = np.nan
        col_sq = np.sum(offdiag ** 2, axis=0)
        l5 = l1 + 2 * np.sqrt(np.max(col_sq)) / Vt

        return {"lambda1": float(l1), "lambda2": float(l2), "lambda3": float(l3),
                "lambda5": float(l5), "lambda6": float(l6) if not np.isnan(l6) else np.nan}
    except Exception:
        return {"lambda1": np.nan, "lambda2": np.nan, "lambda3": np.nan,
                "lambda5": np.nan, "lambda6": np.nan}


def _guttman_lambdas_single_basis(X):
    """Guttman's lambda1..lambda6, computed from whichever matrix X is
    passed in. Calling this with raw item scores gives the RAW
    (covariance-based) lambda family; calling it with column-standardised
    (z-scored, unit-variance) item scores gives the STANDARDISED
    (correlation-based) lambda family. This is the same formula family
    in both cases — only the input basis differs.

    Reference: Guttman, L. (1945). Psychometrika, 10(4), 255-282,
    Equations as individually cited per coefficient below.
    """
    k = X.shape[1]
    out = {f"lambda{i}": np.nan for i in range(1, 7)}
    out["lambda4_method"] = "n/a"
    out["lambda4_n_splits"] = 0
    if k < 2:
        return out
    try:
        C = np.cov(X, rowvar=False, ddof=1)
        Vt = X.sum(axis=1).var(ddof=1)
        if Vt <= 0:
            return out
        item_var = np.diag(C)
        sum_item_var = item_var.sum()
        offdiag = C - np.diag(item_var)

        # lambda1 (Guttman, 1945, Eq. 1) — weakest lower bound
        l1 = 1 - sum_item_var / Vt
        out["lambda1"] = float(l1)

        # lambda3 (Guttman, 1945, Eq. 3) — algebraically identical to
        # Cronbach's alpha on this same basis
        l3 = (k / (k - 1)) * l1
        out["lambda3"] = float(l3)

        # lambda2 (Guttman, 1945, Eq. 2) — improves on lambda1 using the
        # off-diagonal covariance structure
        sum_sq_off = np.sum(offdiag ** 2)
        l2 = l1 + np.sqrt((k / (k - 1)) * sum_sq_off) / Vt
        out["lambda2"] = float(l2)

        # lambda4 (Guttman, 1945, Eq. 4) — TRUE maximum split-half,
        # via exhaustive search (see _lambda4_exhaustive)
        l4_result = _lambda4_exhaustive(X, Vt)
        out["lambda4"] = l4_result["lambda4"]
        out["lambda4_method"] = l4_result["method"]
        out["lambda4_n_splits"] = l4_result["n_splits_evaluated"]

        # lambda6 (Guttman, 1945, Eq. 6) — uses squared multiple
        # correlation (SMC) to isolate unique/error variance per item
        try:
            Rinv = np.linalg.inv(np.corrcoef(X, rowvar=False))
            smc = 1 - 1 / np.diag(Rinv)
            e = item_var * (1 - smc)
            l6 = 1 - e.sum() / Vt
            out["lambda6"] = float(l6)
        except Exception:
            out["lambda6"] = np.nan

        # lambda5 (Guttman, 1945, Eq. 5)
        # λ5 = λ1 + 2·√(e**) / Vt, e** = max_j(Σ_{i≠j} s²_ij)
        col_sq = np.sum(offdiag ** 2, axis=0)
        l5 = l1 + 2 * np.sqrt(np.max(col_sq)) / Vt
        out["lambda5"] = float(l5)

        # ── Dimensionality signal: Kaiser eigenvalue criterion ───────────
        # An earlier version of this function attempted a "lambda4 minus
        # mean of other lambdas" gap as a multidimensionality heuristic.
        # This was tested via Monte Carlo simulation (100 replications
        # each) and found NOT to discriminate reliably: under a
        # genuinely unidimensional null, the gap has mean ~0.08 (90th
        # percentile ~0.10) purely from lambda4's inherent selection
        # bias (it is defined as the MAXIMUM over many candidate splits,
        # which is systematically inflated relative to non-maximised
        # bounds even with no true sub-structure present) -- and this
        # null distribution substantially overlaps the distribution
        # observed under genuine 2-cluster bifactor data (mean ~0.11).
        # A simple gap threshold could not be found that discriminates
        # the two scenarios reliably, so it was NOT shipped as a flag.
        #
        # Instead, this reports the number of eigenvalues > 1 (Kaiser,
        # 1960) of the inter-item correlation matrix -- the same,
        # separately-validated criterion already used to gate whether
        # omega_hierarchical is computable. This is informational, not
        # a pass/fail flag: more than one eigenvalue > 1 suggests
        # possible multidimensionality worth following up (e.g. via the
        # omega_hierarchical result, if available, or a dedicated EFA),
        # but is not by itself definitive.
        try:
            R_for_eig = np.corrcoef(X, rowvar=False)
            eigvals = np.linalg.eigvalsh(R_for_eig)[::-1]
            out["n_eigenvalues_above_1"] = int(np.sum(eigvals > 1.0))
        except Exception:
            out["n_eigenvalues_above_1"] = None
    except Exception:
        pass
    return out


def _guttman_lambdas(X):
    """Guttman's lambda1..lambda6, reported on BOTH the raw-covariance
    basis and the standardised-correlation basis.

    IMPORTANT: these are NOT two different theories or two different
    families of coefficient. This is the same Guttman (1945) lambda
    family, computed on two different, both-legitimate measurement
    bases. The two sets will generally differ whenever item variances
    are heterogeneous — the more item SDs differ from one another, the
    larger the raw-vs-standardised gap typically is. Neither basis is
    "more correct" in the abstract: use the raw basis when the original
    item-scale differences are substantively meaningful; use the
    standardised basis when items should be equalised (unit variance)
    before combination (e.g. items measured on different scales).

    Returns a dict with keys "raw" and "standardized", each holding a
    full lambda1..lambda6 (+ lambda4 method metadata) sub-dict from
    _guttman_lambdas_single_basis(). Top-level lambda1..lambda6 keys are
    ALSO populated (mirroring "raw") for backward compatibility with
    existing callers that expect the flat structure.
    """
    raw = _guttman_lambdas_single_basis(X)
    k = X.shape[1]
    if k >= 2:
        sd = X.std(axis=0, ddof=1)
        sd_safe = np.where(sd > 1e-12, sd, 1.0)
        X_std = (X - X.mean(axis=0)) / sd_safe
    else:
        X_std = X
    standardized = _guttman_lambdas_single_basis(X_std)
    out = dict(raw)  # backward-compat: top-level keys mirror raw basis
    out["raw"] = raw
    out["standardized"] = standardized
    return out


def _item_total_stats(X, item_names, alpha_full):
    """Corrected item-total correlation, alpha-if-deleted, scale stats."""
    k = X.shape[1]
    total = X.sum(axis=1)
    rows = []
    for j in range(k):
        rest = total - X[:, j]
        try:
            cit = np.corrcoef(X[:, j], rest)[0, 1]
        except Exception:
            cit = np.nan
        # alpha if item j deleted
        Xd = np.delete(X, j, axis=1)
        a_del = _cronbach_alpha(Xd) if Xd.shape[1] >= 2 else np.nan
        # squared multiple correlation (item j predicted by the rest)
        try:
            Rinv = np.linalg.inv(np.corrcoef(X, rowvar=False))
            smc = 1 - 1 / np.diag(Rinv)
            smc_j = float(smc[j])
        except Exception:
            smc_j = np.nan
        rows.append({
            "Item": item_names[j],
            "Scale Mean if Item Deleted": float((total - X[:, j]).mean()),
            "Scale Variance if Item Deleted": float(rest.var(ddof=1)),
            "Corrected Item-Total Correlation": cit if not np.isnan(cit) else np.nan,
            "Squared Multiple Correlation": smc_j if not np.isnan(smc_j) else np.nan,
            "Cronbach's Alpha if Item Deleted": a_del if not np.isnan(a_del) else np.nan,
        })
    df = pd.DataFrame(rows)
    # Flag negative alpha-if-deleted values (footnote "a")
    df.attrs["has_negative_alpha"] = bool(
        (df["Cronbach's Alpha if Item Deleted"] < 0).any())
    return df


def _paf_single_factor(R, max_iter=300, tol=1e-9):
    """Iterated Principal Axis Factoring, single common factor.

    Reference: classical iterative principal-factor method (see e.g.
    Gorsuch, 1983, Factor Analysis, 2nd ed., Ch.5). Communalities are
    initialised via SMC (squared multiple correlation = 1 - 1/diag(R^-1))
    and refined iteratively until convergence:
      1. Replace R's diagonal with current communality estimates h².
      2. Eigendecompose the reduced matrix; take the largest
         eigenvalue/eigenvector as the factor loading: λ = sqrt(e1)·v1.
      3. Update h² = λ², repeat until h² stabilises.

    This is a genuine common-factor extraction (unlike PCA, which uses
    the unreduced correlation matrix with 1s on the diagonal) — it
    partitions each item's variance into common (factor-explained) and
    unique components, which is what McDonald's omega formula requires.

    Handles the k=2 case (SMC undefined via matrix inverse for a 2x2
    correlation matrix) with the well-defined closed form h² = r_12².

    Returns (loadings, communalities) as 1-D arrays of length k.
    """
    k = R.shape[0]
    if k == 2:
        h2 = np.array([R[0, 1] ** 2, R[0, 1] ** 2])
    else:
        Rinv = np.linalg.inv(R)
        h2 = np.clip(1 - 1 / np.diag(Rinv), 0.0, 0.999)
    loading = np.zeros(k)
    for _ in range(max_iter):
        R_reduced = R.copy()
        np.fill_diagonal(R_reduced, h2)
        vals, vecs = np.linalg.eigh(R_reduced)
        idx = np.argmax(vals)
        loading = vecs[:, idx] * np.sqrt(max(vals[idx], 0.0))
        if loading.sum() < 0:
            loading = -loading
        h2_new = np.clip(loading ** 2, 0.0, 0.999)
        if np.max(np.abs(h2_new - h2)) < tol:
            h2 = h2_new
            break
        h2 = h2_new
    return loading, h2


def _paf_multi_factor(R, m, max_iter=500, tol=1e-9):
    """Iterated Principal Axis Factoring, m>1 common factors (unrotated).
    Same iterative-communality principle as _paf_single_factor, extended
    to retain the m largest eigenvalue/eigenvector pairs per iteration.
    Returns (pattern matrix k×m, communalities length-k)."""
    k = R.shape[0]
    Rinv = np.linalg.inv(R)
    h2 = np.clip(1 - 1 / np.diag(Rinv), 0.0, 0.999)
    L = np.zeros((k, m))
    for _ in range(max_iter):
        R_reduced = R.copy()
        np.fill_diagonal(R_reduced, h2)
        vals, vecs = np.linalg.eigh(R_reduced)
        idx = np.argsort(vals)[::-1][:m]
        L = vecs[:, idx] * np.sqrt(np.clip(vals[idx], 0.0, None))
        h2_new = np.clip(np.sum(L ** 2, axis=1), 0.0, 0.999)
        if np.max(np.abs(h2_new - h2)) < tol:
            h2 = h2_new
            break
        h2 = h2_new
    return L, h2


def _gpa_oblimin(A, max_iter=5000, tol=1e-9):
    """Oblique rotation via the Gradient Projection Algorithm, direct
    oblimin criterion (gamma=0, i.e. direct quartimin — the standard
    default oblique rotation used by R's psych::fa() and most major
    EFA software).

    Reference: Bernaards, C.A. & Jennrich, R.I. (2005). Gradient
    Projection Algorithms and Software for Arbitrary Rotation Criteria
    in Factor Analysis. Educational and Psychological Measurement,
    65(5), 676-696.

    Input: A (k×m) unrotated loading matrix from _paf_multi_factor.
    Returns: (pattern matrix k×m, factor correlation matrix Φ m×m).

    Verified (see project audit records): gradient converges to ~0,
    result is invariant to the rotation starting point, and the rotated
    solution reproduces the correlation matrix with error identical to
    the unrotated solution (pure reparameterisation, no information
    loss) — confirmed on synthetic bifactor data with known structure.
    """
    k, m = A.shape
    T = np.eye(m)
    alpha = 1.0

    def _crit(L):
        L2 = L ** 2
        N = np.ones((m, m)) - np.eye(m)
        return np.sum(L2 * (L2 @ N)) / 4, L * (L2 @ N)

    Tinv = np.linalg.inv(T)
    L = A @ Tinv.T
    Q, Gq = _crit(L)
    for _ in range(max_iter):
        G = -(L.T @ Gq @ Tinv).T
        Gp = G - T @ np.diag(np.sum(T * G, axis=0))
        s = np.linalg.norm(Gp)
        if s < tol:
            break
        alpha = 2 * alpha
        for _ in range(30):
            Tt = T - alpha * Gp
            v = 1 / np.sqrt(np.sum(Tt ** 2, axis=0))
            Tt = Tt @ np.diag(v)
            Tinv_t = np.linalg.inv(Tt)
            Lt = A @ Tinv_t.T
            Qt, Gqt = _crit(Lt)
            if Qt < Q - 0.5 * s ** 2 * alpha:
                break
            alpha = alpha / 2
        T, L, Q, Gq = Tt, Lt, Qt, Gqt
        Tinv = Tinv_t
    return L, T.T @ T


def _schmid_leiman(Pattern, Phi):
    """Schmid-Leiman bifactor transformation of an oblique multi-factor
    EFA solution into an orthogonalised general factor + orthogonalised
    group/specific factors.

    Reference: Schmid, J. & Leiman, J.M. (1957). The development of
    hierarchical factor solutions. Psychometrika, 22(1), 53-61.
    Applied to omega-hierarchical specifically: Zinbarg, R.E., Revelle,
    W., Yovel, I., & Li, W. (2005). Cronbach's alpha, Revelle's beta,
    and McDonald's omega_H: their relations with each other and two
    alternative conceptualizations of reliability. Psychometrika, 70(1),
    123-133; McDonald, R.P. (1999), Test Theory: A Unified Treatment.

    Procedure:
      1. A second single-factor PAF extraction is applied to Φ itself
         (the group-factor correlation matrix) to obtain each group
         factor's own loading g_j on a general (second-order) factor.
         This must use the SAME iterated-communality PAF procedure as
         the first-order extraction, not a raw eigendecomposition of Φ
         (whose diagonal is 1, not a reduced/communality diagonal) —
         using the raw diagonal was verified during development to
         produce an invalid decomposition (Φ not correctly reproduced).
      2. General-factor item loadings: G = Pattern @ g
      3. Specific/group-factor item loadings (orthogonalised against the
         general factor): S[:,j] = Pattern[:,j] * sqrt(1 - g_j²)

    Verified identity (see project audit records): G_i² + Σⱼ S_ij²
    exactly reproduces each item's original communality from the
    first-order solution, and G@G' + S@S' + diag(uniqueness) reproduces
    the correlation matrix with error identical to the original
    (Pattern, Φ) solution — confirming this is an exact, information-
    preserving reparameterisation.

    Returns (G: general loadings length-k, S: specific loadings k×m,
    g: group-factor-on-general loadings length-m).
    """
    m = Pattern.shape[1]
    if m == 2:
        g, _ = _paf_single_factor(Phi)
    else:
        g, _ = _paf_single_factor(Phi)
    G = Pattern @ g
    if G.sum() < 0:
        G = -G
        g = -g
    S = Pattern * np.sqrt(np.clip(1 - g ** 2, 0.0, None))[None, :]
    return G, S, g


def _mcdonald_omega(X, item_names=None):
    """McDonald's Omega, unidimensional model (\u03c9u), via iterated
    Principal Axis Factoring — computed on BOTH denominator bases
    described in the primary literature.

    Reference (primary, for this exact distinction): Flora, D.B. (2020).
    Your coefficient alpha is probably wrong, but which coefficient
    omega is right? A tutorial on using R to obtain better reliability
    estimates. Advances in Methods and Practices in Psychological
    Science, 3(4), 484-501. https://doi.org/10.1177/2515245920951747
    Foundational reference: McDonald, R.P. (1999). Test Theory: A
    Unified Treatment. Erlbaum.

    Flora (2020) shows that \u03c9u = (\u03a3\u03bbj)\u00b2 / \u03c3\u0302X\u00b2, where the
    denominator \u03c3\u0302X\u00b2 "can be calculated either as the sample
    variance of the total score X or as the model-implied variance of
    X" (Flora, 2020, p. 488) — i.e. \u03c9u is ONE coefficient computable
    on two different, both-legitimate variance bases, not two
    differently-named coefficients. This function reports both:

      omega_model_implied: \u03c3\u0302X\u00b2 = (\u03a3\u03bbj)\u00b2 + \u03a3(1-\u03bbj\u00b2), the
        variance implied BY the fitted one-factor model itself (sum of
        modelled common + modelled unique variance). Matches the rows
        labelled "omega"/"omega2" in R's semTools::reliability().

      omega_observed: \u03c3\u0302X\u00b2 = the ACTUAL observed total-score
        variance (k + 2\u00b7\u03a3 off-diagonal correlations for standardised
        items), independent of how well the one-factor model fits.
        Matches the row labelled "omega3" in semTools::reliability().

    Flora's footnote 7 explicitly warns that some software documentation
    (and Kelley & Pornprasertmanit, 2016) mislabel the observed-variance
    form "hierarchical omega" — this is avoided here: "omega
    hierarchical" (\u03c9h) is reserved exclusively for the bifactor-model
    estimate (see _mcdonald_omega_hierarchical), consistent with most of
    the psychometric literature (Zinbarg et al., 2005; Rodriguez, Reise,
    & Haviland, 2016).

    When the one-factor model fits the data well, the two bases give
    near-identical values (Flora, 2020, footnote 4); a large gap between
    them is itself diagnostic of one-factor model misfit (Bentler, 2009;
    Kelley & Pornprasertmanit, 2016).

    METHODOLOGICAL NOTE (historical correction): an earlier version of
    this function derived loadings from the first principal COMPONENT of
    the raw correlation matrix (PCA), which does not partition variance
    into common vs unique components and cannot validly be labelled a
    McDonald's omega estimate. This function uses iterated Principal
    Axis Factoring, a genuine common-factor extraction. Verified on a
    real reference dataset (N=86, k=4): loadings matched an independent
    external reference calculator to 3-4 decimal places.

    Returns a dict with omega_model_implied, omega_observed, "omega"
    (backward-compatible alias for omega_observed — see rationale in
    docstring of the caller in run_reliability), plus full item-level
    decomposition (loading, communality, unique variance per item).
    Returns NaN/empty arrays if k < 3 or computation fails.
    """
    k = X.shape[1]
    names = item_names if item_names and len(item_names) >= k else [f"Item {i+1}" for i in range(k)]
    empty = {"omega": np.nan, "omega_model_implied": np.nan, "omega_observed": np.nan,
             "loadings": np.array([]), "communalities": np.array([]),
             "unique_variances": np.array([]), "item_names": names}
    if k < 3:
        return empty
    try:
        R = np.corrcoef(X, rowvar=False)
        loading, comm = _paf_single_factor(R)
        err = 1 - comm
        Vt_observed = k + 2 * np.sum(np.triu(R, 1))
        Vt_model_implied = float(loading.sum() ** 2 + err.sum())
        omega_observed = float(loading.sum() ** 2 / Vt_observed) if Vt_observed > 1e-9 else np.nan
        omega_model_implied = (float(loading.sum() ** 2 / Vt_model_implied)
                                if Vt_model_implied > 1e-9 else np.nan)
        return {"omega": omega_observed,  # backward-compatible alias
                "omega_observed": omega_observed,
                "omega_model_implied": omega_model_implied,
                "loadings": loading,
                "communalities": comm,
                "unique_variances": err,
                "item_names": names}
    except Exception:
        return empty


def _mcdonald_omega_hierarchical(X, item_names=None, min_items=6, max_iter_note=True,
                                  max_rotation_iter=None):
    """McDonald's Omega Hierarchical (ωh) via Schmid-Leiman bifactor
    transformation.

    Reference: McDonald, R.P. (1999). Test Theory: A Unified Treatment.
    Erlbaum; Schmid, J. & Leiman, J.M. (1957). Psychometrika, 22(1),
    53-61; Zinbarg, Revelle, Yovel & Li (2005). Psychometrika, 70(1),
    123-133.

    max_rotation_iter: if None (default), the oblique rotation
    (`_gpa_oblimin`) uses its own default max_iter (5000), unchanged
    from prior behaviour -- used for the point estimate. If an integer
    is supplied, this caps the rotation's iteration budget, bounding
    worst-case per-call time; used specifically by the bootstrap
    confidence-interval mechanism (`_bootstrap_ci_fixed_search`), since
    bootstrap-resampled covariance structures were found to occasionally
    require far more rotation iterations to converge than the original
    (non-resampled) sample, causing highly variable, sometimes very slow
    per-replicate cost that is NOT simply a function of item count k.

    ωh answers a different question than ωt: it isolates the proportion
    of total variance attributable specifically to a single general
    factor common to all items, as distinct from ωt's "how much total
    variance is systematic at all" (general + group-specific combined).
    ωh is always <= ωt (within the same bifactor decomposition) because
    it credits only the general-factor component of common variance.

    ωh should NOT automatically replace ωt as the default headline
    reliability statistic: most applications (unidimensional or
    short scales) are adequately summarised by ωt alone, and ωh
    specifically answers a multidimensionality-aware question that is
    only meaningful when a genuine general-plus-group-factor structure
    exists in the data.

    GATING (honesty over forced computation): a bifactor structure
    requires at least two extractable group factors, each with enough
    items to be identified. This function requires:
      (a) k >= min_items (default 6) -- with fewer items, a 2+ group
          factor oblique rotation is under-identified / unstable.
      (b) The number of eigenvalues > 1 (Kaiser criterion) in R is >= 2
          -- if only one factor is substantively supported by the data,
          there is no second group factor to extract, and ωh is not a
          meaningful quantity for this construct (it should be reported
          as "not computable", not forced to a possibly-unstable value).
    If either condition fails, ωh is reported as unavailable with an
    explicit, honest reason -- never silently omitted or approximated.

    Returns a dict: {"omega_h": float or nan, "computable": bool,
    "reason": str, "n_factors_used": int, "general_loadings": array,
    "specific_loadings": array (k×m), "item_names": list}
    """
    k = X.shape[1]
    names = item_names if item_names and len(item_names) >= k else [f"Item {i+1}" for i in range(k)]
    base = {"omega_h": np.nan, "computable": False, "reason": "", "n_factors_used": 0,
            "general_loadings": np.array([]), "specific_loadings": np.array([]),
            "item_names": names}
    if k < min_items:
        base["reason"] = (f"Omega hierarchical requires at least {min_items} items to "
                           f"support an identifiable bifactor (general + group-factor) "
                           f"structure; this construct has {k}.")
        return base
    try:
        R = np.corrcoef(X, rowvar=False)
        vals = np.linalg.eigvalsh(R)[::-1]
        n_factors = int(np.sum(vals > 1.0))
        if n_factors < 2:
            base["reason"] = (f"Only {n_factors} eigenvalue(s) of the inter-item "
                               f"correlation matrix exceed 1.0 (Kaiser criterion); the "
                               f"data support a single dominant factor, not a "
                               f"multi-group-factor bifactor structure. Omega "
                               f"hierarchical is not a meaningful quantity for an "
                               f"essentially unidimensional construct — use omega "
                               f"total (\u03c9t) instead.")
            return base
        m = min(n_factors, k // 3)   # practical cap: keep >=3 items/factor on average
        m = max(m, 2)
        Pattern, comm_mf = _paf_multi_factor(R, m)
        Pattern_rot, Phi = _gpa_oblimin(
            Pattern, max_iter=max_rotation_iter if max_rotation_iter is not None else 5000)
        G, S, g_on_groups = _schmid_leiman(Pattern_rot, Phi)
        Vt_observed = k + 2 * np.sum(np.triu(R, 1))
        if Vt_observed <= 1e-9:
            base["reason"] = "Total observed variance is degenerate (near zero)."
            return base
        omega_h = float(G.sum() ** 2 / Vt_observed)
        omega_t_bifactor = float((G.sum() ** 2 + np.sum(S.sum(axis=0) ** 2)) / Vt_observed)
        return {"omega_h": omega_h, "computable": True,
                "reason": (f"Estimated via a {m}-factor oblique PAF extraction "
                            f"(direct oblimin rotation) followed by Schmid-Leiman "
                            f"bifactor transformation."),
                "n_factors_used": m,
                "general_loadings": G, "specific_loadings": S,
                "omega_t_bifactor": omega_t_bifactor,
                "item_names": names}
    except Exception as e:
        base["reason"] = f"Omega hierarchical could not be estimated ({type(e).__name__})."
        return base


def _icc_if_deleted(X, item_names):
    """ICC(C,k) recomputed with each item removed in turn — diagnostic
    analogue of "Cronbach's alpha if item deleted" (see _item_total_stats),
    applied to the Internal-Consistency-context primary ICC metric.

    OPTIMIZATION (found necessary during unrelated bootstrap-CI
    development work, when testing at larger item counts k revealed this
    function as an unexpected, pre-existing performance bottleneck):
    rather than recomputing ALL SIX ICC forms via pingouin's
    intraclass_corr() for each of the k item-deleted scenarios --
    pingouin's own pandas-heavy DataFrame construction made each such
    call take roughly 0.9-1 second, so the full loop scaled to ~k
    seconds, e.g. ~14.5s at k=15 -- this function instead computes
    Cronbach's alpha directly (pure NumPy, effectively instantaneous)
    for each reduced item set, relying on the PROVEN mathematical
    identity ICC(C,k) = Cronbach's alpha (both equal (MSB-MSE)/MSB from
    the same two-way ANOVA decomposition; already documented and relied
    upon elsewhere in this module's ICC section). Verified to agree with
    pingouin's own ICC(C,k) output to machine precision (~1e-16 absolute
    difference) before this change was made. This is a pure speed
    optimization with NO change to the reported values.

    For each item j, the k-1 remaining items are re-submitted and the
    ICC(C,k)-equivalent value is extracted. This lets a user identify
    which specific item, if dropped, would most improve (or most harm)
    the two-way-consistency reliability estimate — the same diagnostic
    purpose as alpha-if-deleted, applied to the ANOVA-based estimator
    (identical in value to Cronbach's alpha for this specific ICC form).

    Returns a DataFrame with columns ["Item", "ICC(C,k) if Item Deleted"],
    or an empty DataFrame if k < 4 (need at least 3 remaining items for a
    meaningful ICC(C,k) on the reduced matrix).
    """
    k = X.shape[1]
    rows = []
    if k < 4:
        return pd.DataFrame(columns=["Item", "ICC(C,k) if Item Deleted"])
    for j in range(k):
        Xd = np.delete(X, j, axis=1)
        try:
            val = _cronbach_alpha(Xd)
            if isinstance(val, float) and np.isnan(val):
                val = np.nan
        except Exception:
            val = np.nan
        rows.append({"Item": item_names[j], "ICC(C,k) if Item Deleted": val})
    return pd.DataFrame(rows)


def _icc(X, item_names):
    """Intraclass correlation (all six standard forms) via pingouin.

    Pingouin ICC type mapping (Shrout & Fleiss, 1979):
        ICC(A,1)  = two-way random, absolute agreement, single rater   [common notation: ICC(2,1)]
        ICC(A,k)  = two-way random, absolute agreement, mean of k raters [common notation: ICC(2,k)]
        ICC(C,1)  = two-way mixed, consistency, single rater             [common notation: ICC(3,1)]
        ICC(C,k)  = two-way mixed, consistency, mean of k raters         [common notation: ICC(3,k)]
        ICC(1,1)  = one-way random, single rater                         [common notation: ICC(1,1)]

    Returns DataFrame or None when data is degenerate.
    """
    if pg is None:
        return None
    try:
        if float(np.var(X)) < 1e-12:
            return None
        item_vars = np.var(X, axis=0)
        row_vars  = np.var(X, axis=1)
        if (item_vars < 1e-12).any() or (row_vars < 1e-12).all():
            return None
        n, k = X.shape
        long = pd.DataFrame({
            "target": np.repeat(np.arange(n), k),
            "rater":  np.tile(np.arange(k), n),
            "score":  X.flatten(),
        })
        res = pg.intraclass_corr(data=long, targets="target",
                                 raters="rater", ratings="score")
        # Normalise CI column name (older pingouin: CI95%, newer: CI95)
        ci_col = next((c for c in ["CI95%", "CI95"] if c in res.columns), None)
        cols = ["Type", "ICC", "F", "df1", "df2", "pval"]
        if ci_col:
            cols.append(ci_col)
        out = res[cols].copy()
        if ci_col and ci_col != "CI95%":
            out = out.rename(columns={ci_col: "CI95%"})
        if out["ICC"].isna().all():
            return None
        # Round ICC and F for display-adjacent convenience, but NOT pval:
        # pval must retain full floating-point precision here. Rounding it
        # to 3dp at the engine level would silently convert any genuinely
        # tiny p-value (e.g. 3.1e-10 for a very large F-statistic — entirely
        # plausible with strong rater agreement) into a literal 0.0 float,
        # which is statistically dishonest (p is never exactly zero) and
        # indistinguishable downstream from "value not computed". Display
        # -time rounding/thresholding is the sole responsibility of the
        # _p() formatter in utils/formatters.py.
        for col in ["ICC", "F"]:
            if col in out.columns:
                out[col] = out[col].apply(
                    lambda v: float(v) if pd.notna(v) else np.nan)
        return out
    except Exception:
        return None


def _parse_icc_df(icc_df):
    """Parse pingouin ICC DataFrame into named dict.
    Uses correct pingouin type names: ICC(A,1), ICC(A,k), ICC(C,1), ICC(C,k).
    Maps pingouin type names to the common ICC(2,1), ICC(2,k), ICC(3,1), ICC(3,k) notation.
    """
    if icc_df is None or not isinstance(icc_df, pd.DataFrame):
        return None

    def _get(itype):
        row = icc_df[icc_df["Type"] == itype]
        if row.empty:
            return np.nan, np.nan, np.nan, np.nan
        v  = float(row["ICC"].iloc[0])
        p  = float(row["pval"].iloc[0]) if "pval" in row.columns else np.nan
        ci = row["CI95%"].iloc[0] if "CI95%" in row.columns else [np.nan, np.nan]
        if isinstance(ci, str):
            # Parse string like "[-0.32, 0.15]"
            try:
                parts = ci.strip("[]").split(",")
                lo, hi = float(parts[0]), float(parts[1])
            except Exception:
                lo, hi = np.nan, np.nan
        elif hasattr(ci, "__len__") and len(ci) >= 2:
            lo, hi = float(ci[0]), float(ci[1])
        else:
            lo, hi = np.nan, np.nan
        return v, p, lo, hi

    # NOTE: values are returned at FULL floating-point precision here.
    # Rounding was previously applied at this parsing stage (round to 3dp
    # for ICC/CI, 4dp for p) — this silently converted any genuinely tiny
    # but nonzero p-value (e.g. 3.1e-10, entirely plausible with a large
    # F-statistic under strong rater agreement) into a literal 0.0 float,
    # which downstream code cannot distinguish from "not computed" and
    # which is statistically dishonest to report as an exact zero. All
    # display-time rounding and near-zero thresholding is now the sole
    # responsibility of the _f()/_p() formatters in utils/formatters.py,
    # which already implement correct "< .00001"-style threshold notation.
    def _lbl(v):
        if isinstance(v, float) and np.isnan(v): return "—"
        if v < 0.50: return "Poor (<0.50)"
        if v < 0.75: return "Moderate (0.50–0.75)"
        if v < 0.90: return "Good (0.75–0.90)"
        return "Excellent (>0.90)"

    # All 6 ICC forms from pingouin (Shrout & Fleiss, 1979):
    # ICC(1,1) = one-way random, single rater
    # ICC(A,1) = two-way random, absolute agreement, single rater  [PRIMARY]
    # ICC(C,1) = two-way mixed, consistency, single rater
    # ICC(1,k) = one-way random, mean of k raters
    # ICC(A,k) = two-way random, absolute agreement, mean of k raters
    # ICC(C,k) = two-way mixed, consistency, mean of k raters
    i11, p11, l11, h11 = _get("ICC(1,1)")
    i21, p21, l21, h21 = _get("ICC(A,1)")
    i31, p31, l31, h31 = _get("ICC(C,1)")
    i1k, p1k, l1k, h1k = _get("ICC(1,k)")
    i2k, p2k, l2k, h2k = _get("ICC(A,k)")
    i3k, p3k, l3k, h3k = _get("ICC(C,k)")

    return {
        "icc_df":           icc_df,
        # ICC(1,1) — one-way random, single rater
        "icc_1_1":          i11, "icc_1_1_p":     p11,
        "icc_1_1_ci_lo":    l11, "icc_1_1_ci_hi": h11,
        "icc_1_1_label":    _lbl(i11),
        # ICC(A,1) — two-way random, absolute agreement, single rater [PRIMARY]
        "icc_2_1":          i21, "icc_2_1_p":     p21,
        "icc_2_1_ci_lo":    l21, "icc_2_1_ci_hi": h21,
        "icc_2_1_label":    _lbl(i21),
        # ICC(C,1) — two-way mixed, consistency, single rater
        "icc_3_1":          i31, "icc_3_1_p":     p31,
        "icc_3_1_ci_lo":    l31, "icc_3_1_ci_hi": h31,
        "icc_3_1_label":    _lbl(i31),
        # ICC(1,k) — one-way random, mean of k raters
        "icc_1_k":          i1k, "icc_1_k_p":     p1k,
        "icc_1_k_ci_lo":    l1k, "icc_1_k_ci_hi": h1k,
        "icc_1_k_label":    _lbl(i1k),
        # ICC(A,k) — two-way random, absolute agreement, mean of k raters
        "icc_2_k":          i2k, "icc_2_k_p":     p2k,
        "icc_2_k_ci_lo":    l2k, "icc_2_k_ci_hi": h2k,
        "icc_2_k_label":    _lbl(i2k),
        # ICC(C,k) — two-way mixed, consistency, mean of k raters
        "icc_3_k":          i3k, "icc_3_k_p":     p3k,
        "icc_3_k_ci_lo":    l3k, "icc_3_k_ci_hi": h3k,
        "icc_3_k_label":    _lbl(i3k),
        "interpretation_text": "",  # filled by caller
        "formula_note": (
            "Pingouin intraclass_corr (Shrout & Fleiss, 1979). "
            "ICC(2,1) [pingouin: ICC(A,1)]: two-way random effects, absolute agreement, single rater — "
            "PRIMARY index: use when each unit is rated by the same raters drawn randomly from a larger pool. "
            "ICC(2,k) [pingouin: ICC(A,k)]: absolute agreement for mean of k raters — "
            "use when you will average all raters' scores in practice. "
            "ICC(3,1) [pingouin: ICC(C,1)]: two-way mixed, consistency, single rater — "
            "use when the same fixed set of raters rates all units (no random sampling of raters). "
            "ICC(3,k) [pingouin: ICC(C,k)]: consistency for mean of k raters. "
            "Absolute agreement (ICC2) is stricter: it penalises systematic rater bias. "
            "Consistency (ICC3) does not. "
            "95% CI via F-distribution. "
            "Benchmarks — Koo & Li (2016): <0.50 Poor; 0.50–0.75 Moderate; "
            "0.75–0.90 Good; >0.90 Excellent."),
    }


# ══════════════════════════════════════════════════════════════════════════════
# REVERSE-ITEM HANDLING
# ══════════════════════════════════════════════════════════════════════════════

def _reverse(X, method, scale_min=None, scale_max=None, which=None):
    """Return a copy of X with the selected columns reversed."""
    Xr = X.astype(float).copy()
    which = which if which is not None else range(X.shape[1])
    info = []
    for j in which:
        col = Xr[:, j]
        if method == "theoretical" and scale_min is not None and scale_max is not None:
            Xr[:, j] = (scale_min + scale_max) - col
            info.append((j, f"({scale_min} + {scale_max}) \u2212 x"))
        elif method == "observed":
            mn, mx = col.min(), col.max()
            Xr[:, j] = (mn + mx) - col
            info.append((j, f"({mn:g} + {mx:g}) \u2212 x [observed]"))
        elif method == "zscore":
            sd = col.std(ddof=1)
            Xr[:, j] = -((col - col.mean()) / sd) if sd > 0 else col
            info.append((j, "\u2212z(x)"))
    return Xr, info


# ══════════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT (single construct)
# ══════════════════════════════════════════════════════════════════════════════

def run_reliability(matrix, item_names, alpha=0.05, construct_name="Construct",
                    reverse_method=None, reverse_items=None,
                    scale_min=None, scale_max=None,
                    compute_bootstrap_ci=False, n_boot_ic=1000,
                    compute_omega_h=False):
    """Run reliability analysis on one construct (item matrix).

    compute_omega_h : bool, default False
        When True, computes McDonald's omega-hierarchical (Section 4.3.4).
        Defaults to False (skipped) because investigation found its
        oblique-rotation extraction can take substantial, unpredictable
        time for certain data structures (observed: single point-estimate
        calls ranging from milliseconds to over ten seconds depending on
        the specific data realization, not reliably predictable from item
        count k or a fixed iteration cap alone) -- this protects the
        speed of every other coefficient in this module, none of which
        share this issue, for the default analysis run. The interactive
        Web interface explicitly opts in, behind its own loading
        indicator and an explicit warning that computation may take
        several seconds, when the user requests this specific coefficient.

    compute_bootstrap_ci : bool, default False
        When True, additionally computes bootstrap confidence intervals
        for Guttman's lambda family (all 6 forms, both bases), all three
        Split-Half variants, and McDonald's omega-u (both bases) --
        Section 4.3-4.5 CI additions. Defaults to False (skipped
        entirely) because this computation, while individually fast per
        coefficient, is meaningfully slower in aggregate across the ~15
        distinct bootstrap runs involved (empirically: roughly 15-35
        seconds total, depending on item count k) than the base
        reliability computation without it (a fraction of a second) --
        callers that do not need these confidence intervals (including
        the permanent automated test suite's existing coverage of other
        functionality) should not silently pay this cost. The
        interactive Web interface explicitly opts in via this parameter,
        shown behind its own loading indicator (Section: UI), when the
        user is viewing results for a construct where these coefficients
        apply.

    n_boot_ic : int, default 1000
        Bootstrap replicate count used when compute_bootstrap_ci=True.

    Parameters
    ----------
    matrix : array-like (N, k)  -- listwise-complete numeric item scores
    item_names : list[str], length k
    alpha : float -- significance level for CIs (default 0.05 -> 95%)
    construct_name : str
    reverse_method : {None,'theoretical','observed','zscore'}
    reverse_items : list[int] | None -- indices to reverse; None = auto-detect
    scale_min, scale_max : numbers (for 'theoretical')

    Returns
    -------
    dict
    """
    X = np.asarray(matrix, dtype=float)
    mask = ~np.isnan(X).any(axis=1)
    X = X[mask]
    N, k = X.shape
    item_names = list(item_names)
    conf = 1 - alpha
    pct = int(conf * 100)

    # ── Detect reverse items (negative corrected item-total correlation) ──
    flagged = []
    total = X.sum(axis=1)
    for j in range(k):
        rest = total - X[:, j]
        try:
            cit = np.corrcoef(X[:, j], rest)[0, 1]
            if cit < 0:
                flagged.append(item_names[j])
        except Exception:
            pass

    # ── Apply reversal if requested ──
    reverse_info = []
    if reverse_method:
        if reverse_items is None:
            # auto: reverse the flagged items
            idx = [item_names.index(v) for v in flagged]
        else:
            idx = reverse_items
        if idx:
            X, rinfo = _reverse(X, reverse_method, scale_min, scale_max, idx)
            reverse_info = [(item_names[j], f) for j, f in rinfo]

    # ── Coefficients (each protected) ──
    results = {}
    try: results["alpha"] = _cronbach_alpha(X)
    except Exception: results["alpha"] = np.nan
    try: results["alpha_std"] = _standardised_alpha(X)
    except Exception: results["alpha_std"] = np.nan
    try: results["alpha_ci"] = _alpha_ci(results["alpha"], N, k, conf)
    except Exception: results["alpha_ci"] = (np.nan, np.nan)
    try:
        results["dichotomous"] = _is_dichotomous(X)
        if results["dichotomous"]:
            _kr_res = _kr20(X)
            results["kr20"]           = _kr_res["kr20"]
            results["item_p"]         = _kr_res["item_p"]      # proportion correct per item
            results["item_pq"]        = _kr_res["item_pq_sample"]  # backward-compat alias
            results["item_pq_raw"]    = _kr_res["item_pq_raw"]
            results["item_pq_sample"] = _kr_res["item_pq_sample"]
            results["kr21"]           = _kr21(X)
        else:
            results["kr20"] = np.nan
            results["kr21"] = np.nan
            results["item_p"]  = np.array([])
            results["item_pq"] = np.array([])
            results["item_pq_raw"]    = np.array([])
            results["item_pq_sample"] = np.array([])
    except Exception:
        results["dichotomous"] = False; results["kr20"] = np.nan; results["kr21"] = np.nan
    try: results["lambdas"] = _guttman_lambdas(X)
    except Exception: results["lambdas"] = {}
    try:
        results["split_half"] = _split_half(X)
    except Exception:
        results["split_half"] = {}
    try:
        _omega_detail = _mcdonald_omega(X, item_names)
        results["omega"]        = _omega_detail["omega"]          # scalar (backward compat)
        results["omega_detail"] = _omega_detail                    # full per-item breakdown
    except Exception:
        results["omega"] = np.nan
        results["omega_detail"] = {"omega": np.nan, "omega_model_implied": np.nan,
                                    "omega_observed": np.nan, "loadings": np.array([]),
                                    "communalities": np.array([]),
                                    "unique_variances": np.array([]), "item_names": []}
    try:
        if compute_omega_h:
            # SAFETY BOUND: investigation during this development cycle
            # found the oblique rotation's default max_iter (5000) can,
            # for certain data, take many seconds for a SINGLE point-
            # estimate call -- empirically confirmed NON-monotonic with
            # iteration count in some cases (cap=100 completed instantly
            # with a value identical to much slower higher caps), but
            # NOT reliably resolved by capping alone: different random
            # data realizations at the same k and same cap were also
            # found to occasionally take several seconds regardless.
            # Given this could not be resolved to a uniformly fast,
            # predictable bound, omega-hierarchical's ENTIRE computation
            # (not merely its bootstrap CI) is opt-in via this parameter,
            # defaulting to False/skipped, protecting the speed of every
            # other coefficient in this module (which have no such
            # issue) for the default case. The 200-iteration cap is
            # still applied when explicitly requested, as a partial
            # mitigation.
            results["omega_h_detail"] = _mcdonald_omega_hierarchical(
                X, item_names, max_rotation_iter=200)
        else:
            results["omega_h_detail"] = {
                "omega_h": np.nan, "computable": False,
                "reason": (
                    "Omega-hierarchical was not computed for this run. Its "
                    "computation is opt-in (compute_omega_h=True) because "
                    "investigation found its oblique-rotation extraction can "
                    "take substantial, unpredictable time for certain data "
                    "structures, independent of item count -- this protects "
                    "the speed of every other reliability coefficient, which "
                    "have no such issue, for the default analysis run."),
                "n_factors_used": 0, "general_loadings": np.array([]),
                "specific_loadings": np.array([]), "item_names": item_names,
                "not_computed_by_default": True}
    except Exception:
        results["omega_h_detail"] = {"omega_h": np.nan, "computable": False,
                                      "reason": "Omega hierarchical computation failed.",
                                      "n_factors_used": 0, "general_loadings": np.array([]),
                                      "specific_loadings": np.array([]), "item_names": item_names}

    # ══════════════════════════════════════════════════════════════════
    # Bootstrap confidence intervals: Guttman's lambda family, Split-Half
    # (all three variants), and McDonald's Omega (both omega-u bases and
    # omega-hierarchical). Method recommended by Kelley, K., &
    # Pornprasertmanit, S. (2016). Psychological Methods, 21(1), 69-92,
    # for reliability coefficients generally (bootstrap methods showed
    # the best empirical coverage for the smaller sample sizes common in
    # applied reliability research, per subsequent Monte Carlo
    # comparisons of omega-CI methods specifically).
    #
    # Fast, closed-form coefficients (lambda1/2/3/5/6 both bases,
    # omega-u both bases) use a direct percentile bootstrap
    # (`_bootstrap_ci_percentile`) at the full requested n_boot.
    #
    # Coefficients requiring an expensive per-call search or iterative
    # optimisation (lambda4, the maximum-Spearman-Brown split-half
    # variant, omega-hierarchical) use `_bootstrap_ci_fixed_search`,
    # which automatically selects a full re-search bootstrap for k <= 12
    # items or a fixed-search (search once, bootstrap the value only)
    # approach for k > 12 -- see that function's docstring for the full
    # rationale, benchmarks, and the explicitly disclosed limitation of
    # the fixed-search regime.
    # ══════════════════════════════════════════════════════════════════
    _n_boot_ic = n_boot_ic
    try:
        if compute_bootstrap_ci and k >= 2:
            # -- Guttman's lambda: fast forms (both bases) --
            for _basis_key in ("raw", "standardized"):
                if _basis_key not in results["lambdas"]:
                    continue
                _bX = X if _basis_key == "raw" else (
                    (X - X.mean(axis=0)) / np.where(X.std(axis=0, ddof=1) > 1e-12, X.std(axis=0, ddof=1), 1.0))
                _sub = results["lambdas"][_basis_key]
                for _lam_key in ["lambda1", "lambda2", "lambda3", "lambda5", "lambda6"]:
                    _ci = _bootstrap_ci_percentile(
                        _bX, lambda Xb, _lk=_lam_key: _guttman_lambdas_fast_only(Xb).get(_lk, np.nan),
                        n_boot=_n_boot_ic)
                    _sub[f"{_lam_key}_ci_lo"] = _ci["ci_lo"]
                    _sub[f"{_lam_key}_ci_hi"] = _ci["ci_hi"]
                    _sub[f"{_lam_key}_ci_method"] = _ci["method"]
                # -- lambda4: fixed-search bootstrap, k-dependent regime --
                def _l4_search(Xb, return_search_result=False):
                    _r = _lambda4_exhaustive(Xb, Xb.sum(axis=1).var(ddof=1))
                    return _r if return_search_result else _r["lambda4"]
                def _l4_recompute(Xb, fixed_result):
                    return _lambda4_given_split(Xb, Xb.sum(axis=1).var(ddof=1), fixed_result["best_split"])
                _ci4 = _bootstrap_ci_fixed_search(_bX, k, _l4_search, _l4_recompute, n_boot=_n_boot_ic)
                _sub["lambda4_ci_lo"] = _ci4["ci_lo"]
                _sub["lambda4_ci_hi"] = _ci4["ci_hi"]
                _sub["lambda4_ci_method"] = _ci4["method"]
                _sub["lambda4_ci_k_threshold"] = _BOOTSTRAP_SEARCH_K_THRESHOLD

            # -- Split-Half: first-second and odd-even (fast) --
            if results.get("split_half") and not results["split_half"].get("error"):
                for _variant in ["first_second", "odd_even"]:
                    if _variant not in results["split_half"]:
                        continue
                    _v = results["split_half"][_variant]
                    if _v.get("error"):
                        continue
                    for _stat_key in ["spearman_brown", "guttman"]:
                        def _sh_compute(Xb, _variant=_variant, _stat_key=_stat_key):
                            k_ = Xb.shape[1]
                            if _variant == "first_second":
                                idx1 = list(range(k_ // 2)); idx2 = list(range(k_ // 2, k_))
                            else:
                                idx1 = list(range(0, k_, 2)); idx2 = list(range(1, k_, 2))
                            h1 = Xb[:, idx1].sum(axis=1); h2 = Xb[:, idx2].sum(axis=1)
                            r = np.corrcoef(h1, h2)[0, 1]
                            if np.isnan(r): return np.nan
                            if _stat_key == "spearman_brown":
                                return 2*r/(1+r)
                            else:
                                return 4*r*np.sqrt(h1.var(ddof=1)*h2.var(ddof=1)) / Xb.sum(axis=1).var(ddof=1)
                        _ci = _bootstrap_ci_percentile(X, _sh_compute, n_boot=_n_boot_ic)
                        _v[f"{_stat_key}_ci_lo"] = _ci["ci_lo"]
                        _v[f"{_stat_key}_ci_hi"] = _ci["ci_hi"]
                        _v[f"{_stat_key}_ci_method"] = _ci["method"]
                # -- Split-Half Maximum: fixed-search bootstrap --
                if "maximum" in results["split_half"] and not results["split_half"]["maximum"].get("error"):
                    def _sb_search(Xb, return_search_result=False):
                        _r = _max_spearman_brown_split_exhaustive(Xb)
                        return _r if return_search_result else _r["spearman_brown"]
                    def _sb_recompute(Xb, fixed_result):
                        return _spearman_brown_given_split(Xb, fixed_result["best_split"])
                    _ci_max = _bootstrap_ci_fixed_search(X, k, _sb_search, _sb_recompute, n_boot=_n_boot_ic)
                    results["split_half"]["maximum"]["spearman_brown_ci_lo"] = _ci_max["ci_lo"]
                    results["split_half"]["maximum"]["spearman_brown_ci_hi"] = _ci_max["ci_hi"]
                    results["split_half"]["maximum"]["spearman_brown_ci_method"] = _ci_max["method"]
                    results["split_half"]["maximum"]["ci_k_threshold"] = _BOOTSTRAP_SEARCH_K_THRESHOLD

            # -- McDonald's omega-u: both bases (fast) --
            for _ok in ["omega_model_implied", "omega_observed"]:
                _ci = _bootstrap_ci_percentile(
                    X, lambda Xb, _ok=_ok: _mcdonald_omega(Xb, item_names).get(_ok, np.nan),
                    n_boot=_n_boot_ic)
                results["omega_detail"][f"{_ok}_ci_lo"] = _ci["ci_lo"]
                results["omega_detail"][f"{_ok}_ci_hi"] = _ci["ci_hi"]
                results["omega_detail"][f"{_ok}_ci_method"] = _ci["method"]

            # -- McDonald's omega-hierarchical: CI deliberately NOT computed --
            # Investigated during development: even the POINT ESTIMATE alone
            # (a single, uncapped call) was found to take several seconds for
            # certain real (non-pathological) datasets -- specifically, data
            # that only marginally satisfies the >=2-eigenvalue applicability
            # gate without a genuinely well-separated bifactor structure,
            # causing the oblique-rotation optimizer to struggle to converge.
            # Bootstrap resampling compounds this: across genuine bootstrap
            # replicates of such data, omega_h values were observed to vary
            # dramatically (e.g. 0.18-0.61 across 30 replicates of the same
            # underlying data in one tested case) even with a reduced
            # rotation-iteration cap -- indicating the oblique rotation does
            # not reliably converge to a comparable solution across resamples
            # for this class of data. A confidence interval computed from an
            # unstable bootstrap distribution would convey false precision
            # rather than genuine uncertainty, so none is computed. This is a
            # deliberate, disclosed limitation, not merely a "not yet
            # implemented" gap: the point estimate itself remains fully
            # computed and reported.
            if results["omega_h_detail"].get("computable"):
                results["omega_h_detail"]["omega_h_ci_lo"] = np.nan
                results["omega_h_detail"]["omega_h_ci_hi"] = np.nan
                results["omega_h_detail"]["omega_h_ci_method"] = "not_computed_disclosed"
                results["omega_h_detail"]["omega_h_ci_reason"] = (
                    "A bootstrap confidence interval is not computed for "
                    "omega-hierarchical. Investigation found that its "
                    "oblique-rotation extraction can require substantial, "
                    "unpredictable computation time for certain data "
                    "structures (data that only marginally satisfies this "
                    "coefficient's applicability gate without a strongly "
                    "separated bifactor structure), and that bootstrap "
                    "replicate values under such conditions can vary "
                    "dramatically rather than converging to a stable "
                    "distribution -- a confidence interval computed under "
                    "these conditions would convey false precision. This "
                    "is a disclosed limitation, not an oversight: the "
                    "point estimate above remains fully computed.")
    except Exception:
        pass

    try: results["item_stats"] = _item_total_stats(X, item_names, results["alpha"])
    except Exception: results["item_stats"] = pd.DataFrame()
    try: results["icc"] = _icc(X, item_names)
    except Exception: results["icc"] = None
    try: results["icc_if_deleted"] = _icc_if_deleted(X, item_names)
    except Exception: results["icc_if_deleted"] = pd.DataFrame(columns=["Item", "ICC(C,k) if Item Deleted"])

    # ── Inter-item correlation & covariance ──
    try:
        results["inter_item_corr"] = pd.DataFrame(
            np.corrcoef(X, rowvar=False),
            index=item_names, columns=item_names)
        iu = np.triu_indices(k, 1)
        results["avg_inter_item_r"] = float(np.corrcoef(X, rowvar=False)[iu].mean())
        results["inter_item_cov"] = pd.DataFrame(
            np.cov(X, rowvar=False, ddof=1),
            index=item_names, columns=item_names)
    except Exception:
        results["inter_item_corr"] = pd.DataFrame()
        results["avg_inter_item_r"] = np.nan
        results["inter_item_cov"] = pd.DataFrame()
    # ── Item statistics (incl. Median + extended descriptives) ──
    item_rows = []
    for j in range(k):
        d = X[:, j]
        nn = len(d)
        skew = float(scipy_stats.skew(d, bias=False)) if nn > 2 else np.nan
        kurt = float(scipy_stats.kurtosis(d, bias=False)) if nn > 3 else np.nan
        item_rows.append({
            "Item": item_names[j], "N": N,
            "Mean": float(d.mean()),
            "Median": float(np.median(d)),
            "Std. Deviation": float(d.std(ddof=1)),
            "Variance": float(d.var(ddof=1)),
            "Minimum": float(d.min()),
            "Maximum": float(d.max()),
            "Range": float(d.max() - d.min()),
            "Skewness": skew if not np.isnan(skew) else np.nan,
            "Kurtosis": kurt if not np.isnan(kurt) else np.nan,
        })
    results["item_descriptives"] = pd.DataFrame(item_rows)

    # ── Summary Item Statistics (aggregate across items) ──
    try:
        means = X.mean(axis=0)
        variances = X.var(axis=0, ddof=1)
        # inter-item correlations (off-diagonal)
        Rc = np.corrcoef(X, rowvar=False)
        iu = np.triu_indices(k, 1)
        inter_r = Rc[iu]
        Cc = np.cov(X, rowvar=False, ddof=1)
        inter_cov = Cc[iu]

        def _summ(arr):
            arr = np.asarray(arr, dtype=float)
            mn, mx = float(arr.min()), float(arr.max())
            rng = mx - mn
            ratio = (mx / mn) if mn != 0 else np.nan
            return [float(arr.mean()), mn, mx,
                    rng, ratio if not np.isnan(ratio) else np.nan,
                    float(arr.var(ddof=1)) if len(arr) > 1 else np.nan,
                    float(np.median(arr))]

        summ_cols = ["", "Mean", "Minimum", "Maximum", "Range",
                     "Maximum / Minimum", "Variance", "Median"]
        summ_rows = [summ_cols]
        summ_rows.append(["Item Means"] + _summ(means))
        summ_rows.append(["Item Variances"] + _summ(variances))
        if len(inter_r) > 0:
            summ_rows.append(["Inter-Item Correlations"] + _summ(inter_r))
            summ_rows.append(["Inter-Item Covariances"] + _summ(inter_cov))
        results["summary_item_stats"] = pd.DataFrame(summ_rows[1:], columns=summ_cols)
    except Exception:
        results["summary_item_stats"] = pd.DataFrame()

    # ── Scale Statistics (full) ──
    tot = X.sum(axis=1)
    nt = len(tot)
    sskew = float(scipy_stats.skew(tot, bias=False)) if nt > 2 else np.nan
    skurt = float(scipy_stats.kurtosis(tot, bias=False)) if nt > 3 else np.nan
    results["scale_stats"] = {
        "n": N, "k": k,
        "mean": float(tot.mean()),
        "median": float(np.median(tot)),
        "variance": float(tot.var(ddof=1)),
        "sd": float(tot.std(ddof=1)),
        "min": float(tot.min()),
        "max": float(tot.max()),
        "range": float(tot.max() - tot.min()),
        "skewness": sskew if not np.isnan(sskew) else np.nan,
        "kurtosis": skurt if not np.isnan(skurt) else np.nan,
    }

    # ── Standard Error of Measurement (SEM) ──
    # Uses the PRIMARY reliability estimate for this construct's context:
    # KR-20 for dichotomous data, Cronbach's alpha otherwise -- the same
    # coefficient already used as this module's headline reliability
    # figure for the relevant data type.
    _sem_reliability = (results.get("kr20") if results.get("dichotomous")
                         else results.get("alpha"))
    results["sem"] = _sem(results["scale_stats"]["sd"], _sem_reliability)
    results["sem_basis"] = "KR-20" if results.get("dichotomous") else "Cronbach's alpha"


    # ── Descriptive interpretation ──
    a = results["alpha"]
    lbl = alpha_label(a)
    ci = results.get("alpha_ci", (np.nan, np.nan))
    interp = (
        f"For the construct <b>{construct_name}</b> ({k} items, N = {N}), "
        f"Cronbach\u2019s alpha = {a:.3f}, indicating <b>{lbl}</b> internal "
        f"consistency."
    )
    if not np.isnan(ci[0]):
        interp += f" The {pct}% confidence interval is [{ci[0]:.3f}, {ci[1]:.3f}]."
    # alpha-if-deleted advice
    its = results.get("item_stats")
    advice = ""
    if its is not None and not its.empty and not np.isnan(a):
        bad = its[its["Cronbach's Alpha if Item Deleted"] > a + 0.001]
        if not bad.empty:
            items = ", ".join(bad["Item"].tolist())
            advice = (f" Removing {items} would increase alpha, suggesting "
                      f"these item(s) may not fit the construct well.")
    interp += advice
    if flagged:
        interp += (f" Note: {', '.join(flagged)} show negative item-total "
                   f"correlations and may be reverse-scored.")
    results["interpretation"] = interp

    results.update({
        "construct_name": construct_name, "n": N, "k": k,
        "item_names": item_names, "alpha_level": alpha,
        "flagged_reverse": flagged, "reverse_info": reverse_info,
        "reverse_method": reverse_method,
    })

    # Inter-rater agreement is computed separately via run_irar()
    # which is called from run_multi_reliability when mode = Inter-Rater Agreement.
    # Here we only zero-out the keys so downstream code is safe.
    results["cohen_kappa"]   = None
    results["fleiss_kappa"]  = None
    results["krippendorff"]  = None
    results["irar_method"]   = None
    results["irar_data_type"]= None

    return results


def _irar_strength_interp(method_key, value, label, n_units, k_raters, data_type):
    """Generate full academic interpretation text for an inter-rater result."""
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return "Result could not be computed for this configuration."
    v = float(value)
    # Strength
    if v < 0:
        strength = "poor (worse than chance)"
        implication = (
            "The raters disagreed more than expected by chance, suggesting "
            "systematic bias or fundamental disagreement in rating criteria. "
            "Rater training and clarification of rating criteria are strongly recommended.")
    elif v < 0.20:
        strength = "slight"
        implication = (
            "Agreement barely exceeds chance. The raters are largely inconsistent. "
            "The rating protocol should be thoroughly revised and rater training conducted.")
    elif v < 0.40:
        strength = "fair"
        implication = (
            "Agreement is fair but substantially influenced by chance. "
            "Rater calibration sessions and clearer operational definitions of "
            "rating categories are recommended before using these ratings for research.")
    elif v < 0.60:
        strength = "moderate"
        implication = (
            "Moderate agreement indicates reasonable but imperfect consistency. "
            "Acceptable for exploratory research; improvement is recommended for "
            "high-stakes assessment or publication purposes.")
    elif v < 0.80:
        strength = "substantial"
        implication = (
            "Substantial agreement indicates good reliability. "
            "This level is generally acceptable for most research and applied contexts.")
    else:
        strength = "almost perfect"
        implication = (
            "Almost perfect agreement indicates excellent inter-rater reliability. "
            "The raters demonstrate very high consistency in their assessments.")

    # Method-specific symbol and threshold note
    if "Krippendorff" in method_key:
        sym = "α"; thr = ("Krippendorff (2004) recommends α ≥ 0.800 for reliable data "
                          "and considers α ≥ 0.667 the minimum acceptable threshold.")
        bench_ref = "Krippendorff (2004)"
    elif "ICC" in method_key:
        sym = "ICC"
        if v >= 0.90:   icc_str = "Excellent"
        elif v >= 0.75: icc_str = "Good"
        elif v >= 0.50: icc_str = "Moderate"
        else:           icc_str = "Poor"
        thr = (f"Koo & Li (2016): {icc_str} reliability "
               f"(thresholds: >0.90 Excellent, 0.75–0.90 Good, "
               f"0.50–0.75 Moderate, <0.50 Poor).")
        bench_ref = "Koo & Li (2016)"
        strength  = icc_str.lower()
    else:
        sym = "κ"; thr = ("Landis & Koch (1977) benchmarks: <0 Poor; "
                          "0.00–0.20 Slight; 0.21–0.40 Fair; 0.41–0.60 Moderate; "
                          "0.61–0.80 Substantial; 0.81–1.00 Almost Perfect.")
        bench_ref = "Landis & Koch (1977)"

    dtype_str = {"dichotomous": "dichotomous (2 categories)",
                 "nominal":     "nominal (unordered categorical)",
                 "ordinal":     "ordinal (ordered categorical)",
                 "interval":    "interval/continuous",
                 "ratio":       "ratio/continuous"}.get(data_type, data_type)

    return (
        f"The {method_key} ({sym}\u2009=\u2009{v:.3f}) indicates "
        f"<b>{strength} inter-rater agreement</b> "
        f"among {k_raters} raters rating {n_units} units "
        f"({dtype_str} data; {label}). "
        f"{implication} {thr}"
    )


def run_multi_reliability(df, constructs, alpha=0.05, reverse_method=None,
                          auto_reverse=False, scale_min=None, scale_max=None,
                          compute_bootstrap_ci=False, n_boot_ic=1000,
                          compute_omega_h=False):
    """Run reliability for several constructs.

    Parameters
    ----------
    df : DataFrame
    constructs : list of dict {'name': str, 'items': [col, ...]}
    alpha : float
    reverse_method : None | 'theoretical' | 'observed' | 'zscore'
    auto_reverse : bool -- if True, auto-reverse flagged items using reverse_method
    compute_bootstrap_ci : bool, default False -- see run_reliability's
        own docstring; passed through unchanged, defaulting to skipped
        for speed unless the caller explicitly opts in.
    n_boot_ic : int, default 1000 -- bootstrap replicate count when
        compute_bootstrap_ci=True.
    compute_omega_h : bool, default False -- see run_reliability's own
        docstring; passed through unchanged.
    """
    out = {"constructs": [], "alpha_level": alpha}
    summary_rows = []
    for c in constructs:
        name = c["name"]
        items = c["items"]
        sub = df[items].apply(pd.to_numeric, errors="coerce").dropna()
        rm = reverse_method if auto_reverse else None
        res = run_reliability(
            sub.values, items, alpha=alpha, construct_name=name,
            reverse_method=rm, reverse_items=None,
            scale_min=scale_min, scale_max=scale_max,
            compute_bootstrap_ci=compute_bootstrap_ci, n_boot_ic=n_boot_ic,
            compute_omega_h=compute_omega_h)
        out["constructs"].append(res)
        sh = res.get("split_half", {})
        summary_rows.append({
            "Construct": name,
            "Items": res["k"],
            "N": res["n"],
            "Cronbach's \u03b1": res["alpha"],
            "\u03b1 (std.)": res.get("alpha_std", np.nan),
            "McDonald's \u03c9": res.get("omega", np.nan),
            "Guttman \u03bb2": res.get("lambdas", {}).get("lambda2", np.nan),
            "Split-Half (SB)": sh.get("spearman_brown", np.nan),
        })
    out["summary"] = pd.DataFrame(summary_rows)
    return out


def run_multi_irar(df, groups, alpha=0.05, n_boot=1000):
    """Run inter-rater agreement for multiple rating groups.
    Each group specifies its own data_type. All relevant methods
    are computed automatically — no single-method selection.

    Parameters
    ----------
    df     : DataFrame
    groups : list of {"name": str, "items": [col,...], "data_type": str}
    alpha  : significance level
    n_boot : bootstrap resamples for Krippendorff's α

    Returns
    -------
    dict with "constructs" and "irar_summary"
    """
    constructs   = []
    summary_rows = []

    for grp in groups:
        name      = grp["name"]
        cols      = grp["items"]
        data_type = grp.get("data_type","nominal")
        sub       = df[cols].apply(pd.to_numeric, errors="coerce").dropna()
        X         = sub.values.astype(float)
        n_units, k_raters = X.shape

        # Guard: minimum requirements for IRAR computation
        if k_raters < 2:
            constructs.append({
                "construct_name": name, "data_type": data_type,
                "n_units": n_units,     "k_raters": k_raters,
                "rater_names": cols,    "applicable_methods": [],
                "error": ("At least 2 rater columns are required. "
                          "Please select ≥ 2 columns for this rating group."),
            })
            continue
        if n_units < 2:
            constructs.append({
                "construct_name": name, "data_type": data_type,
                "n_units": n_units,     "k_raters": k_raters,
                "rater_names": cols,    "applicable_methods": [],
                "error": (f"Insufficient data: {n_units} complete row(s) found after "
                          f"removing rows with missing values. At least 2 complete rows "
                          f"are required. Check for missing values in the selected columns."),
            })
            continue

        applicable = _get_applicable_methods(data_type, k_raters)

        # ── Mandatory, user-declared instrument-scale information ────────
        # Required (not optional) whenever a q-dependent coefficient
        # (AC1, AC2, Brennan-Prediger) is applicable -- see the primary-
        # theory audit documented in _gwet_ac1's docstring: q must reflect
        # the instrument's declared category count, not merely the count
        # of values observed in this specific sample. The UI enforces
        # this field's presence before allowing computation to run; the
        # engine additionally guards defensively here.
        q_declared      = grp.get("q_declared")
        scale_min       = grp.get("scale_min")

        res = {
            "construct_name":     name,
            "data_type":          data_type,
            "n_units":            n_units,
            "k_raters":           k_raters,
            "rater_names":        cols,
            "applicable_methods": applicable,
            "method_context":     _irar_method_context(data_type, k_raters, applicable),
            # Existing methods
            "cohen_kappa":        None,
            "weighted_kappa":     None,
            "fleiss_kappa":       None,
            "icc":                None,
            "krippendorff":       None,
            # New methods
            "percentage_agreement": None,
            "scott_pi":           None,
            "brennan_prediger":   None,
            "gwet_ac1":           None,
            "gwet_ac2":           None,
            "lin_ccc":            None,
        }

        # ── Percentage Agreement (always first, all configurations) ──────
        if "pct" in applicable:
            pa_res = _percentage_agreement(X)
            res["percentage_agreement"] = {
                "pa": pa_res["pa"], "ci_lo": pa_res["ci_lo"], "ci_hi": pa_res["ci_hi"],
                "n": n_units, "k": k_raters,
                "total_pairwise_comparisons": int(n_units * (k_raters*(k_raters-1)//2)),
                "per_unit": pa_res["per_unit"], "n_units_valid": pa_res["n_units_valid"],
                "mean": pa_res["mean"], "sd": pa_res["sd"],
                "minimum": pa_res["minimum"], "maximum": pa_res["maximum"],
                "interpretation_text": _pa_interp(pa_res["pa"], pa_res["ci_lo"],
                                                    pa_res["ci_hi"], n_units, k_raters),
            }

        # ── Cohen's κ (dichotomous/nominal, k=2) ─────────────────────────
        if "cohen" in applicable and k_raters == 2:
            ck = _cohen_kappa(X, cols, alpha)
            if ck:
                ck["interpretation_text"] = _irar_strength_interp(
                    "Cohen's κ", ck["kappa"], ck["kappa_label"],
                    n_units, k_raters, data_type)
                ck["formula_note"] = (
                    "κ = (P_o − P_e) / (1 − P_e). "
                    "P_o = observed proportion of agreement. "
                    "P_e = Σ_c p_c(r1) × p_c(r2) = expected agreement by chance. "
                    "SE via Fleiss, Cohen & Everitt (1969); z = κ/SE; two-tailed p. "
                    "Prevalence Index (PI) = |p_+ − p_−|; Bias Index (BI) = p_+(r1) − p_+(r2). "
                    "Reference: Cohen (1960). Educational and Psychological Measurement.")
            res["cohen_kappa"] = ck

        # ── Weighted Cohen's κ (ordinal, k=2) ────────────────────────────
        if "weighted" in applicable and k_raters == 2:
            ck_w = _cohen_kappa(X, cols, alpha)
            if ck_w and "kappa_quadratic" in ck_w:
                ck_w["primary_value"] = ck_w.get("kappa_quadratic", np.nan)
                ck_w["primary_label"] = ck_w.get("kappa_quadratic_label","—")
                ck_w["interpretation_text"] = _irar_strength_interp(
                    "Weighted Cohen's κ (quadratic)",
                    ck_w.get("kappa_quadratic", np.nan),
                    ck_w.get("kappa_quadratic_label","—"),
                    n_units, k_raters, data_type)
                ck_w["formula_note"] = (
                    "Quadratic weights: w_ij = 1 − (i−j)²/(k−1)². "
                    "Linear weights: w_ij = 1 − |i−j|/(k−1). "
                    "κ_w = 1 − Σw_ij·d_ij / Σw_ij·e_ij "
                    "(Cohen, 1968). "
                    "Quadratic weights recommended for Likert-type scales — "
                    "larger disagreements penalised proportionally more. "
                    "Note: κ_w (quadratic) ≈ ICC(2,1) for continuous data.")
            res["weighted_kappa"] = ck_w

        # ── Fleiss' κ (dichotomous/nominal, k≥3) ─────────────────────────
        if "fleiss" in applicable and k_raters >= 3:
            fk = _fleiss_kappa(X, cols, alpha)
            if fk:
                fk["interpretation_text"] = _irar_strength_interp(
                    "Fleiss' κ", fk["kappa"], fk["kappa_label"],
                    n_units, k_raters, data_type)
                fk["formula_note"] = (
                    "κ = (P̄ − P̄_e) / (1 − P̄_e) (Fleiss, 1971). "
                    "P̄ = (1/N)Σ_i[(1/k(k−1))Σ_j n_ij(n_ij−1)]. "
                    "P̄_e = Σ_j p_j² (expected by chance). "
                    "SE via Fleiss, Cohen & Everitt (1969). "
                    "Per-category κ_j also reported. "
                    "Note: Fleiss' κ treats all categories as nominal — "
                    "for ordinal ≥3 raters, Krippendorff's α (ordinal metric) is more appropriate.")
            res["fleiss_kappa"] = fk

        # ── ICC (interval/ratio) ──────────────────────────────────────────
        if "icc" in applicable:
            try:
                icc_df = _icc(X, cols)
                if icc_df is not None and isinstance(icc_df, pd.DataFrame):
                    icc_res = _parse_icc_df(icc_df)
                    if icc_res is not None:
                        i21 = icc_res.get("icc_2_1", np.nan)
                        icc_res["interpretation_text"] = _irar_strength_interp(
                            "ICC(2,1)", i21, icc_res.get("icc_2_1_label","—"),
                            n_units, k_raters, data_type)
                        res["icc"] = icc_res
                    else:
                        res["icc"] = {"error": "ICC parsing failed."}
                else:
                    res["icc"] = {"error": "ICC not computable. Check: pingouin installed? ≥2 raters? No zero-variance columns?"}
            except Exception as e:
                res["icc"] = {"error": str(e)}

        # ── Krippendorff's α (all types, all rater counts) ───────────────
        if "krippendorff" in applicable:
            dt_map = {"dichotomous":"nominal","nominal":"nominal",
                      "ordinal":"ordinal","interval":"interval","ratio":"ratio"}
            dt_k = dt_map.get(data_type,"nominal")
            ka_val, ka_ci = _krippendorff_alpha(X, data_type=dt_k, n_boot=n_boot)
            ka_lbl = krippendorff_label(ka_val)
            res["krippendorff"] = {
                "alpha":    float(ka_val) if not np.isnan(ka_val) else np.nan,
                "ci_lo":    float(ka_ci[0]) if not np.isnan(ka_ci[0]) else np.nan,
                "ci_hi":    float(ka_ci[1]) if not np.isnan(ka_ci[1]) else np.nan,
                "data_type":dt_k, "n_units":n_units, "k_raters":k_raters,
                "n_boot":   n_boot, "label": ka_lbl,
                "interpretation_text": _irar_strength_interp(
                    "Krippendorff's α", ka_val, ka_lbl, n_units, k_raters, dt_k),
                "formula_note": (
                    f"α = 1 − D_o/D_e (Krippendorff, 2004). "
                    f"D_o = observed disagreement (mean pairwise distance within units). "
                    f"D_e = expected disagreement (mean pairwise distance across all values). "
                    f"Distance metric for {dt_k} data: "
                    + {"nominal":  "d(a,b) = 0 if a=b, else 1.",
                       "ordinal":  "d(a,b) = (Σn_g from a to b − (n_a+n_b)/2)² "
                                   "(cumulative marginal distribution).",
                       "interval": "d(a,b) = (a−b)².",
                       "ratio":    "d(a,b) = ((a−b)/(a+b))²."}[dt_k]
                    + f" 95% CI: percentile bootstrap ({n_boot:,} resamples, seed=42). "
                    f"Handles missing data and any number of raters. "
                    f"Thresholds: α≥0.800 reliable; 0.667≤α<0.800 tentatively acceptable; "
                    f"α<0.667 unreliable (Krippendorff, 2004)."),
            }

        # ── Gwet's AC1 (dichotomous/nominal, k=2 or k≥3) ────────────────
        if "gwet_ac1" in applicable:
            ac1_res = _gwet_ac1(X, alpha=alpha, q_declared=q_declared)
            if ac1_res.get("ac1") is not None:
                ac1_res["interpretation_text"] = _gwet_ac_interp(
                    ac1_res["ac1"], ac1_res["label"], "AC1",
                    n_units, k_raters, data_type)
                ac1_res["formula_note"] = (
                    "AC1 = (P_o − P_e) / (1 − P_e). "
                    "P_e(AC1) = (1/(q−1)) × Σ_c π_c(1−π_c), "
                    "where π_c = grand marginal proportion of category c, and "
                    "q = user-declared number of categories in the coding "
                    "scheme (not merely the count observed in this sample -- "
                    "see Gwet, Handbook of Inter-Rater Reliability, Ch. 5). "
                    "This P_e formulation avoids the prevalence paradox that "
                    "affects Cohen's κ. Variance via jackknife (Gwet, 2014, App. A). "
                    "Reference: Gwet (2008). British Journal of Mathematical and "
                    "Statistical Psychology, 61(1), 29–48.")
                ac1_res["dual_ci_note"] = _dual_ci_note(
                    "Gwet's AC1", "jackknife",
                    ac1_res.get("ci_lo_z"), ac1_res.get("ci_hi_z"),
                    ac1_res.get("ci_lo_t"), ac1_res.get("ci_hi_t"),
                    ac1_res.get("ci_df"))
            res["gwet_ac1"] = ac1_res

        # ── Scott's π (dichotomous/nominal, k=2 only) ────────────────────
        if "scott_pi" in applicable and k_raters == 2:
            sp_res = _scott_pi(X[:,0], X[:,1], alpha=alpha)
            sp_res["interpretation_text"] = _scott_pi_interp(
                sp_res["pi"], sp_res["label"], sp_res["n"], data_type)
            if sp_res.get("pi") is not None and not np.isnan(sp_res.get("pi", np.nan)):
                sp_res["dual_ci_note"] = _dual_ci_note(
                    "Scott's \u03c0", "analytic",
                    sp_res.get("ci_lo_z"), sp_res.get("ci_hi_z"),
                    sp_res.get("ci_lo_t"), sp_res.get("ci_hi_t"),
                    sp_res.get("ci_df"))
            res["scott_pi"] = sp_res

        # ── Brennan-Prediger (dichotomous/nominal, k=2 only) ─────────────
        if "bp" in applicable and k_raters == 2:
            bp_res = _brennan_prediger(X[:,0], X[:,1], alpha=alpha, q_declared=q_declared)
            bp_res["interpretation_text"] = _bp_interp(
                bp_res["kappa_bp"], bp_res["label"],
                bp_res["n"], bp_res["q"], data_type)
            # ── Comparison with other chance-corrected coefficients ──────
            # Brennan-Prediger, Cohen's kappa, and Gwet's AC1 are all
            # applicable together for dichotomous/nominal k=2 data and
            # differ ONLY in how expected chance agreement (Pe) is
            # modelled -- BP: uniform 1/q; Cohen's: product of each
            # rater's own marginals; AC1: pooled/grand marginals via the
            # (q-1) denominator. Both Cohen's kappa and AC1 are already
            # computed earlier in this same function call (see above);
            # this reuses those results rather than recomputing them.
            _bp_comparison = []
            _ck_for_cmp = res.get("cohen_kappa")
            if _ck_for_cmp and _ck_for_cmp.get("kappa") is not None:
                _bp_comparison.append(("Cohen's \u03ba", _ck_for_cmp["kappa"],
                                        "Product of each rater's own marginal proportions"))
            _ac1_for_cmp = res.get("gwet_ac1")
            if _ac1_for_cmp and _ac1_for_cmp.get("ac1") is not None and not np.isnan(_ac1_for_cmp.get("ac1", np.nan)):
                _bp_comparison.append(("Gwet's AC1", _ac1_for_cmp["ac1"],
                                        "Pooled (grand) marginal proportions across both raters"))
            _bp_comparison.append(("Brennan-Prediger", bp_res["kappa_bp"],
                                    "Uniform 1/q -- assumes all categories equally likely a priori"))
            bp_res["comparison_table"] = _bp_comparison
            bp_res["comparison_note"] = (
                "Brennan-Prediger, Cohen's \u03ba, and Gwet's AC1 all take the same "
                "general form \u03ba=(Po\u2212Pe)/(1\u2212Pe) and share the identical "
                "observed agreement Po; they differ only in how Pe (expected "
                "chance agreement) is modelled. Brennan-Prediger's uniform-"
                "probability Pe makes it immune to the prevalence and bias "
                "paradoxes that can distort Cohen's \u03ba when category use is "
                "very unequal between or within raters -- but this comes at the "
                "cost of assuming a chance model (equal category probability) "
                "that may not reflect the actual rating task.")
            if bp_res.get("kappa_bp") is not None and not np.isnan(bp_res.get("kappa_bp", np.nan)):
                bp_res["dual_ci_note"] = _dual_ci_note(
                    "Brennan-Prediger", "analytic",
                    bp_res.get("ci_lo_z"), bp_res.get("ci_hi_z"),
                    bp_res.get("ci_lo_t"), bp_res.get("ci_hi_t"),
                    bp_res.get("ci_df"))
            res["brennan_prediger"] = bp_res

        # ── Gwet's AC2 (ordinal, k=2 or k≥3) ────────────────────────────
        # Computes ALL FIVE weighting schemes simultaneously (not a
        # single user-selected scheme) -- per explicit agreement: the
        # application presents every scheme's result together, with its
        # own narrative and reference, rather than requiring the user to
        # pick one via a dropdown.
        if "gwet_ac2" in applicable:
            _ac2_scheme_defs = {
                "quadratic": {
                    "label": "Quadratic (Fleiss-Cohen)",
                    "formula": "w_cc' = 1 − (c−c')²/(q−1)²",
                    "reference": "Fleiss, J.L., & Cohen, J. (1973). The equivalence of "
                                 "weighted kappa and the intraclass correlation coefficient "
                                 "as measures of reliability. Educational and Psychological "
                                 "Measurement, 33(3), 613–619.",
                    "when_to_use": "The most commonly used default weighting scheme; "
                                   "penalises disagreements in proportion to the SQUARE of "
                                   "their category distance, so distant disagreements are "
                                   "penalised disproportionately more than near ones. "
                                   "Appropriate as a general-purpose default for ordinal "
                                   "scales when there is no specific substantive reason to "
                                   "prefer a different decay pattern.",
                },
                "linear": {
                    "label": "Linear (Cicchetti-Allison)",
                    "formula": "w_cc' = 1 − |c−c'|/(q−1)",
                    "reference": "Cicchetti, D., & Allison, T. (1971). A new procedure for "
                                 "assessing reliability of scoring EEG sleep recordings. "
                                 "American Journal of EEG Technology, 11, 101–109.",
                    "when_to_use": "Penalises disagreements in direct proportion to category "
                                   "distance (no disproportionate penalty for distant "
                                   "disagreements). Appropriate when every unit of category "
                                   "distance is considered substantively equally serious, "
                                   "rather than distant disagreements being considered "
                                   "disproportionately worse.",
                },
                "radical": {
                    "label": "Radical",
                    "formula": "w_cc' = 1 − √(|c−c'|/(q−1))",
                    "reference": "Formula independently verified against R's own "
                                 "irrCAC::radical.weights() reference package output "
                                 "(Gwet, K.L., irrCAC R package).",
                    "when_to_use": "Intermediate between linear and quadratic in how "
                                   "quickly credit decays with distance -- decays fastest "
                                   "for the FIRST unit of disagreement, then more slowly. "
                                   "Appropriate when even small disagreements should already "
                                   "reduce credit substantially, but very distant "
                                   "disagreements should not be penalised much further beyond "
                                   "that initial drop.",
                },
                "ordinal": {
                    "label": "Ordinal (Krippendorff-style)",
                    "formula": "Frequency-based cumulative distance, normalized to a "
                               "similarity weight (see documentation for the full formula)",
                    "reference": "Krippendorff, K. (2004). Content Analysis: An Introduction "
                                 "to Its Methodology (2nd ed.). Sage Publications, Chapter 11.",
                    "when_to_use": "Unlike the other schemes, weights here depend on the "
                                   "empirical FREQUENCY distribution of ratings, not solely "
                                   "on category values. Appropriate when the categories are "
                                   "not evenly spaced in a substantive sense, and the "
                                   "empirical distribution of responses should inform how "
                                   "\u2018close\u2019 two categories are treated as being.",
                },
                "identity": {
                    "label": "Identity (unweighted)",
                    "formula": "w_cc' = 1 if c=c' else 0",
                    "reference": "Mathematically identical to Gwet's AC1 (verified exactly: "
                                 "see Gwet, K.L. (2014). Handbook of Inter-Rater Reliability "
                                 "(4th ed.). Advanced Analytics, LLC., Chapter 5).",
                    "when_to_use": "No partial credit for any disagreement, however close. "
                                   "Included for direct comparability with AC1 and with "
                                   "Cohen's/Fleiss' unweighted \u03ba; not genuinely an ordinal "
                                   "weighting choice, since it discards the ordering "
                                   "information the other four schemes use.",
                },
            }
            _ac2_schemes_computed = {}
            for _scheme_key, _scheme_meta in _ac2_scheme_defs.items():
                _r = _gwet_ac2(X, weights=_scheme_key, alpha=alpha,
                                q_declared=q_declared, scale_min=scale_min)
                if _r.get("ac2") is not None and not np.isnan(_r.get("ac2", np.nan)):
                    _r["interpretation_text"] = _gwet_ac_interp(
                        _r["ac2"], _r["label"], "AC2", n_units, k_raters, data_type)
                    _r["scheme_label"] = _scheme_meta["label"]
                    _r["weight_formula"] = _scheme_meta["formula"]
                    _r["when_to_use"] = _scheme_meta["when_to_use"]
                    _r["formula_note"] = (
                        f"AC2 = (P_o_w − P_e_w) / (1 − P_e_w). "
                        f"{_scheme_meta['label']}: {_scheme_meta['formula']}. "
                        f"P_e_w = u·Σ_k π_k(1−π_k) / (q(q−1)), where u = the sum of "
                        f"every cell of the q×q weight matrix (including the diagonal) "
                        f"and q = the user-declared number of categories in the coding "
                        f"scheme (not merely the count observed in this sample). "
                        f"Variance via jackknife. Reference: {_scheme_meta['reference']}")
                    _r["dual_ci_note"] = _dual_ci_note(
                        f"Gwet's AC2 ({_scheme_meta['label']})", "jackknife",
                        _r.get("ci_lo_z"), _r.get("ci_hi_z"),
                        _r.get("ci_lo_t"), _r.get("ci_hi_t"),
                        _r.get("ci_df"))
                _ac2_schemes_computed[_scheme_key] = _r
            res["gwet_ac2"] = {"schemes": _ac2_schemes_computed,
                                "n": n_units, "k": k_raters,
                                "q_declared": q_declared, "scale_min": scale_min}


        # ── Lin's CCC (interval/ratio, k=2 only) ─────────────────────────
        if "ccc" in applicable and k_raters == 2:
            ccc_res = _lin_ccc(X[:,0], X[:,1], alpha=alpha)
            ccc_res["interpretation_text"] = _ccc_interp(
                ccc_res["ccc"], ccc_res["rho"], ccc_res["Cb"],
                ccc_res["label"], ccc_res["n"])
            ccc_res["formula_note"] = (
                "ρ_c = 2σ_xy / (σ_x² + σ_y² + (μ_x−μ_y)²) = ρ × C_b. "
                "ρ = Pearson correlation (precision); "
                "C_b = 2/(v + 1/v + u²) = bias correction factor (accuracy); "
                "v = σ_x/σ_y (scale shift); u = (μ_x−μ_y)/(σ_x·σ_y)^0.5 (location shift). "
                "95% CI via Fisher z-transformation on ρ_c. "
                "Reference: Lin (1989). Biometrics, 45(1), 255–268.")
            res["lin_ccc"] = ccc_res

        constructs.append(res)

        # Build comprehensive summary row — all methods
        def _sv(v):
            try: return float(v) if not (isinstance(v,float) and np.isnan(v)) else "—"
            except: return "—"
        def _sp(p):
            try:
                pf=float(p)
                return "< .001" if pf<.001 else f"{pf:.3f}"
            except: return "—"

        row = {
            "Group":       name,
            "Data Type":   data_type.title(),
            "k (Raters)":  k_raters,
            "N (Units)":   n_units,
            "Methods":     ", ".join(applicable),
        }
        # Cohen's κ columns
        ck = res.get("cohen_kappa") or {}
        row["Cohen's κ"]  = _sv(ck.get("kappa"))
        row["κ Sig."]     = _sp(ck.get("kappa_p")) if ck else "—"
        row["κ Label"]    = ck.get("kappa_label","—") if ck else "—"
        # Weighted κ columns
        wk = res.get("weighted_kappa") or {}
        row["Weighted κ (quad)"] = _sv(wk.get("kappa_quadratic")) if wk else "—"
        row["Wκ Label"]           = wk.get("kappa_quadratic_label","—") if wk else "—"
        # Fleiss' κ
        fk = res.get("fleiss_kappa") or {}
        row["Fleiss' κ"]  = _sv(fk.get("kappa")) if fk else "—"
        row["Fκ Sig."]    = _sp(fk.get("kappa_p")) if fk else "—"
        row["Fκ Label"]   = fk.get("kappa_label","—") if fk else "—"
        # ICC
        icc = res.get("icc") or {}
        row["ICC(2,1)"]       = _sv(icc.get("icc_2_1")) if icc and "error" not in icc else "—"
        row["ICC(2,k)"]       = _sv(icc.get("icc_2_k")) if icc and "error" not in icc else "—"
        row["ICC(3,1)"]       = _sv(icc.get("icc_3_1")) if icc and "error" not in icc else "—"
        row["ICC(3,k)"]       = _sv(icc.get("icc_3_k")) if icc and "error" not in icc else "—"
        row["ICC Label"]      = icc.get("icc_2_1_label","—") if icc and "error" not in icc else "—"
        # Krippendorff's α
        ka = res.get("krippendorff") or {}
        row["Kripp. α"]   = _sv(ka.get("alpha")) if ka else "—"
        _lo = ka.get("ci_lo",float("nan")); _hi = ka.get("ci_hi",float("nan"))
        try:
            row["Kripp. 95% CI"] = (f"[{_lo:.3f}, {_hi:.3f}]"
                                    if not (np.isnan(_lo) or np.isnan(_hi)) else "—")
        except: row["Kripp. 95% CI"] = "—"
        row["Kripp. Label"] = ka.get("label","—") if ka else "—"
        summary_rows.append(row)

    return {
        "constructs":   constructs,
        "irar_summary": pd.DataFrame(summary_rows),
        "alpha":        alpha,
        "n_boot":       n_boot,
    }

