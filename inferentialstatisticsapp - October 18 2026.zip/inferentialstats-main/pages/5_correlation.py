"""
pages/5_correlation.py — Inferential Statistics by MA
Bivariate Correlation. Based on user's deployed version.
Additions:
- Tab1: Bivariate Assumption Checks (linearity, outliers, coefficient selection)
- Tab4: TWO interpretation models:
  (A) Per-pair: each pair uses its own recommended method
  (B) Overall: all pairs use one consistent method (overall recommendation)
- HTML + CSV: mirror all web content
"""
import streamlit as st
import pandas as pd
import numpy as np
import warnings
from scipy import stats as scipy_stats
from datetime import datetime
import re as _re
warnings.filterwarnings("ignore")

st.set_page_config(
    page_title="Correlation | Inferential Statistics by MA",
    page_icon="🔗", layout="wide", initial_sidebar_state="expanded")

from utils.styles      import load_page_css
from utils.file_loader import (load_file, load_from_string, validate_file,
                                file_metadata, get_numeric_cols)
from utils.samples     import SAMPLES
from utils.formatters  import _f, _p
from utils.tables      import html_tbl
from utils.plots       import fig_to_bytes
from modules.correlation import run_correlation
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

PAL = ["#1a1a2e", "#e94560", "#0f3460", "#16213e"]
BG  = "#f8fafc"
_METHOD_COEF = {"pearson": "coef_pearson", "spearman": "coef_spearman",
                "kendall": "coef_kendall"}
_METHOD_P    = {"pearson": "p_pearson", "spearman": "p_spearman",
                "kendall": "p_kendall"}
_METHOD_NAME = {"pearson": "Pearson product-moment correlation",
                "spearman": "Spearman's rank-order correlation (ρ)",
                "kendall":  "Kendall's tau-b correlation (τ₂)"}

def _strip(s): return _re.sub(r"<[^>]+>","",str(s))


# ══════════════════════════════════════════════════════════════════════════════
# METHODOLOGICAL NOTES
# ══════════════════════════════════════════════════════════════════════════════
def _methodological_notes(R, alpha):
    pct    = int((1-alpha)*100)
    n      = R["n"]
    n_boot = R.get("n_boot", 0)
    seed   = R.get("bootstrap_seed", 42)
    methods = R.get("methods_used", [])
    mnames  = {"pearson": "Pearson r", "spearman": "Spearman ρ",
               "kendall": "Kendall τ₂"}
    used    = ", ".join(mnames.get(m,m) for m in methods) if methods else "—"
    return [
        ("Coefficient selection",
         "All three coefficients (Pearson r, Spearman ρ, Kendall τ₂) are computed "
         "for every variable pair and shown for comparison. The recommended coefficient "
         "is selected <b>per pair</b> based on: (1) normality of each variable "
         "(Shapiro-Wilk / KS-Lilliefors), (2) bivariate linearity (quadratic R² "
         "improvement test, threshold = 0.04), (3) bivariate outliers (Mahalanobis "
         "distance, χ², df = 2, p < .001), and (4) estimation stability (sample size "
         f"and tied-rank proportion). Method(s) used in this analysis: {used}."),
        ("Linearity assessment",
         "Bivariate linearity is assessed by comparing R² of a linear versus a "
         "quadratic model. Improvement ≥ 0.04 indicates non-linearity. Pearson r "
         "captures only linear association; Spearman ρ captures monotonic "
         "association regardless of functional form."),
        ("Bivariate outlier detection",
         "Mahalanobis distance is used to identify bivariate outliers relative to "
         "the χ² distribution (df = 2, p < .001 threshold ≈ 13.82). Outliers can "
         "substantially inflate or deflate Pearson r; Spearman ρ and Kendall τ₂ are "
         "considerably more robust to extreme bivariate observations."),
        ("Confidence intervals",
         f"{pct}% CIs for all three coefficients. Pearson and Spearman: Fisher "
         "z-transformation (Spearman with Bonett–Wright SE = 1.03/√(n−3)). "
         "Kendall τ₂: "
         + (f"percentile bootstrap ({n_boot:,} resamples, seed {seed})."
            if n_boot > 0 else "bootstrap disabled (enable in sidebar).")),
        ("Tests of normality",
         "Shapiro-Wilk (SW; primary when N < 50) and Kolmogorov-Smirnov with "
         "Lilliefors correction (KS; primary when N ≥ 50). p > .05 = normality "
         "satisfied. Non-normality in either variable of a pair requires a "
         "rank-based coefficient."),
        ("Two interpretation models",
         "<b>(A) Per-pair model</b>: each pair is interpreted using its own "
         "recommended method (Pearson, Spearman, or Kendall) based on its specific "
         "assumption profile. <b>(B) Overall model</b>: all pairs are interpreted "
         "using one consistent method — the overall recommended method (majority "
         "vote across all pairs) — for users who prefer a uniform approach."),
        ("Significance flags",
         "*** p < .001 &nbsp; ** p < .01 &nbsp; * p < .05 &nbsp; n.s. p ≥ α "
         "(two-tailed). Sig. (1-tailed) = Sig. (2-tailed) / 2."),
        ("References",
         "Cohen (1988); Field (2018); Bonett & Wright (2000); "
         "Efron & Tibshirani (1993); Lilliefors (1967); Mahalanobis (1936)."),
    ]


# ══════════════════════════════════════════════════════════════════════════════
# APA WRITE-UP
# ══════════════════════════════════════════════════════════════════════════════
def _build_apa_correlation(R, alpha):
    method = R["recommended_method"]
    mname  = {"pearson": "Pearson product-moment correlation",
               "spearman": "Spearman rank-order correlation",
               "kendall":  "Kendall rank-order correlation (tau-b)"}[method]
    sym    = {"pearson": "r", "spearman": "r_s", "kendall": "τ"}[method]
    n      = R["n"]
    lines  = [f"A {mname} was computed to assess the relationships between the "
              f"study variables (N = {n}). "]
    sig_p, ns_p = [], []
    for row in R["pairwise"].to_dict("records"):
        r  = row.get("r (rec)", np.nan)
        pv = row.get("p (2-tailed)", np.nan)
        v1, v2 = row["Variable 1"], row["Variable 2"]
        try:    pf = float(pv)
        except: pf = np.nan
        if not np.isnan(pf) and pf < alpha:
            ps = "< .001" if pf < .001 else f"= {pf:.3f}"
            sig_p.append(f"{v1} and {v2} ({sym} = {r:.2f}, p {ps})")
        else:
            ns_p.append(f"{v1} and {v2}")
    if sig_p:
        lines.append("Statistically significant correlations were observed between "
                     + "; ".join(sig_p) + ". ")
    if ns_p:
        lines.append("No statistically significant correlation was found between "
                     + "; ".join(ns_p) + ". ")
    return "".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
# PLOTS
# ══════════════════════════════════════════════════════════════════════════════
def _heatmap(coef_df, p_df, title):
    labels = list(coef_df.columns); k = len(labels)
    arr = coef_df.values.astype(float)
    fig, ax = plt.subplots(figsize=(max(4,k*1.1), max(3.4,k*1.0)))
    im = ax.imshow(arr, cmap="RdBu_r", vmin=-1, vmax=1, aspect="auto")
    ax.set_xticks(range(k)); ax.set_yticks(range(k))
    ax.set_xticklabels(labels, rotation=40, ha="right", fontsize=8)
    ax.set_yticklabels(labels, fontsize=8)
    for i in range(k):
        for j in range(k):
            r = arr[i,j]
            if np.isnan(r): continue
            p = p_df.values[i,j]
            star = ("***" if p<.001 else "**" if p<.01
                    else "*" if p<.05 else "") if i!=j else ""
            ax.text(j,i,f"{r:.2f}{star}",ha="center",va="center",fontsize=8,
                    fontweight="bold" if i!=j else "normal",
                    color="white" if abs(r)>0.55 else "#1a1a2e")
    ax.set_title(title, fontsize=10, fontweight="bold", color=PAL[0], pad=10)
    fig.colorbar(im,ax=ax,fraction=0.046,pad=0.04).ax.tick_params(labelsize=7)
    fig.patch.set_facecolor("white"); fig.tight_layout()
    return fig

def _scatter_matrix(matrix, var_names, method="pearson"):
    k = len(var_names)
    fig, axes = plt.subplots(k,k,figsize=(min(2.4*k,12),min(2.4*k,12)))
    if k==1: axes=np.array([[axes]])
    for i in range(k):
        for j in range(k):
            ax=axes[i,j]; ax.set_facecolor(BG)
            ax.spines[["top","right"]].set_visible(False)
            if i==j:
                ax.hist(matrix[:,i],bins=12,color=PAL[2],edgecolor="white",alpha=.85)
            else:
                x=matrix[:,j]; y=matrix[:,i]
                ax.scatter(x,y,s=16,color=PAL[1],alpha=.6,
                           edgecolors="white",linewidths=.4)
                try:
                    b=np.polyfit(x,y,1)
                    xs=np.linspace(x.min(),x.max(),50)
                    ax.plot(xs,np.polyval(b,xs),color=PAL[0],lw=1.4)
                except Exception: pass
            if i==k-1: ax.set_xlabel(var_names[j],fontsize=8,color=PAL[0])
            if j==0:   ax.set_ylabel(var_names[i],fontsize=8,color=PAL[0])
            ax.tick_params(labelsize=6)
    fig.suptitle("Scatterplot Matrix",fontsize=11,fontweight="bold",
                 color=PAL[0],y=1.0)
    fig.patch.set_facecolor("white"); fig.tight_layout()
    return fig


# ══════════════════════════════════════════════════════════════════════════════
# MATRIX ROWS
# ══════════════════════════════════════════════════════════════════════════════
def _matrix_rows(coef_df, p_df, n, p1_df=None, cov_df=None, sscp_df=None):
    labels = list(coef_df.columns)
    rows   = [["",""] + labels]
    for i, ri in enumerate(labels):
        rc=[ri,"Correlation"]; p1c=["","Sig. (1-tailed)"]
        p2c=["","Sig. (2-tailed)"]; nc=["","N"]
        covc=["","Covariance"]; ssc=["","Sum of Squares and Cross-products"]
        for j in range(len(labels)):
            if i==j:
                rc.append("1"); p1c.append("—"); p2c.append("—"); nc.append(str(n))
                if cov_df  is not None: covc.append(_f(cov_df.values[i,j]))
                if sscp_df is not None: ssc.append(_f(sscp_df.values[i,j]))
            else:
                r=coef_df.values[i,j]; p2=p_df.values[i,j]
                star="***" if p2<.001 else "**" if p2<.01 else "*" if p2<.05 else ""
                rc.append(f"{r:.3f}{star}")
                p2c.append(_p(p2))
                p1c.append(_p(p1_df.values[i,j]) if p1_df is not None else _p(p2/2))
                nc.append(str(n))
                if cov_df  is not None: covc.append(_f(cov_df.values[i,j]))
                if sscp_df is not None: ssc.append(_f(sscp_df.values[i,j]))
        rows.extend([rc,p1c,p2c])
        if cov_df  is not None: rows.append(covc)
        if sscp_df is not None: rows.append(ssc)
        rows.append(nc)
    return rows


# ══════════════════════════════════════════════════════════════════════════════
# HTML EXPORT
# ══════════════════════════════════════════════════════════════════════════════
def _build_html_correlation(R, meta, apa, figs_b, alpha):
    import base64
    try:
        from modules.normality import KS_DISCLAIMER
    except Exception:
        KS_DISCLAIMER = ("The Kolmogorov-Smirnov test uses the Lilliefors "
                         "significance correction.")
    method=R["recommended_method"]; var_names=R["var_names"]
    pct=int((1-alpha)*100)

    def _rtbl(rows,lc=None):
        lc=lc or {0}
        h='<table class="rtbl"><thead><tr>'
        for c in rows[0]: h+=f"<th>{c}</th>"
        h+="</tr></thead><tbody>"
        for idx,row in enumerate(rows[1:]):
            h+=f'<tr class="{"even" if idx%2==0 else "odd"}">'
            for j,cell in enumerate(row):
                cls=' class="left"' if j in lc else ""
                h+=f"<td{cls}>{cell}</td>"
            h+="</tr>"
        return h+"</tbody></table>"

    def _sub(t): return f'<div class="sub-hdr">{t}</div>'
    def _sh(t,n): return f'<div class="sec-hdr"><span class="sec-num">{n}</span>{t}</div>'
    def _dftbl(df,lc=None):
        rows=[list(df.columns)]
        for idx in df.index:
            rows.append([_f(v) if isinstance(v,(int,float,np.floating))
                         else str(v) for v in df.loc[idx]])
        return _rtbl(rows,lc)

    # Descriptives
    desc_html=_dftbl(R["descriptives"])
    desc_html+='<p class="tbl-note">Median included. Skewness and Kurtosis: bias-corrected estimators (G1, G2), identical to SPSS.</p>'

    # Normality
    nr=[["Variable","N","SW W","SW Sig.","KS D","KS Sig.ᵃ","Primary","Decision"]]
    for v in var_names:
        nz=R["normality"][v]
        nr.append([v,str(nz.get("n","")),_f(nz.get("sw_W")),_p(nz.get("sw_p")),
                   _f(nz.get("ks_D")),_p(nz.get("ks_p")),
                   nz.get("primary_label","Shapiro-Wilk"),
                   "✓ Normal" if nz.get("pass") else "✗ Non-Normal"])
    norm_html=(_rtbl(nr)
               +f'<p class="tbl-note">ᵃ Lilliefors correction. {KS_DISCLAIMER} '
                f'SW primary for N&lt;50; KS primary for N≥50.</p>')

    # Bivariate Assumption Checks
    bva=R.get("bivariate_assumptions",[])
    bva_html=""
    if bva:
        ba_rows=[["Pair","Normal?","Linear?","Outliers?","Recommended"]]
        for ba in bva:
            ba_rows.append([ba["pair"],
                "✓ Yes" if ba["normal"]  else "✗ No",
                "✓ Yes" if ba["linear"]  else "✗ No",
                f"⚠ {ba['n_outliers']} detected" if ba["outlier"] else "✓ None",
                ba["recommended"]])
        bva_html=_rtbl(ba_rows,lc={0,4})
        bva_html+=('<p class="tbl-note">'
                   '<b>Normal?</b>: both variables pass the primary normality test (p&gt;.05). '
                   '<b>Linear?</b>: quadratic R² improvement &lt;0.04. '
                   '<b>Outliers?</b>: Mahalanobis distance (χ², df=2, p&lt;.001). '
                   '<b>Recommended</b>: the appropriate coefficient for this pair '
                   'based on all checks above.</p>')
        for ba in bva:
            bva_html+=(f'<div class="rec-box"><b>{ba["pair"]}</b> → '
                       f'<b>{ba["recommended"]}</b><br/>{_strip(ba["basis"])}</div>')

    # Recommended summary (rich table)
    pw=R["pairwise"].copy()
    pub=[c for c in pw.columns if not str(c).startswith("_")]
    pw_pub=pw[pub]
    pair_html=_dftbl(pw_pub)
    _nb=R.get("n_boot",0); _seed=R.get("bootstrap_seed",42)
    pair_html+=(f'<p class="tbl-note">'
                f'<b>r (rec)</b>: value of the recommended coefficient per pair. '
                f'<b>SE (rec)</b>: standard error. <b>CI ({pct}%)</b>: Pearson & '
                f'Spearman via Fisher z-transformation; Kendall via '
                +(f'bootstrap ({_nb:,} resamples, seed {_seed}).' if _nb>0
                  else 'bootstrap disabled.')
                +' <b>Normal/Linear/Outliers?</b>: assumption check results. '
                f'Pearson r, Spearman ρ, and Kendall τ₂ all shown for comparison.</p>')

    # Matrices
    mats_html=""
    for m,nm,p1k in [("pearson","Pearson","p1_pearson"),
                      ("spearman","Spearman","p1_spearman"),
                      ("kendall","Kendall's tau-b","p1_kendall")]:
        if m=="pearson":
            rows=_matrix_rows(R["coef_pearson"],R["p_pearson"],R["n"],
                              p1_df=R.get("p1_pearson"),
                              cov_df=R.get("covariance"),sscp_df=R.get("sscp"))
        else:
            rows=_matrix_rows(R[f"coef_{m}"],R[f"p_{m}"],R["n"],p1_df=R.get(f"p1_{m}"))
        mats_html+=_sub(f"{nm} Correlation Matrix")+_rtbl(rows,lc={0,1})
    mats_html+=('<p class="tbl-note">Significance flags: *** p&lt;.001 &nbsp; '
                '** p&lt;.01 &nbsp; * p&lt;.05 (two-tailed). '
                'Sig.(1-tailed) = Sig.(2-tailed)/2. '
                'Covariance and SSCP shown only for Pearson '
                '(matches SPSS Correlate → Options → Cross-product deviations and covariances).</p>')

    # Interpretation — per-pair model (Model A)
    interp_A=""
    for it in R["interpretations"]:
        cls="interp sig" if it.get("sig") else "interp"
        _nv=it.get("normal",None); _lv=it.get("linear",None)
        _ov=it.get("outlier",None); _nout=it.get("n_out",0)
        ni=("✓ Normal"     if _nv is True  else
            "✗ Non-Normal" if _nv is False else "— Unknown")
        li=("✓ Linear"     if _lv is True  else
            "✗ Non-Linear" if _lv is False else "— Unknown")
        oi=(f"⚠ {_nout} Outlier(s)" if _ov else "✓ No Outliers")
        interp_A+=(f'<div class="{cls}">{it["text"]}'
                   f'<br/><span style="font-size:.76rem;color:#475569;">'
                   f'<b>Method</b>: {it["method"]} | {ni} | {li} | {oi}<br/>'
                   f'<i>{_strip(it.get("basis",""))}</i></span></div>')

    # Interpretation — overall model (Model B): per-pair text, one consistent method
    ovr_method = _METHOD_NAME.get(R.get("overall_method","pearson"),"")
    interp_B=""
    for it in R.get("interpretations_overall",[]):
        cls="interp sig" if it.get("sig") else "interp"
        interp_B+=f'<div class="{cls}">{it["text"]}</div>'

    interp_html=(f'<div class="sub-hdr">Model A: Per-Pair Recommended Method</div>'
                 +interp_A
                 +f'<div class="sub-hdr">Model B: Overall Recommended Method '
                 f'(Consistent — {ovr_method})</div>'
                 +f'<p class="tbl-note">All pairs interpreted using <b>{ovr_method}</b> '
                 f'— the majority recommendation across all pairs based on assumption checks.</p>'
                 +interp_B
                 +f'<div class="apa-label">APA 7th Edition Write-Up</div>'
                 +f'<div class="apa-box">{apa}</div>')

    # Notes
    notes_html=""
    for title,txt in _methodological_notes(R,alpha):
        notes_html+=f'<div class="rec-box"><b>{title}.</b> {txt}</div>'

    # Figures
    figs_html=""
    caps=["Correlation heatmap (recommended method).",
          "Scatterplot matrix with linear fit and marginal histograms."]
    for k2,fb in enumerate(figs_b):
        b64=base64.b64encode(fb).decode()
        cap=caps[k2] if k2<len(caps) else ""
        figs_html+=(f'<div class="fig-wrap">'
                    f'<img src="data:image/png;base64,{b64}" '
                    f'style="max-width:100%;border:1px solid #e2e8f0;border-radius:8px;"/>'
                    f'<div class="fig-cap">{cap}</div></div>')

    meta_html='<table class="meta-tbl">'
    for k2,v in meta.items():
        meta_html+=f'<tr><td class="mk">{k2}</td><td class="mv">{v}</td></tr>'
    meta_html+="</table>"
    dcls="use-param" if method=="pearson" else "use-nonparam"

    css="""<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=DM+Sans:wght@300;400;600;700&display=swap');
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:#f0f4f8;color:#1e293b;font-size:14px;line-height:1.6;}
.page{max-width:1120px;margin:0 auto;padding:32px 24px 80px;}
.cover{background:linear-gradient(135deg,#0a0a0a,#1a1a2e 50%,#16213e);border-radius:16px;
  padding:44px 52px;margin-bottom:28px;border-left:6px solid #e94560;}
.cover h1{color:#fff;font-size:2rem;font-weight:700;margin-bottom:8px;}
.cover .badge{display:inline-block;background:#e94560;color:#fff;font-size:.7rem;
  padding:3px 10px;border-radius:20px;font-weight:600;margin-right:6px;}
.meta-tbl{width:100%;border-collapse:collapse;margin-top:20px;}
.meta-tbl td{padding:5px 10px;font-size:.82rem;}
.meta-tbl td.mk{color:#94a3b8;font-weight:600;width:220px;font-family:'DM Mono',monospace;}
.meta-tbl td.mv{color:#e2e8f0;}
.use-param{background:#dcfce7;color:#14532d;border:1px solid #86efac;
  padding:12px 20px;border-radius:10px;margin:16px 0;}
.use-nonparam{background:#ffedd5;color:#7c2d12;border:1px solid #fdba74;
  padding:12px 20px;border-radius:10px;margin:16px 0;}
.section{background:#fff;border-radius:12px;padding:26px 30px;margin-bottom:22px;
  box-shadow:0 2px 14px rgba(0,0,0,.06);}
.sec-hdr{background:linear-gradient(90deg,#1a1a2e,#16213e);color:#e2e8f0;
  padding:11px 20px;border-radius:8px 8px 0 0;font-weight:700;font-size:.82rem;
  margin:-26px -30px 22px;border-bottom:3px solid #e94560;
  display:flex;align-items:center;gap:12px;}
.sec-num{background:#e94560;color:#fff;font-size:.72rem;padding:2px 8px;
  border-radius:12px;font-weight:700;}
.sub-hdr{background:#f1f5f9;color:#1a1a2e;padding:8px 14px;border-radius:6px;
  font-weight:600;font-size:.8rem;margin:18px 0 10px;border-left:3px solid #e94560;}
.rec-box{background:linear-gradient(135deg,#f0f9ff,#e0f2fe);
  border-left:4px solid #0284c7;padding:12px 16px;border-radius:0 8px 8px 0;
  font-size:.82rem;color:#0c4a6e;margin:10px 0;line-height:1.75;}
.rtbl{width:100%;border-collapse:collapse;font-family:'DM Mono',monospace;
  font-size:.72rem;margin-bottom:6px;table-layout:fixed;word-wrap:break-word;}
.rtbl th{background:#1a1a2e;color:#e2e8f0;padding:7px 9px;text-align:center;
  font-weight:600;border:1px solid #334155;}
.rtbl td{padding:5px 9px;border:1px solid #e2e8f0;text-align:right;word-wrap:break-word;}
.rtbl tr.even td{background:#fff;}.rtbl tr.odd td{background:#f8fafc;}
.rtbl td.left{text-align:left;font-weight:500;background:#f1f5f9!important;}
.tbl-note{font-size:.73rem;color:#64748b;font-style:italic;margin-top:8px;line-height:1.6;}
.interp{padding:12px 18px;border-radius:0 10px 10px 0;margin:10px 0;
  font-size:.85rem;line-height:1.8;border-left:4px solid #0284c7;
  background:linear-gradient(135deg,#f8fafc,#f1f5f9);}
.interp.sig{border-left-color:#16a34a;background:linear-gradient(135deg,#f0fdf4,#dcfce7);}
.apa-label{font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;
  letter-spacing:.8px;margin:14px 0 6px;}
.apa-box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;
  padding:14px 18px;font-family:'DM Mono',monospace;font-size:.78rem;line-height:1.8;}
.fig-wrap{text-align:center;margin:18px 0;}
.fig-cap{font-size:.75rem;color:#64748b;font-style:italic;margin-top:10px;}
.footer{text-align:center;color:#94a3b8;font-size:.72rem;margin-top:44px;
  padding-top:16px;border-top:1px solid #e2e8f0;}
</style>"""

    html=f"""<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"/>
<title>Correlation Report</title>{css}</head><body><div class="page">
<div class="cover">
  <h1>🔗 Bivariate Correlation Report</h1>
  <div style="margin-bottom:16px;">
    <span class="badge">SPSS-Equivalent</span>
    <span class="badge">Pearson + Spearman + Kendall</span>
    <span class="badge">Beyond SPSS</span>
  </div>{meta_html}
</div>
<div class="section">
  <div class="sec-hdr"><span class="sec-num">▶</span>COEFFICIENT RECOMMENDATION</div>
  <div class="{dcls}">🎯 Overall recommended: <b>{_METHOD_NAME[method]}</b></div>
  <div class="rec-box">{R["rationale"]}</div>
</div>
<div class="section">{_sh("DESCRIPTIVE STATISTICS",1)}{desc_html}</div>
<div class="section">{_sh("TESTS OF NORMALITY",2)}{norm_html}</div>
<div class="section">{_sh("BIVARIATE ASSUMPTION CHECKS",3)}{bva_html}</div>
<div class="section">{_sh("RECOMMENDED CORRELATION SUMMARY",4)}{pair_html}</div>
<div class="section">{_sh("FULL CORRELATION MATRICES",5)}{mats_html}</div>
<div class="section">{_sh("VISUALISATIONS",6)}{figs_html}</div>
<div class="section">{_sh("INTERPRETATION",7)}{interp_html}</div>
<div class="section">{_sh("METHODOLOGICAL NOTES",8)}{notes_html}</div>
<div class="footer">Generated by Inferential Statistics by MA ·
{datetime.now().strftime("%B %d, %Y at %H:%M")}</div>
</div></body></html>"""
    return html.encode("utf-8")


# ══════════════════════════════════════════════════════════════════════════════
# CSV EXPORT
# ══════════════════════════════════════════════════════════════════════════════
def _build_csv_correlation(R, meta, apa, alpha):
    import io, csv
    buf=io.StringIO(); w=csv.writer(buf)
    pct=int((1-alpha)*100)
    w.writerow(["Bivariate Correlation Report"])
    for k,v in meta.items(): w.writerow([k,v])
    w.writerow([])
    w.writerow(["Overall recommended coefficient",_METHOD_NAME[R["recommended_method"]]])
    w.writerow([])

    w.writerow(["DESCRIPTIVE STATISTICS"])
    w.writerow(list(R["descriptives"].columns))
    for idx in R["descriptives"].index: w.writerow(list(R["descriptives"].loc[idx]))
    w.writerow([])

    w.writerow(["TESTS OF NORMALITY"])
    w.writerow(["Variable","N","SW W","SW Sig.","KS D","KS Sig.","Primary","Decision"])
    for v in R["var_names"]:
        nz=R["normality"][v]
        w.writerow([v,nz.get("n",""),_f(nz.get("sw_W")),_p(nz.get("sw_p")),
                    _f(nz.get("ks_D")),_p(nz.get("ks_p")),
                    nz.get("primary_label","SW"),
                    "Normal" if nz.get("pass") else "Non-Normal"])
    w.writerow([])

    bva=R.get("bivariate_assumptions",[])
    if bva:
        w.writerow(["BIVARIATE ASSUMPTION CHECKS"])
        w.writerow(["Pair","Normal?","Linear?","Outliers?","Recommended","Decision Basis"])
        for ba in bva:
            w.writerow([ba["pair"],
                "Yes" if ba["normal"]  else "No",
                "Yes" if ba["linear"]  else "No",
                f"{ba['n_outliers']} detected" if ba["outlier"] else "None",
                ba["recommended"],
                _strip(ba["basis"])])
        w.writerow([])

    w.writerow(["RECOMMENDED CORRELATION SUMMARY"])
    pw=R["pairwise"].copy()
    pub=[c for c in pw.columns if not str(c).startswith("_")]
    w.writerow(pub)
    for idx in pw.index: w.writerow([str(pw.loc[idx,c]) for c in pub])
    w.writerow([])

    for m,nm,p1k in [("pearson","PEARSON","p1_pearson"),
                      ("spearman","SPEARMAN","p1_spearman"),
                      ("kendall","KENDALL TAU-B","p1_kendall")]:
        w.writerow([f"{nm} MATRIX"])
        df=R[f"coef_{m}"]; pdf=R[f"p_{m}"]; p1df=R.get(p1k)
        cols=list(df.columns)
        w.writerow(["",""]+cols)
        for idx in df.index:
            w.writerow([idx,"Correlation"]+[round(float(v),3) for v in df.loc[idx]])
            p1r,p2r=[],[]
            for jc in cols:
                if idx==jc: p1r.append(""); p2r.append("")
                else:
                    p2v=pdf.loc[idx,jc]
                    p1v=p1df.loc[idx,jc] if p1df is not None else p2v/2
                    p1r.append(_p(p1v)); p2r.append(_p(p2v))
            w.writerow([idx,"Sig. (1-tailed)"]+p1r)
            w.writerow([idx,"Sig. (2-tailed)"]+p2r)
            if m=="pearson" and R.get("covariance") is not None:
                w.writerow([idx,"Covariance"]+[round(float(v),3) for v in R["covariance"].loc[idx]])
            if m=="pearson" and R.get("sscp") is not None:
                w.writerow([idx,"Sum of Squares and Cross-products"]+[round(float(v),3) for v in R["sscp"].loc[idx]])
            w.writerow([idx,"N"]+[R["n"]]*len(cols))
        w.writerow([])

    w.writerow(["INTERPRETATION — MODEL A: PER-PAIR RECOMMENDED METHOD"])
    w.writerow(["Each pair uses its own recommended method based on assumption checks."])
    for it in R["interpretations"]:
        _nv=it.get("normal",None); _lv=it.get("linear",None)
        _ov=it.get("outlier",None); _nout=it.get("n_out",0)
        ni=("Normal"     if _nv is True  else
            "Non-Normal" if _nv is False else "Unknown")
        li=("Linear"     if _lv is True  else
            "Non-Linear" if _lv is False else "Unknown")
        oi=(f"{_nout} outlier(s) detected" if _ov else "No outliers")
        w.writerow([it["pair"],_strip(it["text"])])
        w.writerow(["",f"Method: {it['method']} | Normal: {ni} | Linear: {li} | Outliers: {oi}"])
        w.writerow(["",f"Basis: {_strip(it.get('basis',''))}"])
    w.writerow([])

    ovr_method=_METHOD_NAME.get(R.get("overall_method","pearson"),"")
    w.writerow([f"INTERPRETATION — MODEL B: OVERALL RECOMMENDED METHOD ({ovr_method})"])
    w.writerow([f"All pairs interpreted using {ovr_method} — the majority recommendation based on assumption checks."])
    for it in R.get("interpretations_overall",[]):
        w.writerow([it["pair"],_strip(it["text"])])
    w.writerow([])

    w.writerow(["APA WRITE-UP",apa])
    w.writerow([])
    w.writerow(["METHODOLOGICAL NOTES"])
    for title,txt in _methodological_notes(R,alpha):
        w.writerow([title,_strip(txt)])
    return buf.getvalue().encode("utf-8")


# ══════════════════════════════════════════════════════════════════════════════
# CSS + HEADER
# ══════════════════════════════════════════════════════════════════════════════
st.markdown(load_page_css(), unsafe_allow_html=True)
st.markdown("""
<div class="main-hdr">
  <h1>🔗 Bivariate Correlation
    <span class="badge">SPSS-Equivalent</span>
    <span class="badge">All: Pearson, Spearman, Kendall</span>
    <span class="badge">Beyond SPSS</span>
  </h1>
  <p>Pearson · Spearman's ρ · Kendall's τ-b · Normality · Linearity ·
     Outlier Detection · Per-pair &amp; overall coefficient recommendation</p>
</div>""", unsafe_allow_html=True)
st.markdown("""
<div style="margin-bottom:1rem;">
  <p style="color:#64748b;font-size:.9rem;margin-bottom:.4rem;">
    ☕ Support this work — scan QRIS:</p>
  <img src="https://mywebsite.com/media/thumbnails/QRIS-mywebsite-340x480.jpeg"
       style="width:180px;border-radius:10px;border:2px solid #e94560;display:block;"/>
</div>""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown("### ⚙️ Configuration")
    st.markdown("---")
    alpha  = st.selectbox("α Significance Level", [0.05,0.01,0.001], index=0)
    forced = None  # always auto per-pair
    use_bootstrap = st.checkbox(
        "📐 Bootstrap CI for Kendall's τ₂", value=False,
        help="Percentile bootstrap CIs for Kendall tau-b. "
             "Affects CI only; coefficients and p-values are analytic.")
    n_boot = 0
    if use_bootstrap:
        n_boot = st.selectbox("› Bootstrap resamples",[1000,2000,5000],index=1)
    st.markdown("---")
    samp_key="Bivariate Correlation"; samp=SAMPLES.get(samp_key)
    if samp is not None:
        st.markdown("**📄 Sample Data**")
        st.markdown(f'<p style="font-size:.8rem;color:#64748b;">{samp.get("note","")}</p>',
                    unsafe_allow_html=True)
        st.download_button("⬇️ Download Sample CSV",samp["csv"].encode(),
                           "sample_correlation.csv","text/csv",use_container_width=True)
        st.markdown("---")
    uploaded=st.file_uploader("📂 Upload Data File",type=["csv","xlsx","xls"])
    if uploaded:
        try:
            df=load_file(uploaded); fm=file_metadata(uploaded,df); val=validate_file(df)
            if val["errors"]:
                for e in val["errors"]: st.error(e)
                df=None
            else:
                st.success(f"✓ {fm['Rows']:,} rows × {fm['Columns']} cols")
                for wm in val["warnings"]: st.warning(wm)
        except Exception as e:
            st.error(str(e)); df=None
    elif samp is not None:
        df=load_from_string(samp["csv"]); st.info("ℹ️ Using built-in sample data")
    else:
        df=None
    cfg=None
    if df is not None:
        num_cols=get_numeric_cols(df)
        def _is_id(col,series):
            cl=col.lower().strip()
            idn={'id','no','num','number','index','code','nomor',
                 'subject_id','respondent','participant','sampel'}
            if not (cl in idn or cl.endswith(('_id','_no','_code'))
                    or cl.startswith(('id_','subject'))): return False
            s=series.dropna()
            try: return bool((s==s.astype(int)).all()) and s.nunique()==len(s)
            except: return False
        non_id=[c for c in num_cols if not _is_id(c,df[c])]
        st.markdown("---")
        sel=st.multiselect("📈 Variables (≥ 2)",num_cols,
                           default=non_id[:min(4,len(non_id))],key="corr_vars")
        cfg={"vars":sel} if len(sel)>=2 else None
        if not cfg: st.warning("Select at least 2 numeric variables.")
        st.markdown("---")
        run_btn=st.button("🚀 Run Analysis",type="primary",use_container_width=True)
    else:
        run_btn=False

if df is not None:
    with st.expander("🔍 Data Preview",expanded=False):
        st.dataframe(df.head(20),use_container_width=True)

if not run_btn and "corr_R" not in st.session_state:
    st.markdown(
        '<div style="background:linear-gradient(135deg,#f0f9ff,#e0f2fe);'
        'border:1px solid #bae6fd;border-radius:12px;padding:1.2rem 1.4rem;'
        'margin:.8rem 0;border-left:4px solid #0284c7;">'
        '<h4 style="margin:0 0 .4rem;">🔗 Bivariate Correlation</h4>'
        '<p style="margin:0;font-size:.84rem;color:#475569;">'
        'Select variables. App tests normality, linearity, and bivariate '
        'outliers per pair, then recommends Pearson r, Spearman ρ, or Kendall τ₂ '
        'with full academic justification. Two interpretation models provided.</p></div>',
        unsafe_allow_html=True)
    st.info("👈 Configure variables in the sidebar, then click **Run Analysis**.")
    st.stop()


# ══════════════════════════════════════════════════════════════════════════════
# RUN ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════
if run_btn:
    if cfg is None:
        st.error("⚠️ Please select at least 2 variables."); st.stop()
    with st.spinner("Running correlation analysis…"):
        try:
            sub=(df[cfg["vars"]].apply(pd.to_numeric,errors="coerce").dropna())
            if len(sub)<4:
                st.error("⚠️ At least 4 complete observations required."); st.stop()
            matrix=sub.values.astype(float)
            R=run_correlation(matrix,cfg["vars"],alpha=alpha,
                              forced_method=forced,n_boot=n_boot)
            meta={"Test":"Bivariate Correlation",
                  "Variables":", ".join(cfg["vars"]),
                  "N":R["n"],
                  "Overall Recommended":_METHOD_NAME[R["recommended_method"]],
                  "α":alpha,
                  "Date":datetime.now().strftime("%B %d, %Y %H:%M")}
            apa=_build_apa_correlation(R,alpha)
            _mlbls={"pearson":"Pearson r","spearman":"Spearman ρ","kendall":"Kendall's τ₂"}
            all_figs={}
            for _m in ["pearson","spearman","kendall"]:
                fh=_heatmap(R[f"coef_{_m}"],R[f"p_{_m}"],f"{_mlbls[_m]} Heatmap")
                hb=fig_to_bytes(fh); plt.close(fh)
                fs=_scatter_matrix(R["matrix_data"],R["var_names"],_m)
                sb=fig_to_bytes(fs); plt.close(fs)
                all_figs[_m]=[hb,sb]
            _k=len(R["var_names"])
            _fq,_aq=plt.subplots(2,_k,figsize=(max(4,3.5*_k),7))
            if _k==1: _aq=_aq.reshape(2,1)
            for _j,_vn in enumerate(R["var_names"]):
                _col=R["matrix_data"][:,_j]; _col=_col[~np.isnan(_col)]
                (_osm,_osr),(_sl,_ic,_)=scipy_stats.probplot(_col)
                _a0,_a1=_aq[0,_j],_aq[1,_j]
                _a0.scatter(_osm,_osr,s=18,color=PAL[1],alpha=.7,zorder=3)
                _a0.plot([_osm[0],_osm[-1]],[_sl*_osm[0]+_ic,_sl*_osm[-1]+_ic],
                         color=PAL[0],lw=1.5)
                _a0.set_title(f"Normal Q-Q: {_vn}",fontsize=9,fontweight="bold")
                _a0.set_xlabel("Theoretical Quantiles",fontsize=8)
                _a0.set_ylabel("Sample Quantiles",fontsize=8)
                _a0.tick_params(labelsize=7); _a0.grid(True,alpha=.3)
                _a0.set_facecolor("#f8fafc")
                _det=_osr-(_sl*_osm+_ic)
                _a1.scatter(_osm,_det,s=18,color=PAL[2],alpha=.7,zorder=3)
                _a1.axhline(0,color=PAL[0],lw=1.5)
                _a1.set_title(f"Detrended Q-Q: {_vn}",fontsize=9,fontweight="bold")
                _a1.set_xlabel("Theoretical Quantiles",fontsize=8)
                _a1.set_ylabel("Deviation",fontsize=8)
                _a1.tick_params(labelsize=7); _a1.grid(True,alpha=.3)
                _a1.set_facecolor("#f8fafc")
            _fq.suptitle("Normal Q-Q Plots",fontsize=11,fontweight="bold",
                          color=PAL[0],y=1.01)
            _fq.patch.set_facecolor("white"); _fq.tight_layout()
            qq_bytes=fig_to_bytes(_fq); plt.close(_fq)
            figs_b=all_figs[R["recommended_method"]]
        except Exception as e:
            import traceback as _tb
            st.error(f"⚠️ Analysis could not be completed: {e}")
            st.code(_tb.format_exc()); st.stop()
    st.session_state.update({
        "corr_R":R,"corr_meta":meta,"corr_apa":apa,
        "corr_figs":figs_b,"corr_all_figs":all_figs,
        "corr_qq":qq_bytes,"corr_alpha":alpha})

R        = st.session_state["corr_R"]
meta     = st.session_state["corr_meta"]
apa      = st.session_state["corr_apa"]
figs_b   = st.session_state["corr_figs"]
all_figs = st.session_state.get("corr_all_figs",{})
qq_bytes = st.session_state.get("corr_qq",None)
alpha    = st.session_state.get("corr_alpha",0.05)

st.success("✓ Analysis complete!")
mk=R["recommended_method"]
st.markdown(
    f'<div class="decision-banner {"use-param" if mk=="pearson" else "use-nonparam"}">'
    f'🎯 Overall recommended coefficient: <b>{_METHOD_NAME[mk]}</b></div>',
    unsafe_allow_html=True)
st.markdown(f'<div class="interp-box">{R["rationale"]}</div>',unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# TABS
# ══════════════════════════════════════════════════════════════════════════════
tab1,tab2,tab3,tab4=st.tabs([
    "📊 Descriptives & Normality",
    "🔗 Pearson Correlation",
    "📉 Non-Parametric Correlations",
    "📝 Interpretation"])


# ── TAB 1 ─────────────────────────────────────────────────────────────────────
with tab1:
    # Descriptives
    st.markdown('<div class="sec-title">Descriptive Statistics</div>',unsafe_allow_html=True)
    dcols=list(R["descriptives"].columns)
    drows=[dcols]+[[_f(v) if isinstance(v,(int,float,np.floating)) else str(v)
                    for v in R["descriptives"].loc[i]]
                   for i in R["descriptives"].index]
    st.markdown(html_tbl(drows,left_cols={0}),unsafe_allow_html=True)
    st.markdown('<p class="note-txt">Median included (beyond SPSS default). '
                'Skewness and Kurtosis: bias-corrected estimators (G1, G2), identical to SPSS. '
                'SE of Skewness and SE of Kurtosis provided for normality screening: '
                '|Skewness/SE| > 2 or |Kurtosis/SE| > 2 suggests departure from normality.</p>',
                unsafe_allow_html=True)

    # Normality
    st.markdown('<div class="sec-title">Tests of Normality</div>',unsafe_allow_html=True)
    nrows=[["Variable","N","SW W","SW Sig.","KS D","KS Sig.ᵃ","Primary Criterion","Decision"]]
    for v in R["var_names"]:
        nz=R["normality"][v]
        nrows.append([v,str(nz.get("n","")),_f(nz.get("sw_W")),_p(nz.get("sw_p")),
                      _f(nz.get("ks_D")),_p(nz.get("ks_p")),
                      nz.get("primary_label","Shapiro-Wilk"),
                      "✓ Normal" if nz.get("pass") else "✗ Non-Normal"])
    st.markdown(html_tbl(nrows,left_cols={0}),unsafe_allow_html=True)
    st.markdown('<p class="note-txt">ᵃ Lilliefors correction. '
                '<b>Primary criterion</b>: Shapiro-Wilk for N &lt; 50 (most powerful for small samples); '
                'Kolmogorov-Smirnov with Lilliefors correction for N ≥ 50. '
                'p &gt; .05 = normality assumption met. '
                'p ≤ .05 = normality violated; a rank-based coefficient (Spearman ρ or Kendall τ₂) '
                'is required for any pair involving this variable.</p>',
                unsafe_allow_html=True)

    # Bivariate Assumption Checks
    st.markdown('<div class="sec-title">Bivariate Assumption Checks '
                '(Linearity, Outliers &amp; Coefficient Selection)</div>',
                unsafe_allow_html=True)
    bva=R.get("bivariate_assumptions",[])
    if bva:
        ba_rows=[["Pair","Normal?","Linear?","Bivariate Outliers?","Recommended"]]
        for ba in bva:
            ba_rows.append([ba["pair"],
                "✓ Yes" if ba["normal"]  else "✗ No",
                "✓ Yes" if ba["linear"]  else "✗ No",
                f"⚠ {ba['n_outliers']} detected" if ba["outlier"] else "✓ None",
                ba["recommended"]])
        st.markdown(html_tbl(ba_rows,left_cols={0,4}),unsafe_allow_html=True)
        st.markdown(
            '<p class="note-txt">'
            '<b>Normal?</b>: ✓ = both variables in the pair pass the primary normality test (p &gt; .05); '
            '✗ = at least one variable violates normality, requiring a rank-based coefficient. '
            '<b>Linear?</b>: ✓ = bivariate relationship is approximately linear (quadratic R² '
            'improvement &lt; 0.04); ✗ = non-linear pattern detected (quadratic R² improvement ≥ 0.04), '
            'visible as curvature in the scatterplot — Pearson r would underestimate true association. '
            '<b>Bivariate Outliers?</b>: detected via Mahalanobis distance (χ², df = 2, p &lt; .001 '
            'threshold ≈ 13.82). Outliers inflate or deflate Pearson r; rank-based coefficients '
            'are more robust. '
            '<b>Recommended</b>: the most appropriate coefficient for this specific pair based on '
            'all checks above. Used in Model A (per-pair) interpretation in the Interpretation tab.</p>',
            unsafe_allow_html=True)
        with st.expander("🔎 Academic Decision Basis per Pair"):
            for ba in bva:
                st.markdown(
                    f'<div class="norm-rec-box">'
                    f'<b>{ba["pair"]}</b> → <b>{ba["recommended"]}</b><br/>'
                    f'{ba["basis"]}</div>',unsafe_allow_html=True)
    else:
        st.warning("⚠️ Bivariate assumption checks not available. "
                   "Please click **Run Analysis** again to generate results with the updated engine.")

    # QQ plots
    if qq_bytes is not None:
        st.markdown('<div class="sec-title">Normal Q-Q Plots &amp; Detrended Normal Q-Q Plots</div>',
                    unsafe_allow_html=True)
        st.image(qq_bytes,use_container_width=True)
        st.markdown('<p class="note-txt">'
                    '<b>Top row: Normal Q-Q</b> — points near the diagonal = approximate normality; '
                    'systematic curvature = skewness; S-shape = heavy tails. '
                    '<b>Bottom row: Detrended Q-Q</b> — deviations from the diagonal; '
                    'random scatter around zero = normality; systematic patterns = departure. '
                    'Matches SPSS Explore → Plots → Normal Plots with Tests.</p>',
                    unsafe_allow_html=True)


# ── TAB 2: Pearson ─────────────────────────────────────────────────────────────
with tab2:
    _rec=R["recommended_method"]
    if _rec=="pearson":
        st.markdown('<div class="decision-banner use-param">✓ <b>Pearson r</b> is the '
                    'overall recommended coefficient. Most pairs satisfy normality, '
                    'linearity, and have no bivariate outliers. See Bivariate Assumption '
                    'Checks in Tab 1 for pair-specific details.</div>',unsafe_allow_html=True)
    else:
        st.markdown(f'<div class="decision-banner use-nonparam">ℹ Pearson r shown for '
                    f'reference. Overall recommended: <b>{_METHOD_NAME[_rec]}</b> — see '
                    f'Non-Parametric tab. Individual pairs may differ; see Tab 1.</div>',
                    unsafe_allow_html=True)
    st.markdown('<div class="sec-title">Pearson Correlation Matrix</div>',unsafe_allow_html=True)
    rows_p=_matrix_rows(R["coef_pearson"],R["p_pearson"],R["n"],
                        p1_df=R.get("p1_pearson"),
                        cov_df=R.get("covariance"),sscp_df=R.get("sscp"))
    st.markdown(html_tbl(rows_p,left_cols={0,1}),unsafe_allow_html=True)
    st.markdown(
        '<p class="note-txt">'
        '<b>Pearson r</b>: ranges from −1 to +1. Interpretation (Cohen, 1988): '
        '|r| &lt; .10 negligible; .10–.29 weak; .30–.49 moderate; .50–.69 strong; ≥ .70 very strong. '
        '<b>Sig. (1-tailed)</b>: for directional hypotheses. '
        '<b>Sig. (2-tailed)</b>: for non-directional hypotheses; significant when p ≤ α. '
        '<b>Covariance</b> = Σ(x−x̄)(y−ȳ)/(N−1): positive = variables move together; '
        'negative = opposite direction; magnitude depends on measurement units. '
        '<b>SSCP</b> = Σ(x−x̄)(y−ȳ): cross-product deviations before dividing by (N−1); '
        'Covariance = SSCP/(N−1). Covariance and SSCP reported only for Pearson '
        '(matches SPSS Correlate → Options → Cross-product deviations and covariances). '
        'Significance flags: * p &lt; .05 &nbsp; ** p &lt; .01 &nbsp; *** p &lt; .001 (two-tailed).</p>',
        unsafe_allow_html=True)
    if all_figs.get("pearson"):
        st.markdown('<div class="sec-title">Pearson Correlation Heatmap</div>',unsafe_allow_html=True)
        st.image(all_figs["pearson"][0],use_container_width=True)
        st.markdown('<p class="note-txt">Colour intensity = strength of Pearson r. '
                    'Red = positive; blue = negative. Stars = significance flags.</p>',
                    unsafe_allow_html=True)
        st.markdown('<div class="sec-title">Scatterplot Matrix (Pearson)</div>',unsafe_allow_html=True)
        st.image(all_figs["pearson"][1],use_container_width=True)
        st.markdown('<p class="note-txt">Diagonal: variable distribution. '
                    'Off-diagonal: scatter with linear regression line. '
                    'Curved patterns suggest non-linearity — Pearson r may underestimate '
                    'true association in such cases.</p>',unsafe_allow_html=True)


# ── TAB 3: Non-Parametric ──────────────────────────────────────────────────────
with tab3:
    _rec=R["recommended_method"]
    if _rec in ("spearman","kendall"):
        st.markdown(f'<div class="decision-banner use-nonparam">⭐ <b>{_METHOD_NAME[_rec]}</b> '
                    f'is the overall recommended coefficient (normality and/or linearity '
                    f'assumption not met in the majority of pairs). See Tab 1 for '
                    f'pair-specific checks.</div>',unsafe_allow_html=True)
    else:
        st.markdown('<div class="decision-banner use-param">ℹ Non-parametric correlations '
                    'shown for reference. Pearson r is the overall recommended coefficient. '
                    'Individual pairs may still recommend Spearman or Kendall — see Tab 1.</div>',
                    unsafe_allow_html=True)

    # Spearman
    st.markdown('<div class="sec-title">Spearman\'s Rho (ρ) Correlation Matrix</div>',
                unsafe_allow_html=True)
    rows_s=_matrix_rows(R["coef_spearman"],R["p_spearman"],R["n"],p1_df=R.get("p1_spearman"))
    st.markdown(html_tbl(rows_s,left_cols={0,1}),unsafe_allow_html=True)
    st.markdown(
        '<p class="note-txt">'
        '<b>Spearman ρ</b>: rank-order correlation; measures the strength and direction of a '
        '<i>monotonic</i> relationship (as one variable increases, the other consistently '
        'increases or decreases, but not necessarily at a constant rate). Computed by '
        'ranking both variables and applying the Pearson formula to the ranks. '
        'Appropriate when: normality is violated, bivariate outliers are present, or '
        'the relationship is non-linear but monotonic. Same benchmarks as Pearson r (Cohen, 1988). '
        '<b>Sig. (1-tailed)</b> = Sig. (2-tailed)/2. '
        'Significance flags: * p &lt; .05 &nbsp; ** p &lt; .01 &nbsp; *** p &lt; .001 (two-tailed).</p>',
        unsafe_allow_html=True)
    if all_figs.get("spearman"):
        st.markdown('<div class="sec-title">Spearman Heatmap</div>',unsafe_allow_html=True)
        st.image(all_figs["spearman"][0],use_container_width=True)
        st.markdown('<div class="sec-title">Scatterplot Matrix (Spearman)</div>',unsafe_allow_html=True)
        st.image(all_figs["spearman"][1],use_container_width=True)
    st.markdown("---")

    # Kendall
    st.markdown('<div class="sec-title">Kendall\'s Tau-b (τ₂) Correlation Matrix</div>',
                unsafe_allow_html=True)
    rows_k=_matrix_rows(R["coef_kendall"],R["p_kendall"],R["n"],p1_df=R.get("p1_kendall"))
    st.markdown(html_tbl(rows_k,left_cols={0,1}),unsafe_allow_html=True)
    _nb=R.get("n_boot",0); _seed=R.get("bootstrap_seed",42)
    _boot_note=(f" Kendall CI: percentile bootstrap ({_nb:,} resamples, seed {_seed})."
                if _nb>0 else " Bootstrap CI disabled (enable in sidebar).")
    st.markdown(
        '<p class="note-txt">'
        '<b>Kendall τ₂</b>: counts concordant minus discordant pairs, adjusted for ties '
        '(tau-b variant, identical to SPSS). Preferred over Spearman ρ when: N &lt; 20, '
        'many tied ranks exist, or a more conservative and stable estimate is desired. '
        'Kendall τ values are typically smaller in magnitude than Spearman ρ for the same '
        'data but are considered more accurate in the presence of ties (Kendall, 1938). '
        '<b>Sig. (1-tailed)</b> = Sig. (2-tailed)/2. '
        'Significance flags: * p &lt; .05 &nbsp; ** p &lt; .01 &nbsp; *** p &lt; .001 '
        f'(two-tailed).{_boot_note}</p>',unsafe_allow_html=True)
    if all_figs.get("kendall"):
        st.markdown('<div class="sec-title">Kendall Heatmap</div>',unsafe_allow_html=True)
        st.image(all_figs["kendall"][0],use_container_width=True)
        st.markdown('<div class="sec-title">Scatterplot Matrix (Kendall)</div>',unsafe_allow_html=True)
        st.image(all_figs["kendall"][1],use_container_width=True)


# ── TAB 4: Interpretation ─────────────────────────────────────────────────────
with tab4:
    _pct=int((1-alpha)*100)
    _nb=R.get("n_boot",0); _seed=R.get("bootstrap_seed",42)

    # Rich summary table
    st.markdown('<div class="sec-title">Recommended Correlation Summary</div>',
                unsafe_allow_html=True)
    pw=R["pairwise"].copy()
    pub=[c for c in pw.columns if not str(c).startswith("_")]
    pw_pub=pw[pub]
    pcols=list(pw_pub.columns)
    prows=[pcols]+[[_f(v) if isinstance(v,(int,float,np.floating)) else str(v)
                    for v in pw_pub.loc[i]] for i in pw_pub.index]
    st.markdown(html_tbl(prows,left_cols={0,1,2}),unsafe_allow_html=True)
    st.markdown(
        f'<p class="note-txt">'
        f'<b>Recommended</b>: the coefficient selected per pair based on normality, '
        f'linearity, outlier, and estimation stability checks (see Tab 1). '
        f'<b>r (rec)</b>: value of the recommended coefficient. '
        f'<b>SE (rec)</b>: standard error of the recommended coefficient. '
        f'<b>CI ({_pct}%)</b>: Pearson & Spearman via Fisher z-transformation; '
        f'Kendall via '
        +(f'bootstrap ({_nb:,} resamples, seed {_seed}).' if _nb>0
          else 'bootstrap disabled (enable in sidebar).')
        +f' <b>Sig.</b>: *** p&lt;.001; ** p&lt;.01; * p&lt;.05; n.s. p≥{alpha}. '
        f'<b>Normal?</b>: ✓ both variables pass normality; ✗ violated. '
        f'<b>Linear?</b>: ✓ linear; ✗ non-linear. '
        f'<b>Outliers?</b>: ✓ none; ⚠ n detected. '
        f'Pearson r, Spearman ρ, and Kendall τ₂ all shown for comparison.</p>',
        unsafe_allow_html=True)

    st.markdown("---")

    # Model A: Per-pair
    ovr_label=_METHOD_NAME.get(R.get("overall_method","pearson"),"")
    st.markdown('<div class="sec-title">📌 Model A: Per-Pair Interpretation '
                '(Each pair uses its own recommended method)</div>',
                unsafe_allow_html=True)
    st.markdown(
        '<p class="note-txt" style="margin-bottom:.6rem;">'
        'Each pair is interpreted using its own recommended coefficient determined '
        'by the Bivariate Assumption Checks (normality, linearity, outliers). '
        'The assumption results and academic rationale are shown below each '
        'interpretation.</p>',unsafe_allow_html=True)
    for it in R["interpretations"]:
        _sc="sig" if it.get("sig") else ""
        _nv = it.get("normal", None)
        _lv = it.get("linear", None)
        _ov = it.get("outlier", None)
        _nout = it.get("n_out", 0)
        _ni = ("✓ Normal"     if _nv is True  else
               "✗ Non-Normal" if _nv is False else "— Unknown")
        _li = ("✓ Linear"     if _lv is True  else
               "✗ Non-Linear" if _lv is False else "— Unknown")
        _oi = (f"⚠ {_nout} Outlier(s)" if _ov else "✓ No Outliers")
        st.markdown(
            f'<div class="interp-box {_sc}">'
            f'{it["text"]}'
            f'<br/><span style="font-size:.78rem;color:#475569;margin-top:6px;display:block;">'
            f'<b>Method</b>: {it["method"]} &nbsp;|&nbsp; {_ni} &nbsp;|&nbsp; '
            f'{_li} &nbsp;|&nbsp; {_oi}'
            f'<br/><i>{it.get("basis","")}</i></span></div>',
            unsafe_allow_html=True)

    st.markdown("---")

    # Model B: Overall — all pairs use ONE consistent method, per-pair text
    st.markdown(f'<div class="sec-title">📌 Model B: Overall Interpretation '
                f'(All pairs use one consistent method: {ovr_label})</div>',
                unsafe_allow_html=True)
    st.markdown(
        f'<p class="note-txt" style="margin-bottom:.6rem;">'
        f'All pairs are interpreted using <b>{ovr_label}</b> — the overall '
        f'recommended method based on the majority of assumption check results. '
        f'Use this model when a single consistent method is preferred for all pairs.</p>',
        unsafe_allow_html=True)
    ovr_interps = R.get("interpretations_overall", [])
    if ovr_interps:
        for it in ovr_interps:
            _sc = "sig" if it.get("sig") else ""
            st.markdown(
                f'<div class="interp-box {_sc}">{it["text"]}</div>',
                unsafe_allow_html=True)
    else:
        st.warning("Overall interpretations not available. Please click Run Analysis.")

    st.markdown("---")

    # APA
    st.markdown('<div class="sec-title">APA 7th Edition Write-Up</div>',unsafe_allow_html=True)
    st.markdown(f'<div class="interp-box">{apa}</div>',unsafe_allow_html=True)

    # Methodological Notes
    st.markdown('<div class="sec-title">Methodological Notes</div>',unsafe_allow_html=True)
    for title,txt in _methodological_notes(R,alpha):
        st.markdown(f'<div class="norm-rec-box"><b>{title}.</b> {txt}</div>',
                    unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# DOWNLOADS
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("---")
st.markdown("### 📥 Export")
dc1,dc2=st.columns(2)
with dc1:
    with st.spinner("Generating HTML report…"):
        html_data=_build_html_correlation(R,meta,apa,figs_b,alpha)
    st.download_button("🌐 HTML Report (Full)",html_data,
                       f"Correlation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html",
                       "text/html",use_container_width=True)
with dc2:
    csv_data=_build_csv_correlation(R,meta,apa,alpha)
    st.download_button("📋 CSV Tables",csv_data,
                       f"Correlation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                       "text/csv",use_container_width=True)
