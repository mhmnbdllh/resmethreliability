"""
pages/3_ancova.py
=================
Streamlit page for ANCOVA family analysis.

Tests available:
  - One-Way ANCOVA
  - Factorial ANCOVA
  - Repeated Measures ANCOVA
  - Mixed ANCOVA
  - MANCOVA

Features:
  - SPSS-equivalent output (Type III SS, GG correction)
  - Normality criterion based on Total N
  - Partial η², Cohen's f, Power
  - Multiple post-hoc methods (LSD, Bonferroni, Sidak, Scheffe)
  - Mauchly's sphericity + GG epsilon
  - Multivariate tests (Wilks, Pillai, Hotelling, Roy)
  - EMMs + Pairwise comparisons
  - APA interpretation
  - HTML report + CSV download
"""

import streamlit as st
import pandas as pd
import numpy as np
import re
import warnings
from datetime import datetime

warnings.filterwarnings("ignore")

st.set_page_config(
    page_title="ANCOVA | Inferential Statistics by MA",
    page_icon="🎛️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Imports ────────────────────────────────────────────────────────────────
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from utils.styles      import load_page_css
from utils.file_loader import (load_file, load_from_string, validate_file,
                                file_metadata, get_numeric_cols,
                                get_categorical_cols)
from utils.samples     import SAMPLES
from utils.formatters  import _f, _p
from utils.tables      import html_tbl, normality_table

from modules.ancova    import (run_one_way_ancova, run_factorial_ancova,
                                run_rm_ancova, run_mixed_ancova, run_mancova,
                                transform_dependent, quade_ancova, bootstrap_ancova)
from modules.normality import (recommendation_note, KS_DISCLAIMER,
                                get_primary_label, get_total_n,
                                test_normality)

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import io, base64

PAL = ["#1a1a2e", "#e94560", "#0f3460", "#16213e",
       "#7c3aed", "#0891b2", "#16a34a", "#b45309"]
BG  = "#f8fafc"


# ══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _style_ax(ax):
    ax.set_facecolor(BG)
    ax.spines[["top","right"]].set_visible(False)
    ax.grid(axis="y", alpha=0.3, linestyle="--")

def _fig_b64(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=120, bbox_inches="tight", facecolor=BG)
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode()

def _effect_label(eta2):
    if np.isnan(eta2): return "N/A"
    if eta2 < .01:  return "negligible"
    if eta2 < .06:  return "small"
    if eta2 < .14:  return "medium"
    return "large"

def _is_id_col(col, series):
    cl = col.lower().strip()
    id_n = {'id','no','num','number','index','code','subject_id',
            'respondent','participant','sampel','nomor','subject'}
    id_s = ('_id','_no','_num','_number','_code','_index')
    id_p = ('id_','no_','num_','subject')
    nm = (cl in id_n or any(cl.endswith(s) for s in id_s)
          or any(cl.startswith(s) for s in id_p))
    if not nm: return False
    s = series.dropna()
    try: return bool((s == s.astype(int)).all()) and s.nunique() == len(s)
    except: return False

def _fmt_grand_cov(R):
    """Readable grand-mean covariate string. Handles dict (multi-cov),
    scalar (legacy single cov), or missing."""
    g = R.get("grand_cov_mean", None)
    if isinstance(g, dict):
        if not g:
            return "\u2014"
        return ", ".join(f"{k}\u2009=\u2009{_f(v)}" for k, v in g.items())
    try:
        if g is None or (isinstance(g, float) and np.isnan(g)):
            return "\u2014"
    except Exception:
        pass
    return _f(g)


def _guess_covariate(cols):
    """Guess the covariate column for RM/Mixed ANCOVA by name.
    Time-point columns form a series (time1/2/3, pre/mid/post); the covariate
    is a baseline/demographic measure. Returns the best covariate candidate."""
    kws = ['baseline','base_line','age','iq','covariate','_cov','ses',
           'income','weight','height','bmi','aptitude','motivation']
    for c in cols:
        cl = c.lower()
        if any(kw in cl for kw in kws):
            return c
    # Fallback: a column NOT matching time-series patterns
    time_pat = ('time','wave','t1','t2','t3','t4','pre','mid','post','week','month','day')
    non_time = [c for c in cols if not any(p in c.lower() for p in time_pat)]
    if non_time:
        return non_time[0]
    return cols[-1] if cols else None

def _render_df(df_, left_cols=None):
    """Render a DataFrame as html_tbl."""
    if df_ is None or (hasattr(df_,'empty') and df_.empty): return ""
    if left_cols is None: left_cols = {0}
    def _cell(v):
        if isinstance(v, str): return v if v else "\u2014"
        if isinstance(v, (int, np.integer)): return str(int(v))
        if isinstance(v, float) and not np.isnan(v): return _f(v)
        return "\u2014"
    rows = [list(df_.columns)]
    for _, row in df_.iterrows():
        rows.append([_cell(row[c]) for c in df_.columns])
    return html_tbl(rows, left_cols=left_cols)


# ══════════════════════════════════════════════════════════════════════════════
# INTERPRETATION HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _interpret(R, alpha):
    lines = []
    t = R["type"]
    nr = R.get("normality", {})
    norm_list = [nr] if isinstance(nr, dict) and "sw_W" in nr else []
    _cnt = {"n": 0}
    def NUM():
        _cnt["n"] += 1
        return _cnt["n"]

    def _sig(p_v):
        return "statistically significant" if not np.isnan(p_v) and p_v < alpha \
               else "not statistically significant"

    # Normality (univariate ANCOVA types: single residual set)
    if norm_list:
        prim = get_primary_label(norm_list)
        tn   = get_total_n(norm_list)
        size = "Total N\u2009<\u200950" if tn < 50 else "Total N\u2009\u2265\u200950"
        passed = norm_list[0].get("pass", False)
        lines.append(
            f"<b>{NUM()}. Normality of Residuals ({prim}, {size}):</b> "
            + (f"p\u2009>\u2009.05 \u2192 residuals are approximately normally distributed; "
               f"the normality assumption is satisfied."
               if passed else
               f"p\u2009\u2264\u2009.05 \u2192 residuals depart from normality. ANCOVA is "
               f"robust to moderate violations when N\u2009\u2265\u200930 and groups are "
               f"balanced; check for outliers and consider transforming the outcome "
               f"if the departure is severe. Interpret results with caution."))

    # Normality per dependent variable (MANCOVA)
    elif isinstance(nr, dict) and nr and all(isinstance(v, dict) and "sw_W" in v
                                             for v in nr.values()):
        prim = nr[list(nr.keys())[0]].get("primary_label", "Shapiro-Wilk")
        tn   = nr[list(nr.keys())[0]].get("total_n", "")
        size = "Total N\u2009<\u200950" if (isinstance(tn,(int,float)) and tn < 50) else "Total N\u2009\u2265\u200950"
        violated = [dv for dv, d in nr.items() if not d.get("pass", d.get("sw_pass", False))]
        passed_dvs = [dv for dv, d in nr.items() if dv not in violated]
        if not violated:
            txt = (f"Based on {prim} ({size}, the primary criterion), the residuals "
                   f"of all dependent variables ({', '.join(nr.keys())}) are "
                   f"approximately normally distributed. The (multivariate) normality "
                   f"assumption is reasonably supported.")
        else:
            txt = (f"Based on {prim} ({size}, the primary criterion), residuals for "
                   f"<b>{', '.join(violated)}</b> depart from normality"
                   + (f", while {', '.join(passed_dvs)} are normal" if passed_dvs else "")
                   + ". MANCOVA is robust to moderate, non-severe violations when group "
                   "sizes are balanced and N is adequate; for affected variables, "
                   "inspect outliers, consider a transformation, and prefer "
                   "<b>Pillai\u2019s Trace</b> (the multivariate statistic most robust "
                   "to assumption violations). Interpret the corresponding results "
                   "with appropriate caution.")
        lines.append(f"<b>{NUM()}. Normality of Residuals (per dependent variable):</b> {txt}")

    # Levene (univariate ANCOVA types)
    lev = R.get("levene", {})
    if lev:
        passed_l = lev.get("passed", lev.get("equal_var", False))
        lines.append(
            f"<b>{NUM()}. Homogeneity of Variance (Levene's):</b> "
            f"F\u2009=\u2009{_f(lev.get('F',np.nan))}, "
            f"p\u2009=\u2009{_p(lev.get('p',lev.get('Sig.',np.nan)))}. "
            + ("Equal variances assumed (p\u2009>\u2009.05)."
               if passed_l else
               "Unequal variances detected (p\u2009\u2264\u2009.05). "
               "Interpret results with caution."))

    # Levene per DV (MANCOVA)
    lev_mc = R.get("levene_mancova")
    if lev_mc is not None and hasattr(lev_mc, "empty") and not lev_mc.empty:
        try:
            sig_col = next(c for c in lev_mc.columns if "Sig" in str(c) or str(c).lower() == "p")
            pvals = pd.to_numeric(lev_mc[sig_col], errors="coerce")
            n_viol = int((pvals < alpha).sum())
        except Exception:
            n_viol = 0
        lines.append(
            f"<b>{NUM()}. Homogeneity of Error Variances (Levene's, per dependent variable):</b> "
            + ("All dependent variables satisfied equality of error variances "
               "(all p\u2009>\u2009.05)."
               if n_viol == 0 else
               f"{n_viol} dependent variable(s) showed unequal error variances "
               f"(p\u2009\u2264\u2009.05); interpret the corresponding univariate ANCOVA "
               f"with caution."))

    # Box's M (Mixed ANCOVA / MANCOVA)
    bm = R.get("boxes_m")
    if bm:
        try: pv_bm = float(bm.get("Sig.", np.nan))
        except Exception: pv_bm = np.nan
        lines.append(
            f"<b>{NUM()}. Box's Test of Equality of Covariance Matrices:</b> "
            f"Box's M\u2009=\u2009{_f(bm.get('M',np.nan))}, "
            f"F\u2009=\u2009{_f(bm.get('F',np.nan))}, p\u2009=\u2009{_p(pv_bm)}. "
            + ("Covariance matrices are equal across groups (p\u2009>\u2009.05)."
               if (not np.isnan(pv_bm) and pv_bm > .05) else
               "Covariance matrices may differ across groups (p\u2009\u2264\u2009.05); "
               "with equal group sizes the test is robust, otherwise interpret "
               "with caution."))

    # Homogeneity of slopes
    for skey, slbl in [("slopes",""), ("slopes_a"," \u2014 Factor A"),
                       ("slopes_b"," \u2014 Factor B")]:
        if skey in R:
            sl = R[skey]
            lines.append(
                f"<b>{NUM()}. Homogeneity of Regression Slopes{slbl}:</b> "
                f"F\u2009=\u2009{_f(sl.get('F',np.nan))}, "
                f"p\u2009=\u2009{_p(sl.get('p',np.nan))}. "
                + sl.get("note",""))

    # Main results
    if t == "One-Way ANCOVA":
        p = R.get("p_factor", np.nan)
        lines.append(
            f"<b>{NUM()}. Group Effect (adjusted):</b> "
            f"F\u2009=\u2009{_f(R.get('F_factor',np.nan))}, "
            f"p\u2009=\u2009{_p(p)}, "
            f"partial \u03b7\u00b2\u2009=\u2009{_f(R.get('partial_eta2',np.nan))} "
            f"({_effect_label(R.get('partial_eta2',np.nan))}). "
            f"After controlling for {R['cov_name']}, group differences were "
            f"<b>{_sig(p)}</b> at \u03b1\u2009=\u2009{alpha}.")
        lines.append(
            f"<b>{NUM()}. Estimated Marginal Means:</b> "
            f"Computed at grand mean of the covariate(s) ({_fmt_grand_cov(R)}). "
            f"These represent predicted scores for each group had all participants "
            f"started at the same covariate level \u2014 enabling a fairer group comparison.")

    elif t == "Factorial ANCOVA":
        for eff, fv, pv, eta, nm in [
            ("Factor A", R.get("F_a",np.nan), R.get("p_a",np.nan),
             R.get("eta2_a",np.nan), R.get("fa_name","A")),
            ("Factor B", R.get("F_b",np.nan), R.get("p_b",np.nan),
             R.get("eta2_b",np.nan), R.get("fb_name","B")),
            ("Interaction A\u00d7B", R.get("F_ab",np.nan), R.get("p_ab",np.nan),
             R.get("eta2_ab",np.nan), "A\u00d7B"),
        ]:
            lines.append(
                f"<b>{NUM()}. {eff} ({nm}):</b> "
                f"F\u2009=\u2009{_f(fv)}, p\u2009=\u2009{_p(pv)}, "
                f"partial \u03b7\u00b2\u2009=\u2009{_f(eta)} ({_effect_label(eta)}). "
                f"{_sig(pv).capitalize()} at \u03b1\u2009=\u2009{alpha}.")

    elif t == "Repeated Measures ANCOVA":
        p = R.get("p_time", np.nan)
        lines.append(
            f"<b>{NUM()}. Within-Subjects TIME Effect:</b> "
            f"F\u2009=\u2009{_f(R.get('F_time',np.nan))}, "
            f"p\u2009=\u2009{_p(p)}, "
            f"partial \u03b7\u00b2\u2009=\u2009{_f(R.get('eta2_time',np.nan))} "
            f"({_effect_label(R.get('eta2_time',np.nan))}). "
            f"GG corrected: p\u2009=\u2009{_p(R.get('p_time_gg',np.nan))} "
            f"(\u03b5\u2009=\u2009{_f(R.get('eps_gg',np.nan))}). "
            f"After adjusting for {R['cov_name']}, time effect was <b>{_sig(p)}</b>.")
        lines.append(
            f"<b>{NUM()}. Covariate ({R['cov_name']}):</b> "
            f"F\u2009=\u2009{_f(R.get('F_cov',np.nan))}, "
            f"p\u2009=\u2009{_p(R.get('p_cov',np.nan))}, "
            f"B\u2009=\u2009{_f(R.get('B_cov',np.nan))}. "
            + ("The covariate significantly predicted the outcome (between-subjects)."
               if not np.isnan(R.get("p_cov",np.nan)) and R.get("p_cov",1) < alpha
               else "The covariate did not significantly predict the outcome."))

    elif t == "Mixed ANCOVA":
        for eff, fv, pv in [
            ("Between-Subjects Factor", R.get("F_between",np.nan), R.get("p_between",np.nan)),
            ("Within-Subjects Time",    R.get("F_time",np.nan),    R.get("p_time",np.nan)),
            ("Interaction (Group\u00d7Time)", R.get("F_interact",np.nan), R.get("p_interact",np.nan)),
        ]:
            lines.append(
                f"<b>{NUM()}. {eff}:</b> "
                f"F\u2009=\u2009{_f(fv)}, p\u2009=\u2009{_p(pv)}. "
                f"{_sig(pv).capitalize()} at \u03b1\u2009=\u2009{alpha}.")

    elif t == "MANCOVA":
        mv = R.get("mv_factor") or {}
        if mv:
            lines.append(
                f"<b>{NUM()}. Multivariate Group Effect:</b> "
                f"Wilks\u2019 \u039b\u2009=\u2009{_f(mv.get('Wilks',np.nan))}, "
                f"F\u2009=\u2009{_f(mv.get('F_Wilks',np.nan))}, "
                f"p\u2009=\u2009{_p(mv.get('p_Wilks',np.nan))}. "
                f"After controlling for {R['cov_name']}, the combined dependent "
                f"variables were <b>{_sig(mv.get('p_Wilks',np.nan))}</b> across groups.")
        univ = R.get("univariate", pd.DataFrame())
        if univ is not None and not univ.empty:
            lines.append(f"<b>{NUM()}. Univariate Follow-Up ANCOVAs (per dependent variable):</b>")
            _skip_src = {"Corrected Model", "Intercept", "Error", "Corrected Total", "Total"}
            fac = R.get("factor_name", "group")
            for _, row in univ.iterrows():
                src = str(row.get("Source",""))
                if src in _skip_src or src == R.get("cov_name",""):
                    continue
                dv  = row.get("Dependent Variable","DV")
                pv  = row.get("Sig.", np.nan)
                eta = row.get("Partial \u03b7\u00b2", row.get("Partial η²", np.nan))
                try: pv  = float(pv)
                except Exception: pv = np.nan
                try: eta = float(eta)
                except Exception: eta = np.nan
                try: F_v = float(row.get("F", np.nan))
                except Exception: F_v = np.nan
                lines.append(
                    f"&nbsp;&nbsp;&bull; <b>{dv} \u2014 {src}:</b> "
                    f"F\u2009=\u2009{_f(F_v)}, "
                    f"p\u2009=\u2009{_p(pv)}, "
                    f"partial \u03b7\u00b2\u2009=\u2009{_f(eta)} ({_effect_label(eta)}). "
                    f"{_sig(pv).capitalize()}.")

    # Plain language
    lines.append(f"<b>{NUM()}. Plain Language Summary:</b> " + _plain(R, alpha))
    return lines


def _plain(R, alpha):
    t = R["type"]
    if t == "One-Way ANCOVA":
        sig = R.get("p_factor", 1) < alpha
        return (
            f"After accounting for {R['cov_name']}, the groups "
            f"{'differed significantly' if sig else 'did not differ significantly'} "
            f"in {R['y_name']}. The Estimated Marginal Means show what each group "
            f"would score if everyone started at the same covariate level "
            f"({_fmt_grand_cov(R)}).")
    if t == "Factorial ANCOVA":
        return (f"After adjusting for {R['cov_name']}, we examined how {R['fa_name']} "
                f"and {R['fb_name']} (and their combination) affected {R['y_name']}.")
    if t == "Repeated Measures ANCOVA":
        sig = R.get("p_time", 1) < alpha
        return (f"After controlling for {R['cov_name']}, scores across {R['T']} "
                f"time points changed "
                f"{'significantly' if sig else 'non-significantly'}.")
    if t == "Mixed ANCOVA":
        sig_i = R.get("p_interact", 1) < alpha
        return (f"After adjusting for {R['cov_name']}, "
                f"{'a significant interaction means the groups changed differently over time.' if sig_i else 'no significant interaction — groups changed similarly over time.'}")
    if t == "MANCOVA":
        mv = R.get("mv_factor") or {}
        sig = mv.get("p_Wilks", 1) < alpha
        return (f"After accounting for {R['cov_name']}, groups "
                f"{'differed significantly' if sig else 'did not differ significantly'} "
                f"on the combined outcome variables ({', '.join(R.get('y_names',[]))}).")
    return ""


# ══════════════════════════════════════════════════════════════════════════════
# INTERPRETATION STYLING + APA 7 REPORTING
# ══════════════════════════════════════════════════════════════════════════════

def _interp_cls(line):
    """Classify an interpretation line by statistical decision for colour-coding.

    Returns one of: 'sig' (green), 'nonsig' (amber/caution), 'summary' (blue),
    'neutral' (grey).
    """
    l = line.lower()
    # caution / non-significant / assumption violated
    if ("not statistically significant" in l or "did not significantly" in l
            or "may be violated" in l or "unequal variances detected" in l
            or "may differ across groups" in l or "interpret" in l and "caution" in l
            or "with caution" in l):
        return "nonsig"
    # significant / assumption satisfied (good)
    if ("statistically significant" in l or "significantly predicted" in l
            or "assumption is satisfied" in l or "approximately normally" in l
            or "equal variances assumed" in l or "are equal across groups" in l
            or "satisfied equality" in l):
        return "sig"
    if "plain language" in l:
        return "summary"
    return "neutral"


# inline-style palette per class (so it renders even without external CSS)
_INTERP_STYLE = {
    "sig":     ("#16a34a", "linear-gradient(135deg,#f0fdf4,#dcfce7)"),
    "nonsig":  ("#f59e0b", "linear-gradient(135deg,#fffbeb,#fef3c7)"),
    "summary": ("#0284c7", "linear-gradient(135deg,#f0f9ff,#e0f2fe)"),
    "neutral": ("#64748b", "linear-gradient(135deg,#f8fafc,#f1f5f9)"),
}


def _apa_report(R, alpha):
    """APA 7th-edition result statements — all F-statistics reported as
    F(df_effect, df_error) = value. Uses None-safe significance check."""
    t   = R["type"]
    out = []

    def _p_apa(p):
        try: p = float(p)
        except Exception: return "p = ?"
        if np.isnan(p): return "p = ?"
        return "p < .001" if p < .001 else f"p = {p:.3f}".replace("0.", ".")

    def _val(v, d=2):
        try:
            v = float(v)
            if np.isnan(v): return "?"
            return f"{v:.{d}f}"
        except Exception: return "?"

    def _sig(p):
        """None- and NaN-safe: 0.0 → significant (avoids Python 0.0-falsy bug)."""
        try:
            pf = float(p)
            return "significant" if not np.isnan(pf) and pf < alpha else "not significant"
        except Exception: return "not significant"

    def _F(f_val, df1, df2):
        """Format F(df1, df2) = value. Shows '?' for any missing piece."""
        def _d(x):
            if x is None or x == "": return "?"
            try:
                fx = float(x)
                return "?" if np.isnan(fx) else str(int(fx))
            except Exception: return "?"
        return f"F({_d(df1)}, {_d(df2)}) = {_val(f_val)}"

    cov = R.get("cov_name", "the covariate")

    # ── Normality statement (all types) ───────────────────────────────────
    nr = R.get("normality")
    if isinstance(nr, dict) and nr:
        if "sw_W" in nr:
            _ok = nr.get("pass", False)
            out.append(
                "Preliminary checks indicated that the assumption of normality of "
                "residuals was " + ("met" if _ok else "violated")
                + f" ({nr.get('primary_label','Shapiro\u2013Wilk')}, "
                + ("p > .05" if _ok else "p \u2264 .05") + ").")
        elif all(isinstance(v, dict) and "sw_W" in v for v in nr.values()):
            _viol = [dv for dv, d in nr.items() if not d.get("pass", False)]
            _lbl  = nr[list(nr.keys())[0]].get("primary_label","Shapiro\u2013Wilk")
            if not _viol:
                out.append(
                    "Preliminary checks indicated that the assumption of normality "
                    f"of residuals was met for all dependent variables ({_lbl}, all p > .05).")
            else:
                out.append(
                    "Preliminary checks indicated that the assumption of normality "
                    f"of residuals was violated for {', '.join(_viol)} ({_lbl}, "
                    "p \u2264 .05); Pillai\u2019s Trace was therefore emphasised as the "
                    "most robust multivariate criterion.")

    # ── Type-specific statements ──────────────────────────────────────────
    if t == "One-Way ANCOVA":
        out.append(
            f"A one-way ANCOVA was conducted to examine the effect of "
            f"{R.get('factor_name','group')} on {R.get('y_name','the outcome')} "
            f"while controlling for {cov}. "
            f"The effect of {R.get('factor_name','group')} was {_sig(R.get('p_factor'))}, "
            f"{_F(R.get('F_factor'), R.get('df_factor'), R.get('df_error'))}, "
            f"{_p_apa(R.get('p_factor'))}, "
            f"partial \u03b7\u00b2 = {_val(R.get('partial_eta2'),3)}.")

    elif t == "Factorial ANCOVA":
        df_err = R.get("df_error")
        for label, fk, pk, ek, dfk in [
            (R.get('fa_name','Factor A'), "F_a",  "p_a",  "eta2_a",  "df_a"),
            (R.get('fb_name','Factor B'), "F_b",  "p_b",  "eta2_b",  "df_b"),
            (f"{R.get('fa_name','A')} \u00d7 {R.get('fb_name','B')} interaction",
             "F_ab", "p_ab", "eta2_ab", "df_ab"),
        ]:
            out.append(
                f"The effect of {label} was {_sig(R.get(pk))}, "
                f"{_F(R.get(fk), R.get(dfk), df_err)}, "
                f"{_p_apa(R.get(pk))}, "
                f"partial \u03b7\u00b2 = {_val(R.get(ek),3)}, "
                f"after controlling for {cov}.")

    elif t == "Repeated Measures ANCOVA":
        out.append(
            f"A repeated-measures ANCOVA examined the within-subjects effect of "
            f"{R.get('time_name','time')} on {R.get('y_name','the outcome')}, "
            f"controlling for {cov}. "
            f"The time effect was {_sig(R.get('p_time'))}, "
            f"{_F(R.get('F_time'), R.get('df_time'), R.get('df_resid_within'))}, "
            f"{_p_apa(R.get('p_time'))}, "
            f"partial \u03b7\u00b2 = {_val(R.get('eta2_time'),3)}.")
        out.append(
            f"The covariate ({cov}) accounted for significant between-subjects "
            f"variability: {_sig(R.get('p_cov'))}, "
            f"{_F(R.get('F_cov'), R.get('df_cov'), R.get('df_err_between'))}, "
            f"{_p_apa(R.get('p_cov'))}.")

    elif t == "Mixed ANCOVA":
        out.append(
            f"A mixed ANCOVA examined the effects of "
            f"{R.get('between_name','group')} (between-subjects) and "
            f"{R.get('time_name','time')} (within-subjects) on "
            f"{R.get('y_name','the outcome')}, controlling for {cov}.")
        out.append(
            f"Between-subjects effect ({R.get('between_name','group')}): "
            f"{_sig(R.get('p_between'))}, "
            f"{_F(R.get('F_between'), R.get('df_between'), R.get('df_resid_between'))}, "
            f"{_p_apa(R.get('p_between'))}, "
            f"partial \u03b7\u00b2 = {_val(R.get('eta2_between'),3)}.")
        out.append(
            f"Within-subjects effect ({R.get('time_name','time')}): "
            f"{_sig(R.get('p_time'))}, "
            f"{_F(R.get('F_time'), R.get('df_time'), R.get('df_resid_within'))}, "
            f"{_p_apa(R.get('p_time'))}, "
            f"partial \u03b7\u00b2 = {_val(R.get('eta2_time'),3)}.")
        out.append(
            f"Interaction ({R.get('between_name','group')} \u00d7 "
            f"{R.get('time_name','time')}): "
            f"{_sig(R.get('p_interact'))}, "
            f"{_F(R.get('F_interact'), R.get('df_interact'), R.get('df_resid_within'))}, "
            f"{_p_apa(R.get('p_interact'))}, "
            f"partial \u03b7\u00b2 = {_val(R.get('eta2_interact'),3)}.")

    elif t == "MANCOVA":
        mv = R.get("mv_factor") or {}
        out.append(
            f"A one-way MANCOVA was conducted on the combined dependent variables "
            f"({', '.join(R.get('y_names', []))}) with "
            f"{R.get('factor_name','group')} as the independent variable, "
            f"controlling for {cov}. "
            f"Using Wilks\u2019 \u039b, the multivariate effect of "
            f"{R.get('factor_name','group')} was {_sig(mv.get('p_Wilks'))}, "
            f"\u039b = {_val(mv.get('Wilks'),3)}, "
            f"{_F(mv.get('F_Wilks'), mv.get('df_hyp_Wilks'), mv.get('df_err_Wilks'))}, "
            f"{_p_apa(mv.get('p_Wilks'))}.")
        univ = R.get("univariate", pd.DataFrame())
        if univ is not None and not univ.empty:
            fac = R.get("factor_name", "group")
            for _, row in univ.iterrows():
                if str(row.get("Source","")) != fac:
                    continue
                dv = row.get("Dependent Variable","DV")
                try: pv = float(row.get("Sig.", np.nan))
                except Exception: pv = np.nan
                try: fv = float(row.get("F", np.nan))
                except Exception: fv = np.nan
                try: df1u = int(float(row.get("df", 1)))
                except Exception: df1u = None
                df2u = R.get("df_error")
                out.append(
                    f"For {dv}, the univariate effect of {fac} was {_sig(pv)}, "
                    f"{_F(fv, df1u, df2u)}, "
                    f"{_p_apa(pv)}, "
                    f"partial \u03b7\u00b2 = {_val(row.get('Partial \u03b7\u00b2'),3)}.")

    return out

    # Normality assumption statement (APA style) — all types
    nr = R.get("normality")
    if isinstance(nr, dict) and nr:
        if "sw_W" in nr:  # single residual set (univariate ANCOVA types)
            _ok = nr.get("pass", False)
            out.append(
                "Preliminary checks indicated that the assumption of normality of "
                "residuals was "
                + ("met" if _ok else "violated")
                + f" ({nr.get('primary_label','Shapiro\u2013Wilk')} "
                + ("p > .05" if _ok else "p \u2264 .05") + ").")
        elif all(isinstance(v, dict) and "sw_W" in v for v in nr.values()):  # per-DV (MANCOVA)
            _viol = [dv for dv, d in nr.items() if not d.get("pass", False)]
            if not _viol:
                out.append(
                    "Preliminary checks indicated that the assumption of normality "
                    "of residuals was met for all dependent variables "
                    f"({nr[list(nr.keys())[0]].get('primary_label','Shapiro\u2013Wilk')}, "
                    "all p > .05).")
            else:
                out.append(
                    "Preliminary checks indicated that the assumption of normality "
                    f"of residuals was violated for {', '.join(_viol)} "
                    f"({nr[list(nr.keys())[0]].get('primary_label','Shapiro\u2013Wilk')}, "
                    "p \u2264 .05); Pillai\u2019s Trace was therefore emphasised as the "
                    "most robust multivariate criterion.")

    if t == "One-Way ANCOVA":
        df1 = R.get("df_factor", R.get("df_between", ""))
        df2 = R.get("df_error", "")
        out.append(
            f"A one-way ANCOVA was conducted to compare the effect of "
            f"{R.get('factor_name','group')} on {R.get('y_name','the outcome')} "
            f"while controlling for {cov}. "
            f"The effect of {R.get('factor_name','group')} was "
            f"{'significant' if R.get('p_factor') is not None and R.get('p_factor') < alpha else 'not significant'}, "
            f"F({df1}, {df2}) = {_val(R.get('F_factor'))}, {_p_apa(R.get('p_factor'))}, "
            f"partial \u03b7\u00b2 = {_val(R.get('partial_eta2'),3)}.")
    elif t == "Factorial ANCOVA":
        for eff, fk, pk, ek, nmk in [
            ("main effect of A","F_a","p_a","eta2_a","fa_name"),
            ("main effect of B","F_b","p_b","eta2_b","fb_name"),
            ("A \u00d7 B interaction","F_ab","p_ab","eta2_ab",None)]:
            nm = R.get(nmk, "factor") if nmk else "interaction"
            out.append(
                f"The {eff} ({nm}) was "
                f"{'significant' if R.get(pk) is not None and R.get(pk) < alpha else 'not significant'}, "
                f"F = {_val(R.get(fk))}, {_p_apa(R.get(pk))}, "
                f"partial \u03b7\u00b2 = {_val(R.get(ek),3)}, after controlling for {cov}.")
    elif t == "Repeated Measures ANCOVA":
        out.append(
            f"A repeated-measures ANCOVA examined the within-subjects effect of "
            f"{R.get('time_name','time')} on {R.get('y_name','the outcome')}, "
            f"controlling for {cov}. The time effect was "
            f"{'significant' if R.get('p_time') is not None and R.get('p_time') < alpha else 'not significant'}, "
            f"F = {_val(R.get('F_time'))}, {_p_apa(R.get('p_time'))}, "
            f"partial \u03b7\u00b2 = {_val(R.get('eta2_time'),3)}.")
    elif t == "Mixed ANCOVA":
        out.append(
            f"A mixed ANCOVA examined the effects of {R.get('between_name','group')} "
            f"(between-subjects) and {R.get('time_name','time')} (within-subjects) on "
            f"{R.get('y_name','the outcome')}, controlling for {cov}. "
            f"The between-subjects effect was "
            f"{'significant' if R.get('p_between') is not None and R.get('p_between') < alpha else 'not significant'} "
            f"(F = {_val(R.get('F_between'))}, {_p_apa(R.get('p_between'))}); the "
            f"interaction was "
            f"{'significant' if R.get('p_interact') is not None and R.get('p_interact') < alpha else 'not significant'} "
            f"(F = {_val(R.get('F_interact'))}, {_p_apa(R.get('p_interact'))}).")
    elif t == "MANCOVA":
        mv = R.get("mv_factor") or {}
        out.append(
            f"A one-way MANCOVA was conducted on the combined dependent variables "
            f"({', '.join(R.get('y_names', []))}) with {R.get('factor_name','group')} "
            f"as the independent variable, controlling for {cov}. "
            f"Using Wilks\u2019 \u039b, the multivariate effect of "
            f"{R.get('factor_name','group')} was "
            f"{'significant' if mv.get('p_Wilks') is not None and mv.get('p_Wilks') < alpha else 'not significant'}, "
            f"\u039b = {_val(mv.get('Wilks'),3)}, F = {_val(mv.get('F_Wilks'))}, "
            f"{_p_apa(mv.get('p_Wilks'))}.")
        univ = R.get("univariate", pd.DataFrame())
        if univ is not None and not univ.empty:
            fac = R.get("factor_name", "group")
            for _, row in univ.iterrows():
                if str(row.get("Source","")) != fac:
                    continue
                dv = row.get("Dependent Variable","DV")
                try: pv = float(row.get("Sig.", np.nan))
                except Exception: pv = np.nan
                out.append(
                    f"For {dv}, the univariate effect of {fac} was "
                    f"{'significant' if not np.isnan(pv) and pv < alpha else 'not significant'}, "
                    f"F = {_val(row.get('F'))}, {_p_apa(pv)}, "
                    f"partial \u03b7\u00b2 = {_val(row.get('Partial \u03b7\u00b2'),3)}.")
    return out


# ══════════════════════════════════════════════════════════════════════════════
# PLOTS
# ══════════════════════════════════════════════════════════════════════════════

def _make_plot(R):
    t = R["type"]
    figs = []

    # EMM bar (between-subjects)
    if t in ("One-Way ANCOVA", "Factorial ANCOVA"):
        emm = R.get("emm", pd.DataFrame())
        if not emm.empty and "Adjusted Mean" in emm.columns:
            fig, ax = plt.subplots(figsize=(7, 4), facecolor=BG)
            _style_ax(ax)
            groups = emm.iloc[:, 0].astype(str).values
            means  = emm["Adjusted Mean"].values.astype(float)
            ses    = emm["Std. Error"].values.astype(float)
            x_pos  = np.arange(len(groups))
            cols   = [PAL[i % len(PAL)] for i in range(len(groups))]
            ax.bar(x_pos, means, yerr=ses, capsize=5, color=cols,
                   alpha=0.82, width=0.6,
                   error_kw={"elinewidth":1.5,"ecolor":"#475569"})
            for i,(m,s) in enumerate(zip(means,ses)):
                ax.text(x_pos[i], m+s*1.15, f"{m:.2f}",
                        ha="center", va="bottom", fontsize=9, fontweight="600")
            ax.set_xticks(x_pos); ax.set_xticklabels(groups, fontsize=10)
            ax.set_ylabel(f"Adjusted Mean ({R.get('y_name','Y')})")
            ax.set_title("Estimated Marginal Means ± SE", fontweight="600")
            if t == "One-Way ANCOVA":
                ax.set_xlabel(R.get("factor_name","Group"))
            plt.tight_layout()
            figs.append(("Estimated Marginal Means", _fig_b64(fig)))

    # Profile plot (within-subjects)
    if t in ("Repeated Measures ANCOVA", "Mixed ANCOVA"):
        emm = R.get("emm", pd.DataFrame())
        t_col = R.get("time_name","Time")
        if not emm.empty and "Adjusted Mean" in emm.columns:
            fig, ax = plt.subplots(figsize=(8, 4.5), facecolor=BG)
            _style_ax(ax)
            if t == "Repeated Measures ANCOVA":
                times = emm[t_col].values
                means = emm["Adjusted Mean"].values.astype(float)
                ses   = emm["Std. Error"].values.astype(float)
                x = np.arange(len(times))
                ax.plot(x, means, "o-", color=PAL[1], lw=2.5, ms=8, zorder=3)
                ax.fill_between(x, means-ses, means+ses, alpha=0.18, color=PAL[1])
                for i,m in enumerate(means):
                    ax.text(x[i], m+ses[i]*1.1, f"{m:.2f}",
                            ha="center", fontsize=9, fontweight="600")
                ax.set_xticks(x); ax.set_xticklabels(times)
            else:
                btw = R.get("between_name","Group")
                if btw in emm.columns:
                    groups = sorted(emm[btw].unique())
                    t_lbls = sorted(emm[t_col].unique())
                    for i, grp in enumerate(groups):
                        sub   = emm[emm[btw]==grp].set_index(t_col).reindex(t_lbls)
                        x     = np.arange(len(t_lbls))
                        means = sub["Adjusted Mean"].values.astype(float)
                        ses   = sub["Std. Error"].values.astype(float)
                        ax.plot(x, means, "o-", color=PAL[i%len(PAL)],
                                lw=2.5, ms=8, label=str(grp), zorder=3)
                        ax.fill_between(x, means-ses, means+ses,
                                        alpha=0.15, color=PAL[i%len(PAL)])
                    ax.set_xticks(np.arange(len(t_lbls)))
                    ax.set_xticklabels(t_lbls)
                    ax.legend(title=btw, framealpha=0.7)
            ax.set_xlabel(t_col); ax.set_ylabel("Adjusted Mean")
            ax.set_title("Profile Plot — Adjusted Means ± SE", fontweight="600")
            plt.tight_layout()
            figs.append(("Profile Plot", _fig_b64(fig)))

    # MANCOVA effect sizes
    if t == "MANCOVA":
        univ = R.get("univariate", pd.DataFrame())
        if not univ.empty and "Partial η²" in univ.columns:
            # Only plot factor/covariate rows (skip Corrected Model, Intercept, Error)
            _skip = {"Corrected Model", "Intercept", "Error"}
            univ_plot = univ[~univ["Source"].isin(_skip)].copy() if "Source" in univ.columns else univ.copy()
            univ_plot["Partial η²"] = pd.to_numeric(univ_plot["Partial η²"], errors="coerce")
            univ_plot = univ_plot.dropna(subset=["Partial η²"])
            if not univ_plot.empty:
                fig, ax = plt.subplots(figsize=(7,4), facecolor=BG)
                _style_ax(ax)
                dvs  = univ_plot["Dependent Variable"].values if "Dependent Variable" in univ_plot.columns else univ_plot.index.values
                etas = univ_plot["Partial η²"].values.astype(float)
                cols = [PAL[1] if (not np.isnan(e) and e>=.14)
                        else PAL[2] if (not np.isnan(e) and e>=.06)
                        else PAL[0] for e in etas]
                ax.barh(dvs, etas, color=cols, alpha=0.82)
                for thresh, lbl, c in [(.01,"Small","#64748b"),(.06,"Medium",PAL[2]),(.14,"Large",PAL[1])]:
                    ax.axvline(thresh, color=c, ls="--", lw=1.2, label=f"{lbl} ({thresh})")
                ax.set_xlabel("Partial η²")
                ax.set_title("Effect Size per Dependent Variable", fontweight="600")
                ax.legend(fontsize=8, framealpha=0.7)
                plt.tight_layout()
                figs.append(("Effect Sizes per DV", _fig_b64(fig)))

        # MANCOVA: adjusted means (EMMs) per DV per group
        emm = R.get("emm", pd.DataFrame())
        if emm is not None and not emm.empty and {"Dependent Variable","Adjusted Mean"}.issubset(emm.columns):
            try:
                grp_col = R.get("factor_name","group")
                grp_col = grp_col if grp_col in emm.columns else (
                    "group" if "group" in emm.columns else emm.columns[1])
                dvs = list(dict.fromkeys(emm["Dependent Variable"].tolist()))
                groups = list(dict.fromkeys(emm[grp_col].tolist()))
                fig, ax = plt.subplots(figsize=(7,4), facecolor=BG)
                _style_ax(ax)
                x = np.arange(len(dvs)); w = 0.8/max(len(groups),1)
                for gi, g in enumerate(groups):
                    vals = [float(emm[(emm["Dependent Variable"]==dv) & (emm[grp_col]==g)]["Adjusted Mean"].iloc[0])
                            if not emm[(emm["Dependent Variable"]==dv) & (emm[grp_col]==g)].empty else np.nan
                            for dv in dvs]
                    ax.bar(x + gi*w, vals, w, label=str(g),
                           color=[PAL[gi % len(PAL)]], alpha=0.85)
                ax.set_xticks(x + w*(len(groups)-1)/2); ax.set_xticklabels(dvs)
                ax.set_ylabel("Adjusted Mean (EMM)")
                ax.set_title("Adjusted Means per Dependent Variable", fontweight="600")
                ax.legend(fontsize=8, framealpha=0.7, title=grp_col)
                plt.tight_layout()
                figs.append(("Adjusted Means (EMMs) per DV", _fig_b64(fig)))
            except Exception:
                pass

    # Residual diagnostics (between-subjects models)
    model = R.get("model")
    if model is not None:
        resid  = model.resid.values
        fitted = model.fittedvalues.values
        fig2, axes = plt.subplots(1, 2, figsize=(10, 4), facecolor=BG)
        for ax_ in axes: _style_ax(ax_)
        axes[0].scatter(fitted, resid, color=PAL[1], s=25, alpha=0.7)
        axes[0].axhline(0, color=PAL[0], lw=1.5, ls="--")
        axes[0].set_xlabel("Fitted Values"); axes[0].set_ylabel("Residuals")
        axes[0].set_title("Residuals vs Fitted")
        try:
            from scipy import stats as sc
            (osm,osr),(sl,ic,_) = sc.probplot(resid)
            axes[1].plot(osm, osr, "o", color=PAL[1], ms=4, alpha=0.7)
            axes[1].plot(osm, sl*np.array(osm)+ic, "--", color=PAL[0], lw=1.5)
        except: pass
        axes[1].set_xlabel("Theoretical Quantiles"); axes[1].set_ylabel("Sample Quantiles")
        axes[1].set_title("Normal Q-Q (Residuals)")
        plt.tight_layout()
        figs.append(("Residual Diagnostics", _fig_b64(fig2)))

    return figs


# ══════════════════════════════════════════════════════════════════════════════
# HTML REPORT
# ══════════════════════════════════════════════════════════════════════════════

def _build_html(R, meta, interps, figs_b, alpha):
    t = R["type"]
    def _cell(v):
        if isinstance(v, str): return v if v else "\u2014"
        if isinstance(v, (int, np.integer)): return str(int(v))
        if isinstance(v, float) and not np.isnan(v): return _f(v)
        return "\u2014"
    def _rtbl(rows, lc=None):
        if not rows: return ""
        left = lc or set()
        hd = "".join(f"<th>{c}</th>" for c in rows[0])
        bd = ""
        for i, row in enumerate(rows[1:]):
            cls = "even" if i % 2 == 0 else "odd"
            cells = "".join(
                f'<td class="left">{cell}</td>' if j in left else f'<td>{cell}</td>'
                for j, cell in enumerate(row))
            bd += f'<tr class="{cls}">{cells}</tr>'
        return f'<table class="rtbl"><thead><tr>{hd}</tr></thead><tbody>{bd}</tbody></table>'
    def _sub(tt):
        return f'<div class="sub-hdr">{tt}</div>'
    def _dfhtml(df_, lc=None):
        if df_ is None or (hasattr(df_,"empty") and df_.empty): return ""
        rows = [list(df_.columns)]
        for _, row in df_.iterrows():
            rows.append([_cell(row[c]) for c in df_.columns])
        return _rtbl(rows, lc or {0})

    css = """<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=DM+Sans:wght@300;400;600;700&display=swap');
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:#f0f4f8;color:#1e293b;font-size:14px;line-height:1.6;}
.page{max-width:1120px;margin:0 auto;padding:32px 24px 80px;}
.cover{background:linear-gradient(135deg,#0a0a0a 0%,#1a1a2e 50%,#16213e 100%);border-radius:16px;padding:44px 52px;margin-bottom:28px;border-left:6px solid #e94560;box-shadow:0 12px 48px rgba(233,69,96,.2);}
.cover h1{color:#fff;font-size:2rem;font-weight:700;margin-bottom:8px;}
.cover .badge{display:inline-block;background:#e94560;color:#fff;font-size:.7rem;padding:3px 10px;border-radius:20px;font-weight:600;margin-right:6px;}
.meta-tbl{width:100%;border-collapse:collapse;margin-top:20px;}
.meta-tbl td{padding:5px 10px;font-size:.82rem;}
.meta-tbl td.mk{color:#94a3b8;font-weight:600;width:220px;font-family:'DM Mono',monospace;}
.meta-tbl td.mv{color:#e2e8f0;}
.section{background:#fff;border-radius:12px;padding:26px 30px;margin-bottom:22px;box-shadow:0 2px 14px rgba(0,0,0,.06);}
.sec-hdr{background:linear-gradient(90deg,#1a1a2e,#16213e);color:#e2e8f0;padding:11px 20px;border-radius:8px 8px 0 0;font-weight:700;font-size:.82rem;letter-spacing:.8px;margin:-26px -30px 22px;font-family:'DM Mono',monospace;border-bottom:3px solid #e94560;}
.sub-hdr{background:#f1f5f9;color:#1a1a2e;padding:8px 14px;border-radius:6px;font-weight:600;font-size:.8rem;margin:18px 0 10px;border-left:3px solid #e94560;}
.rec-box{background:linear-gradient(135deg,#f0f9ff,#e0f2fe);border-left:4px solid #0284c7;padding:12px 16px;border-radius:0 8px 8px 0;font-size:.82rem;color:#0c4a6e;margin:12px 0;line-height:1.75;}
.rtbl{width:100%;border-collapse:collapse;font-family:'DM Mono',monospace;font-size:.73rem;margin-bottom:6px;table-layout:fixed;word-wrap:break-word;}
.rtbl th{background:#1a1a2e;color:#e2e8f0;padding:8px 10px;text-align:center;font-weight:600;border:1px solid #334155;white-space:normal;font-size:.71rem;}
.rtbl td{padding:6px 10px;border:1px solid #e2e8f0;text-align:right;white-space:normal;word-wrap:break-word;}
.rtbl tr.even td{background:#fff;}.rtbl tr.odd td{background:#f8fafc;}
.rtbl td.left{text-align:left;font-weight:500;background:#f1f5f9!important;}
.tbl-note{font-size:.73rem;color:#64748b;font-style:italic;margin-top:8px;line-height:1.6;}
.interp{padding:12px 18px;border-radius:0 10px 10px 0;margin:10px 0;font-size:.86rem;line-height:1.8;border-left:4px solid #0284c7;background:linear-gradient(135deg,#f8fafc,#f1f5f9);}
.interp b{color:#0284c7;}.interp.sig{border-left-color:#16a34a;background:linear-gradient(135deg,#f0fdf4,#dcfce7);}.interp.sig b{color:#16a34a;}
.interp.nonsig{border-left-color:#dc2626;background:linear-gradient(135deg,#fef2f2,#fee2e2);}
.apa-label{font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:6px;}
.apa-box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:14px 18px;font-family:'DM Mono',monospace;font-size:.78rem;color:#1e293b;line-height:1.8;}
.warn-box{background:#fffbeb;border-left:4px solid #f59e0b;padding:.7rem 1rem;border-radius:0 6px 6px 0;font-size:.82rem;color:#92400e;margin:.4rem 0;}
.info-box{background:#eff6ff;border-left:4px solid #3b82f6;padding:.7rem 1rem;border-radius:0 6px 6px 0;font-size:.82rem;color:#1e40af;margin:.4rem 0;}
.fig-wrap{text-align:center;margin:18px 0;}
.footer{text-align:center;color:#94a3b8;font-size:.72rem;margin-top:44px;padding-top:16px;border-top:1px solid #e2e8f0;line-height:1.8;}
</style>"""

    nr = R.get("normality", {})
    all_ok = R.get("all_ok", False)
    cls    = "use-param" if all_ok else "use-nonparam"
    _html_lbl = {
        "One-Way ANCOVA":           "Parametric ANCOVA",
        "Factorial ANCOVA":         "Parametric Factorial ANCOVA",
        "Repeated Measures ANCOVA": "Parametric RM ANCOVA",
        "Mixed ANCOVA":             "Parametric Mixed ANCOVA",
        "MANCOVA":                  "Parametric MANCOVA",
    }.get(t, "Parametric ANCOVA")
    dtxt = (f"\u2713 All assumption checks passed \u2014 {_html_lbl} results are reliable."
            if all_ok else
            f"\u26a0 One or more assumptions may be violated \u2014 review tests.")

    # ANCOVA / Univariate table
    left_01 = {0, 1}
    anova_html = ""
    if R.get("anova_table") is not None:
        anova_html = ('<div class="sub-hdr">Tests of Between-Subjects Effects</div>'
                      + _dfhtml(R["anova_table"]))
    elif R.get("univariate") is not None:
        anova_html = ('<div class="sub-hdr">Tests of Between-Subjects Effects</div>'
                      + _dfhtml(R["univariate"], left_01))
    # Parameter Estimates (Factorial)
    _pe = R.get("param_estimates")
    if _pe is not None and hasattr(_pe,"empty") and not _pe.empty:
        anova_html += ('<div class="sub-hdr">Parameter Estimates</div>'
                       + _dfhtml(_pe, {0}))
    # Univariate Tests (Factorial)
    _ut = R.get("univariate_tests")
    if _ut is not None and hasattr(_ut,"empty") and not _ut.empty:
        anova_html += ('<div class="sub-hdr">Univariate Tests</div>'
                       + _dfhtml(_ut, {0,1}))

    # Descriptives (MANCOVA) — Mean, SD, N per group per DV
    desc_html = ""
    desc_df = R.get("descriptives")
    if desc_df is not None and hasattr(desc_df,"empty") and not desc_df.empty:
        desc_html = ('<div class="sub-hdr">Descriptive Statistics</div>'
                     + _dfhtml(desc_df, {0}))

    # Levene's per DV (MANCOVA)
    lev_html = ""
    lev_mc = R.get("levene_mancova")
    if lev_mc is not None and hasattr(lev_mc,"empty") and not lev_mc.empty:
        lev_html = ('<div class="sub-hdr">Levene\'s Test of Equality of Error Variances</div>'
                    + _dfhtml(lev_mc, {0}))

    # Multivariate tests (MANCOVA) — Intercept, Covariate, Factor
    mv_html = ""
    def _mv_html_block(mv, lbl):
        if not mv: return ""
        rows = [
            ["Statistic","Value","F","Hyp df","Error df","Sig.","Partial \u03b7\u00b2","Noncent. Parameter"],
            ["Pillai\u2019s Trace",
             _f(mv["Pillai"]),    _f(mv["F_Pillai"]),
             str(mv.get("df_hyp_Pillai","—")), str(mv.get("df_err_Pillai","—")),
             _p(mv["p_Pillai"]),  _f(mv.get("eta2_Pillai","")),
             _f(mv.get("noncent_Pillai",""))],
            ["Wilks\u2019 Lambda",
             _f(mv["Wilks"]),     _f(mv["F_Wilks"]),
             str(mv.get("df_hyp_Wilks","—")),  str(mv.get("df_err_Wilks","—")),
             _p(mv["p_Wilks"]),   _f(mv.get("eta2_Wilks","")),
             _f(mv.get("noncent_Wilks",""))],
            ["Hotelling-Lawley",
             _f(mv["Hotelling"]), _f(mv["F_HL"]),
             str(mv.get("df_hyp_HL","—")),     str(mv.get("df_err_HL","—")),
             _p(mv["p_HL"]),      _f(mv.get("eta2_HL","")),
             _f(mv.get("noncent_HL",""))],
            ["Roy\u2019s Largest Root",
             _f(mv["Roy"]),       _f(mv["F_Roy"]),
             str(mv.get("df_hyp_Roy","—")),    str(mv.get("df_err_Roy","—")),
             _p(mv["p_Roy"]),     _f(mv.get("eta2_Roy","")),
             _f(mv.get("noncent_Roy",""))],
        ]
        left_0 = {0}
        return f'<div class="sub-hdr">Multivariate Tests \u2014 {lbl}</div>' + _rtbl(rows, left_0)

    for _eff, _key in [("Intercept",                   "mv_intercept"),
                       (R.get("cov_name","Covariate"),  "mv_cov"),
                       (R.get("factor_name","Group"),   "mv_factor")]:
        mv_html += _mv_html_block(R.get(_key), _eff)

    # ── RM / Mixed ANCOVA: Mauchly, Within-Subjects, Between-Subjects ──────
    def _nc(F, dfn):
        try: return _f(round(float(F)*float(dfn), 3))
        except Exception: return "\u2014"
    if t in ("Repeated Measures ANCOVA", "Mixed ANCOVA") and "mauchly_W" in R:
        cn = R.get("cov_name","Covariate"); bn = R.get("between_name","Group")
        # Multivariate Tests (within-subjects) — before Mauchly, matching SPSS order
        def _mvw_html(mv, lbl):
            if not mv: return ""
            rows = [["Statistic","Value","F","Hyp df","Error df","Sig.","Partial \u03b7\u00b2","Noncent."],
                ["Pillai\u2019s Trace",_f(mv["Pillai"]),_f(mv["F_Pillai"]),
                 str(mv.get("df_hyp","?")),str(mv.get("df_err","?")),
                 _p(mv["p_Pillai"]),_f(mv.get("eta2","")),_f(mv.get("noncent",""))],
                ["Wilks\u2019 Lambda",_f(mv["Wilks"]),_f(mv["F_Wilks"]),
                 str(mv.get("df_hyp","?")),str(mv.get("df_err","?")),
                 _p(mv["p_Wilks"]),_f(mv.get("eta2","")),_f(mv.get("noncent",""))],
                ["Hotelling-Lawley",_f(mv.get("Hotelling",np.nan)),_f(mv.get("F_HL",np.nan)),
                 str(mv.get("df_hyp","?")),str(mv.get("df_err","?")),
                 _p(mv.get("p_HL",np.nan)),_f(mv.get("eta2","")),_f(mv.get("noncent",""))],
                ["Roy\u2019s Largest Root",_f(mv.get("Roy",np.nan)),_f(mv.get("F_Roy",np.nan)),
                 str(mv.get("df_hyp","?")),str(mv.get("df_err","?")),
                 _p(mv.get("p_Roy",np.nan)),_f(mv.get("eta2","")),_f(mv.get("noncent",""))],
            ]
            return f'<div class="sub-hdr">Multivariate Tests \u2014 {lbl}</div>' + _rtbl(rows, {0})
        mv_html += _mvw_html(R.get("mv_time"), "TIME")
        if t == "Mixed ANCOVA":
            mv_html += _mvw_html(R.get("mv_tg"), f"TIME \u00d7 {bn}")
        mv_html += _mvw_html(R.get("mv_tc"), f"TIME \u00d7 {cn}")
        # Mauchly
        mau_rows = [["Within Subjects Effect","Mauchly's W","Approx. Chi-Square","df","Sig.","\u03b5 (GG)"],
                    ["TIME", _f(R.get("mauchly_W",np.nan)), _f(R.get("mauchly_chi2",np.nan)),
                     str(R.get("mauchly_df","?")), _p(R.get("mauchly_p",np.nan)),
                     _f(R.get("eps_gg",np.nan))]]
        mv_html += '<div class="sub-hdr">Mauchly\u2019s Test of Sphericity</div>' + _rtbl(mau_rows, {0})

        if t == "Repeated Measures ANCOVA":
            ws_rows = [["Source","Type III SS","df","MS","F","Sig. (Uncorr.)","Sig. (GG)","Partial \u03b7\u00b2","Noncent."],
                ["TIME", _f(R.get("SS_time",np.nan)), str(R.get("df_time","?")),
                 _f(R.get("MS_time",np.nan)), _f(R.get("F_time",np.nan)),
                 _p(R.get("p_time",np.nan)), _p(R.get("p_time_gg",np.nan)),
                 _f(R.get("eta2_time",np.nan)), _nc(R.get("F_time",np.nan), R.get("df_time",1))],
                [f"TIME \u00d7 {cn}", _f(R.get("SS_tc",np.nan)), str(R.get("df_tc","?")),
                 "\u2014", _f(R.get("F_tc",np.nan)), _p(R.get("p_tc",np.nan)), "\u2014",
                 _f(R.get("eta2_tc",np.nan)), _nc(R.get("F_tc",np.nan), R.get("df_tc",1))]]
            mv_html += '<div class="sub-hdr">Tests of Within-Subjects Effects</div>' + _rtbl(ws_rows, {0})
            bs_rows = [["Source","SS","df","F","Sig.","Partial \u03b7\u00b2","Noncent."],
                [cn, _f(R.get("SS_cov",np.nan)), "1", _f(R.get("F_cov",np.nan)),
                 _p(R.get("p_cov",np.nan)), _f(R.get("eta2_cov",np.nan)), _nc(R.get("F_cov",np.nan),1)],
                ["Error", "\u2014", str(R.get("df_err_between","?")), "\u2014","\u2014","\u2014","\u2014"]]
            mv_html += '<div class="sub-hdr">Tests of Between-Subjects Effects</div>' + _rtbl(bs_rows, {0})
        else:  # Mixed ANCOVA
            T_ = R.get("T",3); k_ = R.get("k",2)
            ws_rows = [["Source","SS","df","F","Sig.","\u03b5 (GG)","Partial \u03b7\u00b2","Noncent."],
                ["TIME", _f(R.get("SS_time",np.nan)), str(R.get("df_time",T_-1)),
                 _f(R.get("F_time",np.nan)), _p(R.get("p_time",np.nan)),
                 _f(R.get("eps_gg",np.nan)), _f(R.get("eta2_time",np.nan)),
                 _nc(R.get("F_time",np.nan), R.get("df_time",T_-1))],
                [f"TIME \u00d7 {R.get('between_name','Group')}", _f(R.get("SS_interact",R.get("SS_tg",np.nan))),
                 str((T_-1)*(k_-1)), _f(R.get("F_interact",R.get("F_tg",np.nan))),
                 _p(R.get("p_interact",R.get("p_tg",np.nan))), "\u2014",
                 _f(R.get("eta2_interact",R.get("eta2_tg",np.nan))),
                 _nc(R.get("F_interact",R.get("F_tg",np.nan)),(T_-1)*(k_-1))],
                [f"TIME \u00d7 {cn}", _f(R.get("SS_tc",np.nan)), str(T_-1),
                 _f(R.get("F_tc",np.nan)), _p(R.get("p_tc",np.nan)), "\u2014",
                 _f(R.get("eta2_tc",np.nan)), _nc(R.get("F_tc",np.nan), T_-1)]]
            mv_html += '<div class="sub-hdr">Tests of Within-Subjects Effects</div>' + _rtbl(ws_rows, {0})
            bs_rows = [["Source","SS","df","F","Sig.","Partial \u03b7\u00b2","Noncent."],
                [R.get("between_name","Group"), _f(R.get("SS_between",np.nan)),
                 str(R.get("df_between","?")), _f(R.get("F_between",np.nan)),
                 _p(R.get("p_between",np.nan)), _f(R.get("eta2_between",np.nan)),
                 _nc(R.get("F_between",np.nan), R.get("df_between",1))],
                [cn, _f(R.get("SS_cov",np.nan)), "1", _f(R.get("F_cov",np.nan)),
                 _p(R.get("p_cov",np.nan)), _f(R.get("eta2_cov",np.nan)), _nc(R.get("F_cov",np.nan),1)],
                ["Error","\u2014", str(R.get("df_resid_between","?")), "\u2014","\u2014","\u2014","\u2014"]]
            mv_html += '<div class="sub-hdr">Tests of Between-Subjects Effects</div>' + _rtbl(bs_rows, {0})

        # Within-Subjects Contrasts (RM & Mixed)
        _cdf = R.get("contrasts")
        if _cdf is not None and hasattr(_cdf,"empty") and not _cdf.empty:
            crows = [list(_cdf.columns)]
            for _i in _cdf.index:
                crows.append([_f(v) if isinstance(v,float) else str(v) for v in _cdf.loc[_i]])
            mv_html += ('<div class="sub-hdr">Tests of Within-Subjects Contrasts</div>'
                        + _rtbl(crows, {0,1}))

    # Box's M
    bm_html = ""
    bm = R.get("boxes_m")
    if bm:
        bm_rows = [["Box's M","F","df1","df2","Sig."],
                   [_f(bm["M"]),_f(bm["F"]),str(bm["df1"]),_f(bm["df2"]),_p(bm["Sig."])]]
        bm_html = '<div class="sub-hdr">Box\'s M Test</div>' + _rtbl(bm_rows)

    # EMMs
    emm_html = ""
    for k, lbl in [("emm","Estimated Marginal Means"),
                   ("emm_cell","Cell EMMs"),
                   ("emm_group","Group EMMs (avg over time)"),
                   ("emm_time","Time EMMs (avg over groups)"),
                   ("emm_a",f"Marginal Means — {R.get('fa_name','')} (avg over {R.get('fb_name','')})"),
                   ("emm_b",f"Marginal Means — {R.get('fb_name','')} (avg over {R.get('fa_name','')})") ]:
        df_ = R.get(k)
        if df_ is not None and hasattr(df_, "empty") and not df_.empty:
            emm_html += f'<div class="sub-hdr">{lbl}</div>' + _dfhtml(df_)

    # Post-hoc
    pw_html = ""
    for k, lbl in [("pairwise","Pairwise Comparisons (Bonferroni)"),
                   ("pairwise_a",f"Pairwise — {R.get('fa_name','')}"),
                   ("pairwise_b",f"Pairwise — {R.get('fb_name','')}"),
                   ("pairwise_time","Pairwise Time Comparisons"),
                   ("pairwise_group","Pairwise Group Comparisons")]:
        df_ = R.get(k)
        if df_ is not None and hasattr(df_,"empty") and not df_.empty:
            pw_html += f'<div class="sub-hdr">{lbl}</div>' + _dfhtml(df_, {0,1})

    # Normality of residuals
    norm_html = ""
    nr_html   = R.get("normality", {})
    left_07   = {0, 6, 7}
    left_0    = {0}
    if isinstance(nr_html, dict) and "sw_W" in nr_html:
        # Single normality (ANCOVA)
        nr_rows = [["Variable","N","KS D","KS Sig.","SW W","SW Sig.","Primary","Decision"],
                   [nr_html.get("label","Residuals"),
                    str(nr_html.get("total_n", nr_html.get("n","?"))),
                    _f(nr_html.get("ks_D",np.nan)), _p(nr_html.get("ks_p",np.nan)),
                    _f(nr_html.get("sw_W",np.nan)), _p(nr_html.get("sw_p",np.nan)),
                    nr_html.get("primary_label","?"),
                    "\u2713 Normal" if nr_html.get("pass") else "\u2717 Non-Normal"]]
        norm_html = _sub("Normality of Residuals") + _rtbl(nr_rows, left_07)
    elif isinstance(nr_html, dict) and nr_html:
        # Per-DV normality (MANCOVA)
        nr_rows = [["Dependent Variable","N","KS D","KS Sig.","SW W","SW Sig.","Primary","Decision"]]
        for dv, dv_nr in nr_html.items():
            if isinstance(dv_nr, dict) and "sw_W" in dv_nr:
                nr_rows.append([
                    dv,
                    str(dv_nr.get("total_n", dv_nr.get("n","?"))),
                    _f(dv_nr.get("ks_D",np.nan)), _p(dv_nr.get("ks_p",np.nan)),
                    _f(dv_nr.get("sw_W",np.nan)), _p(dv_nr.get("sw_p",np.nan)),
                    dv_nr.get("primary_label","?"),
                    "\u2713 Normal" if dv_nr.get("pass") else "\u2717 Non-Normal"
                ])
        norm_html = _sub("Normality of Residuals (per DV)") + _rtbl(nr_rows, left_07)

    # Meta table (cover style)
    meta_html = "<table class='meta-tbl'>"
    for k_, v in meta.items():
        meta_html += f"<tr><td class='mk'>{k_}</td><td class='mv'>{v}</td></tr>"
    meta_html += "</table>"

    # ── Additional assumption tables (parity with web Tab 0) ──
    assump_html = ""
    # Levene's Test (univariate ANCOVA types)
    _lev_uni = R.get("levene", {})
    if _lev_uni:
        _eq = _lev_uni.get("passed", _lev_uni.get("equal_var", False))
        assump_html += (
            '<div class="sub-hdr">Levene\u2019s Test for Equality of Variances</div>'
            + _rtbl([["F","Sig.","Decision"],
                     [_f(_lev_uni.get("F",np.nan)),
                      _p(_lev_uni.get("p",_lev_uni.get("Sig.",np.nan))),
                      "\u2713 Equal variances" if _eq else "\u2717 Unequal variances"]]))
    # Homogeneity of Regression Slopes
    for _sk, _sl in [("slopes","Homogeneity of Regression Slopes"),
                     ("slopes_a","Regression Slopes \u2014 Factor A"),
                     ("slopes_b","Regression Slopes \u2014 Factor B")]:
        if _sk in R and R[_sk]:
            _s = R[_sk]
            assump_html += (
                f'<div class="sub-hdr">{_sl}</div>'
                + _rtbl([["F","Sig.","Decision"],
                         [_f(_s.get("F",np.nan)), _p(_s.get("p",np.nan)),
                          "\u2713 Satisfied" if _s.get("passed") else "\u2717 Violated"]]))
            if _s.get("note"):
                assump_html += f'<p class="tbl-note">{_s.get("note")}</p>'
    # Linearity
    for _lk, _ll in [("linearity","Linearity: Covariate vs DV"),
                     ("linearity_a","Linearity per Factor A Group"),
                     ("linearity_b","Linearity per Factor B Group")]:
        _lin = R.get(_lk)
        if _lin is not None and hasattr(_lin,"empty") and not _lin.empty:
            _lr = [["Group","N","r","Sig.","Linear?"]]
            for _, _row in _lin.iterrows():
                _lr.append([_row.get("Group",""), str(_row.get("N","")),
                            _f(_row.get("r",np.nan)), _p(_row.get("Sig.",np.nan)),
                            "\u2713 Yes" if _row.get("passed") else "\u2717 No"])
            assump_html += f'<div class="sub-hdr">{_ll}</div>' + _rtbl(_lr, {0})

    # ── Effect Size & Statistical Power table (parity with web Tab 4) ──
    from scipy import stats as _sc
    def _pwr_h(eta2, df_num=1, df_den=None):
        if eta2 is None or np.isnan(eta2) or eta2 >= 1: return np.nan
        f2 = eta2/(1-eta2); dn = df_den or max(R.get("n",30)-2,1)
        try:
            ncp = f2*(df_num+dn+1); fc = _sc.f.ppf(1-alpha, df_num, dn)
            return float(np.clip(_sc.ncf.sf(fc, df_num, dn, ncp),0,1))
        except Exception: return np.nan
    _es = [["Effect","Partial \u03b7\u00b2","Cohen's f","Interpretation","Power"]]
    def _es_add(lbl, eta2, dfn=1):
        if eta2 is None or np.isnan(eta2): return
        fv = float(np.sqrt(eta2/(1-eta2))) if eta2 < 1 else np.nan
        pw = _pwr_h(eta2, dfn)
        _es.append([lbl, _f(eta2), _f(fv) if not np.isnan(fv) else "\u2014",
                    _effect_label(eta2), f"{pw*100:.1f}%" if not np.isnan(pw) else "\u2014"])
    for _k, _l in [("partial_eta2","Group (Factor)"),("eta2_a","Factor A"),
                   ("eta2_b","Factor B"),("eta2_ab","Interaction A\u00d7B"),
                   ("eta2_time","Time (Within)"),("eta2_between","Between-Subjects"),
                   ("eta2_interact","Interaction"),("eta2_cov","Covariate")]:
        _v = R.get(_k, np.nan)
        if _v is not None and not (isinstance(_v,float) and np.isnan(_v)): _es_add(_l, _v)
    if t == "MANCOVA":
        _u = R.get("univariate", pd.DataFrame())
        if _u is not None and not _u.empty and "Partial \u03b7\u00b2" in _u.columns:
            for _, _row in _u.iterrows():
                if str(_row.get("Source","")) in {"Corrected Model","Intercept","Error","Corrected Total","Total"}:
                    continue
                try: _eta = float(_row.get("Partial \u03b7\u00b2", np.nan))
                except Exception: _eta = np.nan
                try: _dfn = int(float(_row.get("df",1)))
                except Exception: _dfn = 1
                _es_add(f"{_row.get('Dependent Variable','DV')} \u2014 {_row.get('Source','')}", _eta, _dfn)
    es_html = ""
    if len(_es) > 1:
        es_html = (_rtbl(_es, {0,3})
                   + '<p class="tbl-note">Partial \u03b7\u00b2: \u2265.01 small, '
                     '\u2265.06 medium, \u2265.14 large (Cohen, 1988). Power based on the '
                     'non-central F distribution at the selected \u03b1.</p>')


    # Interp blocks → colour-coded by statistical decision
    interp_html = "".join(
        f'<div class="interp {_interp_cls(line)}">{line}</div>' for line in interps)

    # APA 7 reporting block
    _apa_lines = _apa_report(R, alpha)
    apa_html = ""
    if _apa_lines:
        apa_html = ('<div class="apa-label">Ready-to-paste APA 7 results</div>'
                    '<div class="apa-box">'
                    + "<br><br>".join(_apa_lines) + "</div>")

    # Figures → .fig-wrap
    figs_html = "".join(
        f'<div class="fig-wrap"><div class="sub-hdr">{lbl}</div>'
        f'<img src="data:image/png;base64,{b64}" style="max-width:100%;border-radius:8px;"/></div>'
        for lbl, b64 in figs_b)

    _ds = f'<div class="sec-hdr">2. DESCRIPTIVE STATISTICS</div>{desc_html}' if desc_html else ""
    _bx = f'{bm_html}' if bm_html else ""
    _lv = f'{lev_html}' if lev_html else ""
    _mv = f'{mv_html}' if mv_html else ""
    _emm_note = (f'<p class="tbl-note">Computed at grand mean of covariate(s): '
                 f'{_fmt_grand_cov(R)}.</p>')

    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"/>
<title>{t} | Inferential Statistics by MA</title>{css}</head>
<body><div class="page">
<div class="cover">
  <h1>&#127907; {t} Report</h1>
  <div style="margin-bottom:20px;">
    <span class="badge">SPSS-Equivalent</span><span class="badge">Type III SS</span>
    <span class="badge">EMMs</span><span class="badge">Partial &#951;&#178;</span>
    <span class="badge">Noncent.</span>
  </div>
  {meta_html}
  <div style="margin-top:18px;padding-top:16px;border-top:1px solid rgba(255,255,255,.12);">
    <p style="color:#94a3b8;font-size:.76rem;margin:0 0 8px;">&#9749; Support this work &mdash; scan QRIS</p>
    <img src="https://muhaiminabdullah.com/media/images/qris_muhaiminabdullahdotcom.png"
         style="width:130px;border-radius:8px;border:2px solid #e94560;display:block;"/>
  </div>
</div>
<div class="section"><div class="sec-hdr">1. NORMALITY &amp; ASSUMPTION TESTS</div>
  <div class="{cls.replace('use-param','info-box').replace('use-nonparam','warn-box')}"
       style="font-weight:600;margin-bottom:12px;">{dtxt}</div>
  {norm_html}
  {assump_html}
  {_lv}
</div>
{_ds and f'<div class="section">{_ds}</div>'}
<div class="section"><div class="sec-hdr">3. OMNIBUS / MULTIVARIATE TESTS</div>
  {_bx}
  {_mv}
  {anova_html}
  <p class="tbl-note">Partial &#951;&#178;: &lt;.01 negligible, .01&#8211;.06 small,
  .06&#8211;.14 medium, &#8805;.14 large (Cohen, 1988). Noncentrality parameter (&#955;) = F &#215; hypothesis df.</p>
</div>
<div class="section"><div class="sec-hdr">4. ESTIMATED MARGINAL MEANS</div>
  {emm_html}
  {_emm_note}
</div>
<div class="section"><div class="sec-hdr">5. POST-HOC COMPARISONS</div>
  {pw_html if pw_html else '<p class="tbl-note">No pairwise comparisons available.</p>'}
</div>
<div class="section"><div class="sec-hdr">6. EFFECT SIZE &amp; STATISTICAL POWER</div>
  {es_html if es_html else '<p class="tbl-note">Effect-size estimates are not available for this analysis.</p>'}
</div>
<div class="section"><div class="sec-hdr">7. INTERPRETATION</div>
  {interp_html}
  {apa_html}
</div>
<div class="section"><div class="sec-hdr">8. DIAGNOSTIC PLOTS</div>
  {figs_html}
</div>
<div class="footer">Generated by Inferential Statistics by MA &nbsp;&middot;&nbsp; {t}
  &nbsp;&middot;&nbsp; {datetime.now().strftime("%B %d, %Y at %H:%M")}</div>
</div></body></html>""".encode("utf-8")


# ══════════════════════════════════════════════════════════════════════════════
# CSS + HEADER  (identical pattern to 2_anova.py)
# ══════════════════════════════════════════════════════════════════════════════
st.markdown(load_page_css(), unsafe_allow_html=True)

st.markdown("""
<div class="main-hdr">
  <h1>&#127907; ANCOVA Family
    <span class="badge">SPSS-Equivalent</span>
    <span class="badge">Type&nbsp;III&nbsp;SS</span>
    <span class="badge">EMMs</span>
    <span class="badge">Partial&nbsp;&#951;&#178;</span>
  </h1>
  <p>One-Way &nbsp;&middot;&nbsp; Factorial &nbsp;&middot;&nbsp;
     Repeated Measures &nbsp;&middot;&nbsp; Mixed &nbsp;&middot;&nbsp; MANCOVA</p>
</div>""", unsafe_allow_html=True)

st.markdown("""
<div style="margin-bottom:1rem;">
  <p style="color:#64748b;font-size:.9rem;margin-bottom:.4rem;">
    &#9749; Support this work &mdash; scan QRIS <a href="https://paypal.me/mhmnbdllh" target="_blank" style="color: #0070ba; font-size: 13px; font-weight: bold;"> or Donate via PayPal </a></p>
  <img src="https://muhaiminabdullah.com/media/images/qris_muhaiminabdullahdotcom.png"
       style="width:180px;border-radius:10px;border:2px solid #e94560;display:block;"/>
</div>""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR  (identical pattern to 2_anova.py)
# ══════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown("### &#9881;&#65039; Configuration")
    st.markdown("---")

    _tests = [
        "One-Way ANCOVA",
        "Factorial ANCOVA",
        "Repeated Measures ANCOVA",
        "Mixed ANCOVA",
        "MANCOVA",
    ]
    # Honor a navigation request from the landing page (home-page buttons set a
    # session key). No URL query params are used (consistent with the other pages).
    _nav = (st.session_state.pop("ancova_goto", None)
            or st.session_state.pop("selected_test", None))
    if _nav in _tests:
        st.session_state["ancova_test_sel"] = _nav

    if "ancova_test_sel" not in st.session_state:
        st.session_state["ancova_test_sel"] = st.session_state.get(
            "ancova_test", "One-Way ANCOVA")

    test_type = st.selectbox("&#127907; Select Test", _tests,
                             key="ancova_test_sel")

    # If the user switches test type without re-running, clear stale RESULTS so
    # the page shows the "ready to run" state for the new test (do NOT clear the
    # selector key itself, or the dropdown would reset to One-Way).
    if ("ancova_last_run" in st.session_state
            and st.session_state["ancova_last_run"] != test_type):
        for _k in ("ancova_R", "ancova_meta", "ancova_interps", "ancova_figs"):
            st.session_state.pop(_k, None)

    alpha = st.selectbox("\u03b1 Significance Level", [0.05, 0.01, 0.001], index=0)

    posthoc_method = st.selectbox(
        "Post-Hoc Method",
        ["bonferroni", "lsd", "sidak", "scheffe"],
        format_func={
            "bonferroni": "Bonferroni (conservative)",
            "lsd":        "LSD (Fisher, no correction)",
            "sidak":      "Sidak",
            "scheffe":    "Scheff\u00e9 (most flexible)",
        }.get,
        index=0)

    transform_method = st.selectbox(
        "\U0001f527 DV Transformation (if residuals non-normal)",
        ["none", "log", "log10", "sqrt", "boxcox", "yeojohnson"],
        format_func={
            "none":       "None (original scale)",
            "log":        "Natural log \u2014 right-skewed data",
            "log10":      "Log base 10 \u2014 right-skewed data",
            "sqrt":       "Square root \u2014 counts / mild skew",
            "boxcox":     "Box-Cox \u2014 auto-optimal (positive data)",
            "yeojohnson": "Yeo-Johnson \u2014 auto-optimal (any data)",
        }.get,
        index=0,
        help="Applied to the dependent variable before analysis. Use only if "
             "normality of residuals is violated; results are reported on the "
             "transformed scale.")

    st.markdown("---")

    _samp_key = {
        "One-Way ANCOVA":           "One-Way ANCOVA",
        "Factorial ANCOVA":         "Factorial ANCOVA",
        "Repeated Measures ANCOVA": "Repeated Measures ANCOVA",
        "Mixed ANCOVA":             "Mixed ANCOVA",
        "MANCOVA":                  "MANCOVA",
    }[test_type]
    samp = SAMPLES[_samp_key]
    st.markdown("**&#128196; Sample Data**")
    st.markdown(
        f'<p style="font-size:.8rem;color:#64748b;">{samp["note"]}</p>',
        unsafe_allow_html=True)
    st.download_button(
        "&#11015;&#65039; Download Sample CSV",
        samp["csv"].encode(),
        f"sample_{_samp_key.replace(' ','_').lower()}.csv",
        "text/csv", use_container_width=True)
    st.markdown("---")

    uploaded = st.file_uploader(
        "&#128194; Upload Data File",
        type=["csv", "xlsx", "xls"])
    if uploaded:
        try:
            df = load_file(uploaded)
            fm = file_metadata(uploaded, df)
            val = validate_file(df)
            if val["errors"]:
                for e in val["errors"]: st.error(e)
                df = None
            else:
                st.success(f"&#10003; {fm['Rows']:,} rows \u00d7 {fm['Columns']} cols")
                for w in val["warnings"]: st.warning(w)
        except Exception as e:
            st.error(str(e)); df = None
    else:
        df = load_from_string(samp["csv"])
        st.info("\u2139\ufe0f Using built-in sample data")

    # ── Variable selection ──────────────────────────────────────────────────
    cfg = None
    if df is not None:
        num_cols = get_numeric_cols(df)
        cat_cols = get_categorical_cols(df)
        all_cols = list(df.columns)
        id_cols  = [c for c in num_cols if _is_id_col(c, df[c])]
        non_id   = [c for c in num_cols if c not in id_cols]
        grp_cols = cat_cols + [c for c in num_cols
                               if c not in id_cols and df[c].nunique() <= 15]
        st.markdown("---")

        if test_type == "One-Way ANCOVA":
            gc = st.selectbox("&#128101; Factor (Group)", grp_cols, index=0,
                              key="ow_group")
            cc = st.multiselect("&#128202; Covariate(s)", non_id,
                                default=non_id[:1], key="ow_cov",
                                help="Select one or more covariates (SPSS allows several).")
            rem = [c for c in non_id if c not in cc]
            dc = st.selectbox("&#127919; Dependent Variable (Y)", rem,
                               index=max(0, len(rem)-1), key="ow_dv")
            if cc:
                cfg = {"type":"oneway","group":gc,"cov":cc,"dv":dc}
            else:
                st.warning("Select at least one covariate.")

        elif test_type == "Factorial ANCOVA":
            fa = st.selectbox("Factor A", grp_cols, index=0,
                              key="fac_factorA")
            _fb_opts = [c for c in grp_cols if c != fa]
            if _fb_opts:
                fb = st.selectbox("Factor B", _fb_opts, index=0,
                                  key="fac_factorB")
            else:
                fb = None
                st.warning("Factorial ANCOVA needs **2 different** categorical "
                           "factors, but only one was found.")
            # Covariate(s): prefer pretest/baseline-named numeric columns
            _covF = [c for c in non_id
                     if any(kw in c.lower() for kw in
                            ("pre", "base", "cov", "prior", "iq", "age"))]
            cc = st.multiselect("&#128202; Covariate(s)", non_id,
                                default=(_covF[:1] if _covF else non_id[:1]),
                                key="fac_cov",
                                help="Select one or more covariates (SPSS allows several).")
            rem = [c for c in non_id if c not in cc]
            dc = st.selectbox("&#127919; Dependent Variable (Y)", rem,
                               index=0 if rem else 0, key="fac_dv")
            if fb is not None and cc:
                cfg = {"type":"factorial","fa":fa,"fb":fb,"cov":cc,"dv":dc}
            elif fb is not None and not cc:
                st.warning("Select at least one covariate.")

        elif test_type == "Repeated Measures ANCOVA":
            _cov_guess = _guess_covariate(non_id)
            _time_def  = [c for c in non_id if c != _cov_guess]
            tc = st.multiselect(
                "Time-Point Columns (≥2)",
                non_id,
                default=_time_def if len(_time_def) >= 2 else non_id[:min(3, len(non_id))],
                key="rm_times",
                help="Select 2+ numeric columns representing repeated measurements.")
            rem = [c for c in non_id if c not in tc]
            _ci = [c for c in rem if c == _cov_guess] or (rem[:1] if rem else [])
            cc = st.multiselect("&#128202; Covariate(s) (between-subjects)", rem,
                                default=_ci, key="rm_cov",
                                help="One or more between-subjects covariates (SPSS allows several).")
            if len(tc) >= 2 and cc:
                cfg = {"type":"rm","times":tc,"cov":cc}
            elif len(tc) >= 2 and not cc:
                st.warning("Select at least one covariate.")
            else:
                st.warning("Select at least 2 time-point columns.")

        elif test_type == "Mixed ANCOVA":
            bc = st.selectbox("&#128101; Between-Subjects Factor", grp_cols,
                              index=0, key="mx_between")
            _cov_guess = _guess_covariate(non_id)
            _time_def  = [c for c in non_id if c != _cov_guess]
            tc = st.multiselect(
                "Time-Point Columns (≥2)",
                non_id,
                default=_time_def if len(_time_def) >= 2 else non_id[:min(3, len(non_id))],
                key="mx_times")
            rem = [c for c in non_id if c not in tc]
            _ci = [c for c in rem if c == _cov_guess] or (rem[:1] if rem else [])
            cc = st.multiselect("&#128202; Covariate(s)", rem,
                                default=_ci, key="mx_cov",
                                help="One or more covariates (SPSS allows several).")
            if len(tc) >= 2 and cc:
                cfg = {"type":"mixed","between":bc,"times":tc,"cov":cc}
            elif len(tc) >= 2 and not cc:
                st.warning("Select at least one covariate.")
            else:
                st.warning("Select at least 2 time-point columns.")

        else:  # MANCOVA
            gc = st.selectbox("&#128101; Factor (Group)", grp_cols, index=0,
                              key="mc_group")
            cc = st.multiselect("&#128202; Covariate(s)", non_id,
                                default=non_id[:1], key="mc_cov",
                                help="Select one or more covariates (SPSS allows several).")
            rem = [c for c in non_id if c not in cc]
            dvs = st.multiselect(
                "&#127919; Dependent Variables (≥2)", rem,
                default=rem[:min(3, len(rem))], key="mc_dvs")
            if len(dvs) >= 2 and cc:
                cfg = {"type":"mancova","group":gc,"cov":cc,"dvs":dvs}
            elif len(dvs) >= 2 and not cc:
                st.warning("Select at least one covariate.")
            else:
                st.warning("Select at least 2 dependent variables.")

        st.markdown("---")
        run_btn = st.button("&#128640; Run Analysis",
                             type="primary", use_container_width=True)
    else:
        run_btn = False


# ══════════════════════════════════════════════════════════════════════════════
# DATA PREVIEW
# ══════════════════════════════════════════════════════════════════════════════
if df is not None:
    with st.expander("&#128269; Data Preview", expanded=False):
        st.dataframe(df.head(20), use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# WELCOME
# ══════════════════════════════════════════════════════════════════════════════
if not run_btn and "ancova_R" not in st.session_state:
    st.markdown(
        f'<div style="background:linear-gradient(135deg,#f0f9ff,#e0f2fe);'
        f'border:1px solid #bae6fd;border-radius:12px;padding:1.2rem 1.4rem;'
        f'margin:.8rem 0;border-left:4px solid #0284c7;">'
        f'<h4 style="margin:0 0 .4rem;font-size:.95rem;font-weight:700;">'
        f'&#128203; {test_type}</h4>'
        f'<p style="margin:0;font-size:.84rem;color:#475569;">'
        f'{samp["desc"]}</p></div>',
        unsafe_allow_html=True)
    st.info("&#128072; Configure variables in the sidebar, then click **Run Analysis**.")
    st.stop()


# ══════════════════════════════════════════════════════════════════════════════
# RUN ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════
if run_btn:
    if cfg is None:
        st.error("&#9888;&#65039; Variable configuration is incomplete."); st.stop()

    with st.spinner("Running analysis\u2026"):
        try:
            # ── Pre-flight: coerce numerics & apply DV transformation ────────
            # Guards against non-numeric cells (e.g. text, or values pasted as
            # Excel formulas) and applies the chosen transform to the DV(s).
            transform_info = {"applied": False, "label": "None", "note": "", "feasible": True}
            dfw = df.copy()
            if cfg["type"] in ("oneway", "factorial"):
                _dv_cols = [cfg["dv"]]
            elif cfg["type"] == "mancova":
                _dv_cols = list(cfg["dvs"])
            else:                       # rm / mixed
                _dv_cols = list(cfg["times"])
            _cov_cols = list(cfg.get("cov") or [])
            _num_needed = _dv_cols + _cov_cols
            _bad = []
            for _c in _num_needed:
                _co = pd.to_numeric(dfw[_c], errors="coerce")
                if _co.notna().sum() == 0:
                    _bad.append(_c)
                dfw[_c] = _co
            if _bad:
                raise ValueError("__NONNUMERIC__" + ", ".join(_bad))
            _before = len(dfw)
            dfw = dfw.dropna(subset=_num_needed)
            if len(dfw) < 3:
                raise ValueError("__TOOFEW__")
            if transform_method != "none":
                for _c in _dv_cols:
                    _yt, _tinfo = transform_dependent(dfw[_c].values, transform_method)
                    transform_info = _tinfo
                    if _tinfo.get("applied"):
                        dfw[_c] = _yt
                    elif not _tinfo.get("feasible", True):
                        break

            if cfg["type"] == "oneway":
                R = run_one_way_ancova(
                    y=dfw[cfg["dv"]].values,
                    factor=dfw[cfg["group"]].values,
                    covariate=dfw[cfg["cov"]].values.astype(float),
                    y_name=cfg["dv"], factor_name=cfg["group"],
                    cov_name=cfg["cov"], alpha=alpha,
                    posthoc_method=posthoc_method)
                meta = {"Test":test_type,"Factor":cfg["group"],
                        "Covariate(s)":", ".join(cfg["cov"]),
                        "DV":cfg["dv"],"N":R["n"],"Post-Hoc":posthoc_method.title(),
                        "\u03b1":alpha,"Date":datetime.now().strftime("%B %d, %Y %H:%M")}

            elif cfg["type"] == "factorial":
                R = run_factorial_ancova(
                    y=dfw[cfg["dv"]].values,
                    factor_a=dfw[cfg["fa"]].values,
                    factor_b=dfw[cfg["fb"]].values,
                    covariate=dfw[cfg["cov"]].values.astype(float),
                    y_name=cfg["dv"], fa_name=cfg["fa"], fb_name=cfg["fb"],
                    cov_name=cfg["cov"], alpha=alpha,
                    posthoc_method=posthoc_method)
                meta = {"Test":test_type,"Factor A":cfg["fa"],"Factor B":cfg["fb"],
                        "Covariate(s)":", ".join(cfg["cov"]),"DV":cfg["dv"],"N":R["n"],
                        "\u03b1":alpha,"Date":datetime.now().strftime("%B %d, %Y %H:%M")}

            elif cfg["type"] == "rm":
                R = run_rm_ancova(
                    data_wide=dfw[cfg["times"]].values.astype(float),
                    time_labels=cfg["times"],
                    covariate=dfw[cfg["cov"]].values.astype(float),
                    cov_name=cfg["cov"], alpha=alpha,
                    posthoc_method=posthoc_method)
                meta = {"Test":test_type,"Time Points":", ".join(cfg["times"]),
                        "Covariate(s)":", ".join(cfg["cov"]),"N":R["n"],"Post-Hoc":posthoc_method.title(),
                        "\u03b1":alpha,"Date":datetime.now().strftime("%B %d, %Y %H:%M")}

            elif cfg["type"] == "mixed":
                R = run_mixed_ancova(
                    data_wide=dfw[cfg["times"]].values.astype(float),
                    time_labels=cfg["times"],
                    between_factor=dfw[cfg["between"]].values,
                    covariate=dfw[cfg["cov"]].values.astype(float),
                    between_name=cfg["between"], cov_name=cfg["cov"], alpha=alpha,
                    posthoc_method=posthoc_method)
                meta = {"Test":test_type,"Between Factor":cfg["between"],
                        "Time Points":", ".join(cfg["times"]),
                        "Covariate(s)":", ".join(cfg["cov"]),"N":R["n"],
                        "\u03b1":alpha,"Date":datetime.now().strftime("%B %d, %Y %H:%M")}

            else:  # MANCOVA
                R = run_mancova(
                    y_matrix=dfw[cfg["dvs"]].values.astype(float),
                    factor=dfw[cfg["group"]].values,
                    covariate=dfw[cfg["cov"]].values.astype(float),
                    y_names=cfg["dvs"], factor_name=cfg["group"],
                    cov_name=cfg["cov"], alpha=alpha,
                    posthoc_method=posthoc_method)
                meta = {"Test":test_type,"Factor":cfg["group"],
                        "Covariate(s)":", ".join(cfg["cov"]),
                        "DVs":", ".join(cfg["dvs"]),"N":R["n"],
                        "Post-Hoc":posthoc_method.title(),
                        "\u03b1":alpha,"Date":datetime.now().strftime("%B %d, %Y %H:%M")}

            # Attach remedy context for the results section
            R["transform_info"] = transform_info
            R["_run_cfg"] = cfg
            if transform_info.get("applied"):
                meta["DV Transformation"] = transform_info["label"]

        except ValueError as ve:
            _msg = str(ve)
            if _msg.startswith("__NONNUMERIC__"):
                _cols = _msg.replace("__NONNUMERIC__", "")
                st.error(
                    "&#9888;&#65039; **The data could not be read as numbers.**  \n"
                    f"These column(s) contain non-numeric values: **{_cols}**.  \n\n"
                    "This often happens when a spreadsheet exports **formulas** "
                    "(e.g. `=A2*B2`) or text instead of plain numbers, or when there "
                    "are stray symbols. Please open your file, copy the affected "
                    "columns, and paste them back as **Values** (Paste Special \u2192 "
                    "Values), then re-upload. Make sure each analysis column contains "
                    "only numbers.")
            elif _msg == "__TOOFEW__":
                st.error("&#9888;&#65039; **Not enough complete rows.** After removing "
                         "rows with missing or non-numeric values, fewer than 3 cases "
                         "remained. Please check your data for blanks or text in the "
                         "selected columns.")
            else:
                st.error("&#9888;&#65039; **The analysis could not be completed with "
                         "these data.** Please check that the grouping variable has at "
                         "least two categories, each group has enough cases, and the "
                         "covariate/outcome columns are numeric.")
            st.stop()
        except Exception:
            st.error(
                "&#9888;&#65039; **The analysis could not be completed with the current "
                "data and settings.** This usually means the data don\u2019t fit the "
                "selected design \u2014 for example a group with too few cases, a "
                "covariate that is constant, perfectly collinear covariates, or a "
                "transformation that doesn\u2019t suit these values. Please review your "
                "variable selections and try again; if you applied a transformation, try "
                "\u2018None\u2019 or a different one.")
            st.stop()

    with st.spinner("Generating plots\u2026"):
        figs_b = _make_plot(R)

    interps = _interpret(R, alpha)

    st.session_state.update({
        "ancova_R":       R,
        "ancova_meta":    meta,
        "ancova_interps": interps,
        "ancova_figs":    figs_b,
        "ancova_alpha":   alpha,
        "ancova_test":    test_type,
        "ancova_last_run": test_type,
        "ancova_posthoc": posthoc_method,
    })


# ══════════════════════════════════════════════════════════════════════════════
# LOAD FROM SESSION
# ══════════════════════════════════════════════════════════════════════════════
R         = st.session_state["ancova_R"]
meta      = st.session_state["ancova_meta"]
interps   = st.session_state["ancova_interps"]
figs_b    = st.session_state["ancova_figs"]
alpha     = st.session_state.get("ancova_alpha", 0.05)
test_type = st.session_state["ancova_test"]

st.success("&#10003; Analysis complete!")

# ══════════════════════════════════════════════════════════════════════════════
# DECISION BANNER
# ══════════════════════════════════════════════════════════════════════════════
nr       = R.get("normality", {})
norm_ok  = nr.get("pass", False) if isinstance(nr, dict) else False
lev_ok   = R.get("levene", {}).get("passed",
           R.get("levene", {}).get("equal_var", True))
all_ok   = R.get("all_ok", False)
cls      = "use-param" if all_ok else "use-nonparam"

# Use correct analysis name per test type
_analysis_lbl = {
    "One-Way ANCOVA":           "Parametric ANCOVA",
    "Factorial ANCOVA":         "Parametric Factorial ANCOVA",
    "Repeated Measures ANCOVA": "Parametric RM ANCOVA",
    "Mixed ANCOVA":             "Parametric Mixed ANCOVA",
    "MANCOVA":                  "Parametric MANCOVA",
}.get(test_type, "Parametric ANCOVA")

if isinstance(nr, dict) and "sw_W" in nr:
    prim = nr.get("primary_label","Shapiro-Wilk")
    tn   = nr.get("total_n", nr.get("n", 0))
    size = "Total N\u2009<\u200950" if tn < 50 else "Total N\u2009\u2265\u200950"
    txt  = (f"\u2713 <b>{prim}</b> ({size}) p\u2009>\u2009.05 "
            f"\u2192 Normality satisfied \u2192 <b>{_analysis_lbl} applied.</b>"
            if norm_ok else
            f"\u26a0 <b>{prim}</b> ({size}) p\u2009\u2264\u2009.05 "
            f"\u2192 Normality violated \u2192 <b>Interpret with caution.</b>")
elif isinstance(nr, dict) and nr:
    # MANCOVA — dict of dicts per DV
    all_dv_ok = all(v.get("pass", False) for v in nr.values()
                    if isinstance(v, dict))
    txt = (f"\u2713 All DVs residuals normal \u2192 <b>{_analysis_lbl} applied.</b>"
           if all_dv_ok else
           f"\u26a0 Normality violated for one or more DVs \u2192 "
           f"<b>Interpret with caution.</b>")
else:
    txt = (f"\u2713 <b>{_analysis_lbl} applied.</b>"
           if all_ok else
           f"\u26a0 Check assumptions below.")

st.markdown(f'<div class="decision-banner {cls}">{txt}</div>',
            unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# ASSUMPTION DECISION FLOW & REMEDIES  ("because X → do Y → refer to Z")
# ══════════════════════════════════════════════════════════════════════════════
def _assumption_flow_and_remedies(R, test_type, alpha):
    _ti = R.get("transform_info", {}) or {}
    # 1) Transformation note (if one was applied or attempted)
    if _ti.get("applied"):
        st.markdown(
            f'<div class="decision-banner use-param">&#128295; <b>Transformation '
            f'applied:</b> {_ti["label"]}. {_ti["note"]} Re-check the normality table '
            f'below: if residuals are now normal (p&nbsp;&gt;&nbsp;.05), the ANCOVA '
            f'results are valid on the transformed scale.</div>',
            unsafe_allow_html=True)
    elif _ti.get("feasible", True) is False:
        st.markdown(
            f'<div class="decision-banner use-nonparam">&#9888; <b>Transformation could '
            f'not be applied:</b> {_ti.get("reason","")} Showing results on the original '
            f'scale.</div>', unsafe_allow_html=True)

    # Gather assumption outcomes
    nr = R.get("normality", {})
    if isinstance(nr, dict) and "pass" in nr:
        norm_ok = nr.get("pass", False)
    elif isinstance(nr, dict) and nr:
        norm_ok = all(v.get("pass", False) for v in nr.values() if isinstance(v, dict))
    else:
        norm_ok = True
    lev = R.get("levene", {}) or {}
    lev_ok = lev.get("passed", lev.get("equal_var", True))
    # slopes (may be single or per-factor)
    slope_objs = [R.get(k) for k in ("slopes", "slopes_a", "slopes_b") if R.get(k)]
    slopes_ok = all(s.get("passed", True) for s in slope_objs) if slope_objs else True
    # linearity
    lin_ok = True
    for lk in ("linearity", "linearity_a", "linearity_b"):
        lobj = R.get(lk)
        if isinstance(lobj, pd.DataFrame) and "passed" in lobj.columns and len(lobj):
            lin_ok = lin_ok and bool(lobj["passed"].any())

    st.markdown('<div class="sec-title">Assumption Decision Flow &amp; Recommendations</div>',
                unsafe_allow_html=True)

    notes = []
    # GATE 1 — homogeneity of regression slopes (the ANCOVA gate)
    if not slopes_ok:
        notes.append(
            ('use-nonparam',
             "&#9940; <b>Homogeneity of regression slopes is VIOLATED</b> "
             "(factor&nbsp;\u00d7&nbsp;covariate interaction is significant). "
             "<b>Because</b> the covariate\u2019s effect differs across groups, "
             "<b>the adjusted means from ANCOVA are not trustworthy</b> \u2014 ANCOVA "
             "is not the right model here. <b>Do this:</b> do not rely on the ANCOVA "
             "table above; instead examine each group\u2019s covariate\u2013outcome "
             "relationship separately, and <b>refer to a Johnson-Neyman analysis</b> "
             "(run in SPSS via the PROCESS macro, or in R with the <i>interactions</i> "
             "package) to identify the covariate range over which groups truly differ. "
             "This app does not compute Johnson-Neyman, but it is the methodologically "
             "correct next step when slopes are not parallel."))
    else:
        notes.append(
            ('use-param',
             "&#10003; <b>Homogeneity of regression slopes holds</b> (no significant "
             "factor&nbsp;\u00d7&nbsp;covariate interaction). The core ANCOVA "
             "requirement is met, so the adjusted means are interpretable."))

    # GATE 2 — linearity
    if not lin_ok:
        notes.append(
            ('use-nonparam',
             "&#9888; <b>Linearity may be violated</b> (the covariate is not linearly "
             "related to the outcome within groups). <b>Because</b> ANCOVA assumes a "
             "straight-line covariate\u2013outcome relationship, <b>do this:</b> try a "
             "<b>transformation</b> of the outcome (sidebar) or add a quadratic covariate "
             "term; if it cannot be linearised, ANCOVA results should be treated as "
             "approximate."))

    # GATE 3 — normality of residuals → remedies
    if not norm_ok:
        if test_type == "One-Way ANCOVA":
            notes.append(
                ('use-nonparam',
                 "&#9888; <b>Normality of residuals is violated</b> "
                 "(p&nbsp;\u2264&nbsp;.05). <b>Because</b> ordinary ANCOVA assumes "
                 "normal residuals, you have three valid routes, <b>do</b> any one: "
                 "(1) apply a <b>transformation</b> to the outcome (sidebar) and re-check "
                 "normality; (2) <b>refer to Quade\u2019s non-parametric ANCOVA</b> "
                 "(table below) \u2014 the rank-based equivalent for a one-way design; or "
                 "(3) <b>refer to the Bootstrap ANCOVA</b> (table below), which gives "
                 "valid confidence intervals without assuming normality. With a large, "
                 "balanced sample, ANCOVA is also fairly robust to mild violations."))
        else:
            notes.append(
                ('use-nonparam',
                 "&#9888; <b>Normality of residuals is violated</b> "
                 "(p&nbsp;\u2264&nbsp;.05). <b>Because</b> this design "
                 f"({test_type}) has no exact non-parametric equivalent, <b>do this:</b> "
                 "apply a <b>transformation</b> of the outcome (sidebar) and re-check "
                 "normality, or use a robust / bootstrap procedure. With a large, "
                 "balanced sample the analysis is fairly robust to mild violations; "
                 "interpret results with appropriate caution."))
    else:
        notes.append(
            ('use-param',
             "&#10003; <b>Residuals are approximately normal</b> "
             "(p&nbsp;&gt;&nbsp;.05) \u2014 the parametric results are valid."))

    # GATE 4 — homogeneity of variance (Levene)
    if not lev_ok:
        notes.append(
            ('use-nonparam',
             "&#9888; <b>Homogeneity of variance is violated</b> (Levene "
             "p&nbsp;\u2264&nbsp;.05). <b>Because</b> group variances differ, "
             "<b>do this:</b> prefer a <b>transformation</b> to stabilise variance, "
             "interpret group comparisons cautiously (especially with unequal group "
             "sizes), or use the Bootstrap results which do not assume equal variance."))
    else:
        notes.append(
            ('use-param',
             "&#10003; <b>Homogeneity of variance holds</b> (Levene p&nbsp;&gt;&nbsp;.05)."))

    for css, msg in notes:
        st.markdown(f'<div class="decision-banner {css}">{msg}</div>',
                    unsafe_allow_html=True)

    # ── Quade & Bootstrap tables (One-Way ANCOVA, shown when normality fails) ──
    cfg = R.get("_run_cfg", {})
    if test_type == "One-Way ANCOVA" and not norm_ok and cfg:
        try:
            _dfw = df.copy()
            for _c in [cfg["dv"]] + list(cfg["cov"]):
                _dfw[_c] = pd.to_numeric(_dfw[_c], errors="coerce")
            _dfw = _dfw.dropna(subset=[cfg["dv"], cfg["group"]] + list(cfg["cov"]))
            _yv = _dfw[cfg["dv"]].values.astype(float)
            _gv = _dfw[cfg["group"]].values
            _cv = _dfw[cfg["cov"]].values.astype(float)

            q = quade_ancova(_yv, _gv, _cv, cov_name=cfg["cov"])
            st.markdown('<div class="sec-title">Quade\u2019s Non-Parametric ANCOVA '
                        '(rank-based) \u2014 recommended when residuals are non-normal</div>',
                        unsafe_allow_html=True)
            st.markdown(html_tbl([["F", "df1", "df2", "Sig.", "\u03b7\u00b2 (effect size)"],
                                  [_f(q["F"]), str(q["df1"]), str(q["df2"]),
                                   _p(q["p"]), _f(q["eta2"])]]), unsafe_allow_html=True)
            _qsig = q["sig"]
            st.markdown(
                f'<div class="interp-box {"sig" if _qsig else ""}">'
                f'<b>Interpretation:</b> Quade\u2019s F({q["df1"]},&nbsp;{q["df2"]})'
                f'\u2009=\u2009{_f(q["F"])}, p\u2009=\u2009{_p(q["p"])}. '
                + ("After adjusting for the covariate(s) on ranks, the groups differ "
                   "significantly (p&nbsp;&le;&nbsp;&alpha;). This rank-based result does "
                   "not require normality and supports the group difference."
                   if _qsig else
                   "After adjusting for the covariate(s) on ranks, no significant group "
                   "difference is found (p&nbsp;&gt;&nbsp;&alpha;).")
                + '</div>', unsafe_allow_html=True)

            bt = bootstrap_ancova(_yv, _gv, _cv, cov_name=cfg["cov"], alpha=alpha)
            st.markdown('<div class="sec-title">Bootstrap ANCOVA \u2014 '
                        f'{bt["ci_pct"]}% CIs for adjusted mean differences '
                        '(robust to non-normality)</div>', unsafe_allow_html=True)
            st.markdown('<p class="note-txt">&#9432; <b>Note:</b> bootstrap results are '
                        'based on random resampling (5,000 resamples, fixed seed for '
                        'reproducibility). They are <b>not expected to match SPSS exactly</b> '
                        'and may vary slightly across software; they are validated against '
                        'R. A pair is significant when its confidence interval excludes 0.</p>',
                        unsafe_allow_html=True)
            _bp = bt["pairs"].copy()
            _rows = [list(_bp.columns)]
            for _, r in _bp.iterrows():
                _rows.append([str(r["Group A"]), str(r["Group B"]),
                              _f(r["Adjusted Mean Diff"]), _f(r["CI Lower"]),
                              _f(r["CI Upper"]), _p(r["Bootstrap p"]),
                              "Yes" if r["Significant"] else "No"])
            st.markdown(html_tbl(_rows, left_cols={0,1}), unsafe_allow_html=True)
        except Exception:
            st.markdown('<p class="note-txt">Quade / Bootstrap could not be computed for '
                        'these data; rely on the transformation route or interpret the '
                        'parametric ANCOVA with caution.</p>', unsafe_allow_html=True)

try:
    _assumption_flow_and_remedies(R, test_type, alpha)
except Exception:
    pass
t_type = R["type"]
if t_type == "One-Way ANCOVA":
    metrics = [
        (_f(R.get("F_factor",np.nan)),    f"F(1,\u2009{R.get('n',0)-3})"),
        (_p(R.get("p_factor",np.nan)),     "Sig."),
        (_f(R.get("partial_eta2",np.nan)), "Partial \u03b7\u00b2"),
        (_fmt_grand_cov(R), f"Grand mean covariate(s)"),
        (str(R.get("n","?")),              "N"),
    ]
elif t_type == "Factorial ANCOVA":
    metrics = [
        (_f(R.get("F_a",np.nan)),  f"F {R.get('fa_name','A')}"),
        (_p(R.get("p_a",np.nan)),   "Sig. A"),
        (_f(R.get("F_b",np.nan)),  f"F {R.get('fb_name','B')}"),
        (_p(R.get("p_b",np.nan)),   "Sig. B"),
        (str(R.get("n","?")),       "N"),
    ]
elif t_type == "Repeated Measures ANCOVA":
    metrics = [
        (_f(R.get("F_time",np.nan)),     f"F({R.get('df_time',2)},\u2009{R.get('df_resid_within','?')})"),
        (_p(R.get("p_time_gg",np.nan)),  "Sig. (GG)"),
        (_f(R.get("eta2_time",np.nan)),  "Partial \u03b7\u00b2"),
        (_f(R.get("eps_gg",np.nan)),     "\u03b5 (GG)"),
        (str(R.get("n","?")),            "N Subjects"),
    ]
elif t_type == "Mixed ANCOVA":
    metrics = [
        (_f(R.get("F_interact",np.nan)),  "F Interaction"),
        (_p(R.get("p_interact",np.nan)),   "Sig. Interaction"),
        (_f(R.get("eta2_interact",np.nan)),"Partial \u03b7\u00b2"),
        (_f(R.get("eps_gg",np.nan)),       "\u03b5 (GG)"),
        (str(R.get("n","?")),              "N Subjects"),
    ]
else:  # MANCOVA
    mv = R.get("mv_factor") or {}
    metrics = [
        (_f(mv.get("Wilks",np.nan)),   "Wilks' \u039b"),
        (_p(mv.get("p_Wilks",np.nan)), "Sig. (Wilks)"),
        (_f(mv.get("Pillai",np.nan)),  "Pillai's Trace"),
        (str(R.get("p", R.get("n","?"))), "No. DVs"),
        (str(R.get("n","?")),           "N"),
    ]

cols = st.columns(5)
for col, (val, lbl) in zip(cols, metrics):
    col.markdown(
        f'<div class="metric-card">'
        f'<div class="metric-val">{val}</div>'
        f'<div class="metric-lbl">{lbl}</div>'
        f'</div>',
        unsafe_allow_html=True)
st.markdown("<br>", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# TABS
# ══════════════════════════════════════════════════════════════════════════════
_results_tab_label = {
    "One-Way ANCOVA":          "&#128200; ANCOVA Results",
    "Factorial ANCOVA":        "&#128200; ANCOVA Results",
    "Repeated Measures ANCOVA":"&#128200; RM-ANCOVA Results",
    "Mixed ANCOVA":            "&#128200; Mixed ANCOVA Results",
    "MANCOVA":                 "&#128200; MANCOVA Results",
}.get(t_type, "&#128200; Results")

tab_labels = [
    "&#128203; Assumptions",
    "&#128202; Descriptives",
    _results_tab_label,
    "&#128201; EMMs &amp; Post-Hoc",
    "&#9889; Effect Size &amp; Power",
    "&#128200; Plots",
    "&#128172; Interpretation",
]
tabs = st.tabs(tab_labels)


# ── Tab 0: Assumptions ──────────────────────────────────────────────────────
with tabs[0]:
    nr = R.get("normality", {})
    norm_list = [nr] if isinstance(nr, dict) and "sw_W" in nr else []

    if norm_list:
        prim_lbl  = get_primary_label(norm_list)
        total_n   = get_total_n(norm_list)
        size_lbl  = "Total N\u2009<\u200950" if total_n < 50 else "Total N\u2009\u2265\u200950"
        st.markdown(
            f'<div class="norm-rec-box">{recommendation_note(total_n)}</div>',
            unsafe_allow_html=True)
        st.markdown('<div class="sec-title">Normality of Residuals</div>',
                    unsafe_allow_html=True)
        sw_html, ks_html = normality_table(norm_list, prim_lbl)
        st.markdown('<div class="sub-title">Shapiro-Wilk Test</div>',
                    unsafe_allow_html=True)
        st.markdown(sw_html, unsafe_allow_html=True)
        st.markdown('<div class="sub-title">Kolmogorov-Smirnov Test (Lilliefors)</div>',
                    unsafe_allow_html=True)
        st.markdown(ks_html, unsafe_allow_html=True)
        st.markdown(
            f'<div class="info-box" style="margin-top:.5rem;">{KS_DISCLAIMER}</div>',
            unsafe_allow_html=True)
        if norm_list[0].get("pass"):
            st.markdown(
                f'<div class="info-box">&#10003; <b>{prim_lbl}</b> ({size_lbl}) '
                f'p\u2009>\u2009.05 \u2192 Normality of residuals satisfied.</div>',
                unsafe_allow_html=True)
        else:
            st.markdown(
                f'<div class="warn-box">&#9888; <b>{prim_lbl}</b> ({size_lbl}) '
                f'p\u2009\u2264\u2009.05 \u2192 Normality violated. '
                f'ANCOVA is robust for N\u2009\u2265\u200930.</div>',
                unsafe_allow_html=True)
    # MANCOVA per DV
    elif isinstance(nr, dict) and nr:
        _sec_shown = False
        for dv, dv_nr in nr.items():
            if isinstance(dv_nr, dict) and "sw_W" in dv_nr:
                if not _sec_shown:
                    st.markdown('<div class="sec-title">Normality of Residuals (per DV)</div>',
                                unsafe_allow_html=True)
                    total_n_dv = get_total_n([dv_nr])
                    st.markdown(
                        f'<div class="norm-rec-box">{recommendation_note(total_n_dv)}</div>',
                        unsafe_allow_html=True)
                    _sec_shown = True
                st.markdown(f'<div class="sub-title">{dv}</div>', unsafe_allow_html=True)
                prim_lbl = get_primary_label([dv_nr])
                sw_h, ks_h = normality_table([dv_nr], prim_lbl)
                st.markdown(sw_h, unsafe_allow_html=True)
                st.markdown(ks_h, unsafe_allow_html=True)
        # Descriptive interpretation across all DVs (decision-coloured)
        if _sec_shown:
            _prim = get_primary_label([list(nr.values())[0]])
            _viol = [dv for dv, d in nr.items()
                     if isinstance(d, dict) and not d.get("pass", d.get("sw_pass", False))]
            _okdv = [dv for dv in nr if dv not in _viol]
            _acc, _bg = _INTERP_STYLE["sig" if not _viol else "nonsig"]
            if not _viol:
                _msg = (f"<b>Interpretation:</b> Based on {_prim} (the primary "
                        f"criterion), the residuals of all dependent variables "
                        f"({', '.join(nr.keys())}) are approximately normally "
                        f"distributed (p\u2009&gt;\u2009.05). The multivariate normality "
                        f"assumption is reasonably supported, and the MANCOVA results "
                        f"can be interpreted with confidence.")
            else:
                _msg = (f"<b>Interpretation:</b> Based on {_prim} (the primary "
                        f"criterion), residuals for <b>{', '.join(_viol)}</b> depart "
                        f"from normality (p\u2009\u2264\u2009.05)"
                        + (f", while {', '.join(_okdv)} are normal" if _okdv else "")
                        + ". MANCOVA is robust to moderate violations when group sizes "
                        "are balanced and N is adequate. For the affected variable(s): "
                        "inspect outliers, consider a transformation (e.g. log or "
                        "square-root), and emphasise <b>Pillai\u2019s Trace</b> \u2014 the "
                        "multivariate statistic most robust to assumption violations. "
                        "Interpret the corresponding univariate results with caution.")
            st.markdown(
                f'<div style="border-left:5px solid {_acc};background:{_bg};'
                f'padding:12px 17px;border-radius:0 10px 10px 0;margin:10px 0;'
                f'font-size:.88rem;line-height:1.75;">{_msg}</div>',
                unsafe_allow_html=True)

    # Levene
    lev = R.get("levene", {})
    if lev:
        F_l = lev.get("F", np.nan)
        p_l = lev.get("p", lev.get("Sig.", np.nan))
        eq  = lev.get("passed", lev.get("equal_var", False))
        st.markdown('<div class="sec-title">Levene\u2019s Test for Equality of Variances</div>',
                    unsafe_allow_html=True)
        lev_rows = [["F","Sig.","Decision"],
                    [_f(F_l), _p(p_l),
                     "\u2713 Equal variances" if eq else "\u2717 Unequal variances"]]
        st.markdown(html_tbl(lev_rows), unsafe_allow_html=True)
        if eq:
            st.markdown('<div class="info-box">&#10003; p\u2009>\u2009.05 '
                        '\u2192 Equal variances assumed.</div>',
                        unsafe_allow_html=True)
        else:
            st.markdown('<div class="warn-box">&#9888; p\u2009\u2264\u2009.05 '
                        '\u2192 Unequal variances. Interpret with caution.</div>',
                        unsafe_allow_html=True)

    # Homogeneity of slopes
    for skey, slbl in [("slopes","Homogeneity of Regression Slopes"),
                       ("slopes_a","Regression Slopes — Factor A"),
                       ("slopes_b","Regression Slopes — Factor B")]:
        if skey in R:
            sl = R[skey]
            st.markdown(f'<div class="sec-title">{slbl}</div>',
                        unsafe_allow_html=True)
            s_rows = [["F","Sig.","Decision"],
                      [_f(sl.get("F",np.nan)), _p(sl.get("p",np.nan)),
                       "\u2713 Satisfied" if sl.get("passed") else "\u2717 Violated"]]
            st.markdown(html_tbl(s_rows), unsafe_allow_html=True)
            note = sl.get("note","")
            if note:
                box_cls = "info-box" if sl.get("passed") else "warn-box"
                st.markdown(f'<div class="{box_cls}">{note}</div>',
                            unsafe_allow_html=True)

    # Mauchly (RM / Mixed)
    if "mauchly_W" in R and not np.isnan(R.get("mauchly_W", np.nan)):
        st.markdown('<div class="sec-title">Mauchly\u2019s Test of Sphericity</div>',
                    unsafe_allow_html=True)
        sph_rows = [
            ["Mauchly W","\u03c7\u00b2","df","Sig.","\u03b5 (GG)","Decision"],
            [_f(R["mauchly_W"]), _f(R.get("mauchly_chi2",np.nan)),
             str(R.get("mauchly_df","?")), _p(R.get("mauchly_p",np.nan)),
             _f(R.get("eps_gg",np.nan)),
             "\u2713 Sphericity assumed" if R.get("mauchly_p",0) > 0.05
             else "\u2717 Sphericity violated \u2192 use GG-corrected"],
        ]
        st.markdown(html_tbl(sph_rows, left_cols={5}), unsafe_allow_html=True)
        if R.get("mauchly_p", 1) > 0.05:
            st.markdown('<div class="info-box">&#10003; Sphericity assumed (p\u2009>\u2009.05). '
                        'Uncorrected p-values are valid.</div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="warn-box">&#9888; Sphericity violated (p\u2009\u2264\u2009.05). '
                        f'Use GG-corrected p-values (\u03b5\u2009=\u2009{_f(R.get("eps_gg",np.nan))}).'
                        f'</div>', unsafe_allow_html=True)

    # Linearity
    for lkey, llbl in [("linearity","Linearity: Covariate vs DV"),
                       ("linearity_a","Linearity per Factor A Group"),
                       ("linearity_b","Linearity per Factor B Group")]:
        if lkey in R:
            lin = R[lkey]
            if not lin.empty:
                st.markdown(f'<div class="sec-title">{llbl}</div>',
                            unsafe_allow_html=True)
                lrows = [["Group","N","r","Sig.","Linear?"]]
                for _, row in lin.iterrows():
                    lrows.append([row["Group"],str(row["N"]),
                                  _f(row["r"]), _p(row["Sig."]),
                                  "\u2713 Yes" if row["passed"] else "\u2717 No"])
                st.markdown(html_tbl(lrows, left_cols={0}), unsafe_allow_html=True)
                st.markdown('<p class="note-txt">Significant r (p\u2009&lt;\u2009.05) '
                            'confirms linear covariate\u2013DV relationship.</p>',
                            unsafe_allow_html=True)


# ── Tab 1: Descriptives ─────────────────────────────────────────────────────
with tabs[1]:
    st.markdown('<div class="sec-title">Descriptive Statistics</div>',
                unsafe_allow_html=True)
    desc = R.get("descriptives", pd.DataFrame()).copy()
    if not desc.empty:
        for c in desc.select_dtypes(include=float).columns:
            desc[c] = desc[c].apply(lambda v: _f(v) if not np.isnan(v) else ".")
        st.dataframe(desc, use_container_width=True, hide_index=True)


# ── Tab 2: Results (ANCOVA / RM-ANCOVA / Mixed / MANCOVA per test type) ──────
with tabs[2]:
    # One-Way / Factorial — Between-Subjects Effects
    if "anova_table" in R:
        st.markdown('<div class="sec-title">Tests of Between-Subjects Effects — Type III SS</div>',
                    unsafe_allow_html=True)
        st.markdown(_render_df(R["anova_table"]), unsafe_allow_html=True)
        st.markdown(
            f'<p class="note-txt">Type III (Marginal) SS \u2014 SPSS GLM default. '
            f'Partial \u03b7\u00b2: &lt;.01 negligible, .01\u2013.06 small, '
            f'.06\u2013.14 medium, \u2265.14 large. '
            f'Covariate: {R.get("cov_name","?")}.</p>',
            unsafe_allow_html=True)

        # Parameter Estimates (Factorial)
        _pe = R.get("param_estimates")
        if _pe is not None and hasattr(_pe,"empty") and not _pe.empty:
            st.markdown('<div class="sec-title">Parameter Estimates</div>',
                        unsafe_allow_html=True)
            prows=[list(_pe.columns)]+[[_f(v) if isinstance(v,float) else str(v) for v in _pe.loc[i]] for i in _pe.index]
            st.markdown(html_tbl(prows, left_cols={0}), unsafe_allow_html=True)
            st.markdown(
                '<p class="note-txt">Reference category (last level) set to 0. '
                'Partial η² = t²/(t²+df<sub>error</sub>).</p>',
                unsafe_allow_html=True)

        # Univariate Tests (simple/EMM main effects)
        _ut = R.get("univariate_tests")
        if _ut is not None and hasattr(_ut,"empty") and not _ut.empty:
            st.markdown('<div class="sec-title">Univariate Tests</div>',
                        unsafe_allow_html=True)
            urows=[list(_ut.columns)]+[[_f(v) if isinstance(v,float) else str(v) for v in _ut.loc[i]] for i in _ut.index]
            st.markdown(html_tbl(urows, left_cols={0,1}), unsafe_allow_html=True)
            st.markdown(
                '<p class="note-txt">F tests the effect of each factor on the '
                'estimated marginal means, adjusted for the covariate.</p>',
                unsafe_allow_html=True)

    # ── MANCOVA-specific results (own block; MANCOVA has no single anova_table) ──
    if t_type == "MANCOVA":
        # Box's M
        bm = R.get("boxes_m")
        if bm:
            st.markdown('<div class="sec-title">Box\'s Test of Equality of Covariance Matrices</div>',
                        unsafe_allow_html=True)
            bm_rows = [["Box's M","F","df1","df2","Sig."],
                       [_f(bm["M"]), _f(bm["F"]), str(bm["df1"]),
                        _f(bm["df2"]), _p(bm["Sig."])]]
            st.markdown(html_tbl(bm_rows), unsafe_allow_html=True)
            st.markdown(
                '<p class="note-txt">Tests H₀: observed covariance matrices are equal. '
                'p &gt; .05 → assumption satisfied. '
                'This test is sensitive to non-normality.</p>',
                unsafe_allow_html=True)
            _bm_p = bm.get("Sig.", np.nan)
            try: _bm_p = float(_bm_p)
            except Exception: _bm_p = np.nan
            _bm_ok = (not np.isnan(_bm_p)) and _bm_p > .05
            _acc, _bg = _INTERP_STYLE["sig" if _bm_ok else "nonsig"]
            st.markdown(
                f'<div style="border-left:5px solid {_acc};background:{_bg};'
                f'padding:11px 16px;border-radius:0 8px 8px 0;margin:8px 0;'
                f'font-size:.86rem;line-height:1.7;">'
                f'<b>Interpretation:</b> Box\u2019s M = {_f(bm.get("M"))}, '
                f'F = {_f(bm.get("F"))}, p = {_p(_bm_p)}. '
                + ("The homogeneity of covariance matrices assumption is satisfied "
                   "(p &gt; .05); Pillai\u2019s Trace and the other multivariate tests "
                   "can be interpreted with confidence."
                   if _bm_ok else
                   "The assumption may be violated (p \u2264 .05). With equal group "
                   "sizes MANCOVA is robust; otherwise prefer Pillai\u2019s Trace, "
                   "which is most robust to this violation.")
                + '</div>', unsafe_allow_html=True)

        # Multivariate Tests — all 3 effects: Intercept, Covariate, Factor (SPSS order)
        _mv_hdr = ["Statistic","Value","F","Hypothesis df","Error df",
                   "Sig.","Partial \u03b7\u00b2","Noncent. Parameter"]

        def _mv_block(mv):
            if not mv: return []
            return [
                ["Pillai\u2019s Trace",
                 _f(mv["Pillai"]),    _f(mv["F_Pillai"]),
                 str(mv.get("df_hyp_Pillai","—")), str(mv.get("df_err_Pillai","—")),
                 _p(mv["p_Pillai"]),  _f(mv.get("eta2_Pillai","")),
                 _f(mv.get("noncent_Pillai",""))],
                ["Wilks\u2019 Lambda",
                 _f(mv["Wilks"]),     _f(mv["F_Wilks"]),
                 str(mv.get("df_hyp_Wilks","—")),  str(mv.get("df_err_Wilks","—")),
                 _p(mv["p_Wilks"]),   _f(mv.get("eta2_Wilks","")),
                 _f(mv.get("noncent_Wilks",""))],
                ["Hotelling-Lawley Trace",
                 _f(mv["Hotelling"]), _f(mv["F_HL"]),
                 str(mv.get("df_hyp_HL","—")),     str(mv.get("df_err_HL","—")),
                 _p(mv["p_HL"]),      _f(mv.get("eta2_HL","")),
                 _f(mv.get("noncent_HL",""))],
                ["Roy\u2019s Largest Root",
                 _f(mv["Roy"]),       _f(mv["F_Roy"]),
                 str(mv.get("df_hyp_Roy","—")),    str(mv.get("df_err_Roy","—")),
                 _p(mv["p_Roy"]),     _f(mv.get("eta2_Roy","")),
                 _f(mv.get("noncent_Roy",""))],
            ]

        for _eff_lbl, _mv_data in [
            ("Intercept",                    R.get("mv_intercept")),
            (R.get("cov_name","Covariate"),  R.get("mv_cov")),
            (R.get("factor_name","Group"),   R.get("mv_factor")),
        ]:
            _rows = _mv_block(_mv_data)
            if _rows:
                st.markdown(f'<div class="sec-title">Multivariate Tests \u2014 {_eff_lbl}</div>',
                            unsafe_allow_html=True)
                st.markdown(html_tbl([_mv_hdr]+_rows, left_cols={0}), unsafe_allow_html=True)
        st.markdown(
            '<p class="note-txt">Partial \u03b7\u00b2: Pillai=V/s; Wilks=1\u2212\u039b\u00b9\u141f\u02e2; '
            'Hotelling=T\u2080/(T\u2080+s); Roy=\u03b8/(1+\u03b8). '
            'Noncentrality parameter (\u03bb)\u2009=\u2009F\u2009\u00d7\u2009hypothesis df; '
            'larger \u03bb \u2192 greater statistical power.</p>',
            unsafe_allow_html=True)
        _mvf = R.get("mv_factor") or {}
        if _mvf:
            try: _pw = float(_mvf.get("p_Wilks", np.nan))
            except Exception: _pw = np.nan
            _sig_mv = (not np.isnan(_pw)) and _pw < alpha
            _acc, _bg = _INTERP_STYLE["sig" if _sig_mv else "nonsig"]
            st.markdown(
                f'<div style="border-left:5px solid {_acc};background:{_bg};'
                f'padding:11px 16px;border-radius:0 8px 8px 0;margin:8px 0;'
                f'font-size:.86rem;line-height:1.7;">'
                f'<b>Interpretation:</b> The multivariate effect of '
                f'{R.get("factor_name","group")} (Wilks\u2019 \u039b = '
                f'{_f(_mvf.get("Wilks"))}, F = {_f(_mvf.get("F_Wilks"))}, '
                f'p = {_p(_pw)}) is '
                + ("<b>statistically significant</b>. After controlling for "
                   f"{R.get('cov_name','the covariate')}, the groups differ on the "
                   "combined dependent variables; examine the univariate ANCOVAs "
                   "below to locate which dependent variable(s) drive the effect."
                   if _sig_mv else
                   "<b>not statistically significant</b>. After controlling for "
                   f"{R.get('cov_name','the covariate')}, there is insufficient "
                   "evidence that the groups differ on the combined dependent "
                   "variables; univariate follow-ups should be interpreted "
                   "cautiously.")
                + '</div>', unsafe_allow_html=True)

        # Levene per DV
        lev_mc = R.get("levene_mancova", pd.DataFrame())
        if not lev_mc.empty:
            st.markdown('<div class="sec-title">Levene\'s Test of Equality of Error Variances</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_df(lev_mc, left_cols={0}), unsafe_allow_html=True)
            try:
                _sigc = next(c for c in lev_mc.columns if "Sig" in str(c) or str(c).lower()=="p")
                _pv = pd.to_numeric(lev_mc[_sigc], errors="coerce")
                _nv = int((_pv < alpha).sum())
                _dvc = lev_mc.columns[0]
                _viol = lev_mc.loc[_pv < alpha, _dvc].astype(str).tolist()
            except Exception:
                _nv = 0; _viol = []
            _acc, _bg = _INTERP_STYLE["sig" if _nv == 0 else "nonsig"]
            st.markdown(
                f'<div style="border-left:5px solid {_acc};background:{_bg};'
                f'padding:11px 16px;border-radius:0 8px 8px 0;margin:8px 0;'
                f'font-size:.86rem;line-height:1.7;">'
                f'<b>Interpretation:</b> '
                + ("All dependent variables satisfy equality of error variances "
                   "(all p &gt; .05); the homogeneity-of-variance assumption holds "
                   "for every univariate ANCOVA below."
                   if _nv == 0 else
                   f"{_nv} dependent variable(s) "
                   f"({', '.join(_viol)}) show unequal error variances (p \u2264 .05). "
                   "Interpret the corresponding univariate ANCOVA(s) with caution; "
                   "consider a more conservative \u03b1 or a robust alternative.")
                + '</div>', unsafe_allow_html=True)

        # Univariate ANCOVA per DV
        univ = R.get("univariate", pd.DataFrame())
        if not univ.empty:
            st.markdown('<div class="sec-title">Tests of Between-Subjects Effects (Univariate ANCOVAs)</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_df(univ, left_cols={0,1}), unsafe_allow_html=True)
            st.markdown(
                '<p class="note-txt">Type III SS. Each DV tested separately with the covariate. '
                'Partial η²: ≥.01 small, ≥.06 medium, ≥.14 large.</p>',
                unsafe_allow_html=True)
            # Per-DV factor-effect interpretation
            _fac = R.get("factor_name", "group")
            for _, _row in univ.iterrows():
                if str(_row.get("Source","")) != _fac:
                    continue
                _dv = _row.get("Dependent Variable","DV")
                try: _pv2 = float(_row.get("Sig.", np.nan))
                except Exception: _pv2 = np.nan
                try: _eta2 = float(_row.get("Partial \u03b7\u00b2", np.nan))
                except Exception: _eta2 = np.nan
                _sg = (not np.isnan(_pv2)) and _pv2 < alpha
                _acc, _bg = _INTERP_STYLE["sig" if _sg else "nonsig"]
                st.markdown(
                    f'<div style="border-left:5px solid {_acc};background:{_bg};'
                    f'padding:10px 15px;border-radius:0 8px 8px 0;margin:7px 0;'
                    f'font-size:.85rem;line-height:1.65;">'
                    f'<b>{_dv}:</b> effect of {_fac} '
                    f'(F = {_f(_row.get("F"))}, p = {_p(_pv2)}, '
                    f'partial \u03b7\u00b2 = {_f(_eta2)} \u2014 {_effect_label(_eta2)}) is '
                    + ("<b>statistically significant</b>; groups differ on this "
                       "dependent variable after adjusting for the covariate."
                       if _sg else
                       "<b>not statistically significant</b>; no reliable group "
                       "difference on this dependent variable after adjustment.")
                    + '</div>', unsafe_allow_html=True)

    # Noncentrality helper (shared by RM and Mixed within/between tables)
    def _nc(F, df):
        try: return _f(round(float(F)*float(df), 3))
        except Exception: return "\u2014"

    # Reusable multivariate block (RM/Mixed within-subjects)
    def _mv_within_tbl(mv, eff_lbl):
        if not mv: return ""
        rows = [["Statistic","Value","F","Hypothesis df","Error df","Sig.","Partial \u03b7\u00b2","Noncent."],
            ["Pillai\u2019s Trace",_f(mv["Pillai"]),_f(mv["F_Pillai"]),
             str(mv.get("df_hyp","?")),str(mv.get("df_err","?")),
             _p(mv["p_Pillai"]),_f(mv.get("eta2","")),_f(mv.get("noncent",""))],
            ["Wilks\u2019 Lambda",_f(mv["Wilks"]),_f(mv["F_Wilks"]),
             str(mv.get("df_hyp","?")),str(mv.get("df_err","?")),
             _p(mv["p_Wilks"]),_f(mv.get("eta2","")),_f(mv.get("noncent",""))],
            ["Hotelling-Lawley",_f(mv.get("Hotelling",np.nan)),_f(mv.get("F_HL",np.nan)),
             str(mv.get("df_hyp","?")),str(mv.get("df_err","?")),
             _p(mv.get("p_HL",np.nan)),_f(mv.get("eta2","")),_f(mv.get("noncent",""))],
            ["Roy\u2019s Largest Root",_f(mv.get("Roy",np.nan)),_f(mv.get("F_Roy",np.nan)),
             str(mv.get("df_hyp","?")),str(mv.get("df_err","?")),
             _p(mv.get("p_Roy",np.nan)),_f(mv.get("eta2","")),_f(mv.get("noncent",""))],
        ]
        return (f'<div class="sec-title">Multivariate Tests \u2014 {eff_lbl}</div>'
                + html_tbl(rows, left_cols={0}))

    # RM ANCOVA
    if t_type == "Repeated Measures ANCOVA":
        cn = R.get("cov_name","Covariate")
        if R.get("mv_time"):
            st.markdown(_mv_within_tbl(R["mv_time"], "TIME"), unsafe_allow_html=True)
        if R.get("mv_tc"):
            st.markdown(_mv_within_tbl(R["mv_tc"], f"TIME \u00d7 {cn}"), unsafe_allow_html=True)

        st.markdown('<div class="sec-title">Tests of Within-Subjects Effects</div>',
                    unsafe_allow_html=True)
        wr = [["Source","Type III SS","df","MS","F",
               "Sig. (Uncorrected)","Sig. (GG)","\u03b5 (GG)","Partial \u03b7\u00b2","Noncent. Parameter"],
              ["TIME",_f(R.get("SS_time",np.nan)),str(R.get("df_time","?")),
               _f(R.get("MS_time",np.nan)),_f(R.get("F_time",np.nan)),
               _p(R.get("p_time",np.nan)),_p(R.get("p_time_gg",np.nan)),
               _f(R.get("eps_gg",np.nan)),_f(R.get("eta2_time",np.nan)),
               _nc(R.get("F_time",np.nan), R.get("df_time",1))],
              [f"TIME \u00d7 {R.get('cov_name','COV')}",
               _f(R.get("SS_tc",np.nan)),str(R.get("df_tc","?")),"\u2014",
               _f(R.get("F_tc",np.nan)),_p(R.get("p_tc",np.nan)),"\u2014","\u2014",
               _f(R.get("eta2_tc",np.nan)),
               _nc(R.get("F_tc",np.nan), R.get("df_tc",1))]]
        st.markdown(html_tbl(wr, left_cols={0}), unsafe_allow_html=True)
        st.markdown(
            f'<p class="note-txt">Error df\u2009=\u2009{R.get("df_resid_within","?")} '
            f'= (T\u22121)(N\u22121\u2212p) \u2014 SPSS formula.</p>',
            unsafe_allow_html=True)

        st.markdown('<div class="sec-title">Tests of Between-Subjects Effects (Covariate)</div>',
                    unsafe_allow_html=True)
        br = [["Source","SS","df","F","Sig.","Partial \u03b7\u00b2","Noncent. Parameter"],
              [R.get("cov_name","Covariate"),_f(R.get("SS_cov",np.nan)),"1",
               _f(R.get("F_cov",np.nan)),_p(R.get("p_cov",np.nan)),
               _f(R.get("eta2_cov",np.nan)),_nc(R.get("F_cov",np.nan), 1)],
              ["Error","\u2014",str(R.get("df_err_between","?")),"\u2014","\u2014","\u2014","\u2014"]]
        st.markdown(html_tbl(br, left_cols={0}), unsafe_allow_html=True)

        # Within-Subjects Contrasts
        _cdf = R.get("contrasts")
        if _cdf is not None and hasattr(_cdf,"empty") and not _cdf.empty:
            st.markdown('<div class="sec-title">Tests of Within-Subjects Contrasts</div>',
                        unsafe_allow_html=True)
            crows=[list(_cdf.columns)]+[[_f(v) if isinstance(v,float) else str(v) for v in _cdf.loc[i]] for i in _cdf.index]
            st.markdown(html_tbl(crows, left_cols={0,1}), unsafe_allow_html=True)

    # Mixed ANCOVA
    if t_type == "Mixed ANCOVA":
        cn = R.get("cov_name","Covariate"); bn = R.get("between_name","Group")
        # Box's M Test
        bm = R.get("boxes_m")
        if bm:
            st.markdown('<div class="sec-title">Box\'s Test of Equality of Covariance Matrices</div>',
                        unsafe_allow_html=True)
            bm_rows = [["Box's M","F","df1","df2","Sig."],
                       [_f(bm["M"]), _f(bm["F"]), str(bm["df1"]),
                        _f(bm["df2"]), _p(bm["Sig."])]]
            st.markdown(html_tbl(bm_rows), unsafe_allow_html=True)
            st.markdown(
                '<p class="note-txt">Tests H₀: covariance matrices of the repeated '
                'measures are equal across groups. p &gt; .05 → assumption satisfied.</p>',
                unsafe_allow_html=True)
        if R.get("mv_time"):
            st.markdown(_mv_within_tbl(R["mv_time"], "TIME"), unsafe_allow_html=True)
        if R.get("mv_tg"):
            st.markdown(_mv_within_tbl(R["mv_tg"], f"TIME \u00d7 {bn}"), unsafe_allow_html=True)
        if R.get("mv_tc"):
            st.markdown(_mv_within_tbl(R["mv_tc"], f"TIME \u00d7 {cn}"), unsafe_allow_html=True)

        st.markdown('<div class="sec-title">Tests of Within-Subjects Effects</div>',
                    unsafe_allow_html=True)
        wh = [["Source","SS","df","F","Sig.","\u03b5 (GG)","Partial \u03b7\u00b2","Noncent. Parameter"],
              ["TIME",_f(R.get("SS_time",np.nan)),str(R.get("df_time",2)),
               _f(R.get("F_time",np.nan)),_p(R.get("p_time",np.nan)),
               _f(R.get("eps_gg",np.nan)),_f(R.get("eta2_time",np.nan)),
               _nc(R.get("F_time",np.nan), R.get("df_time",2))],
              [f"TIME \u00d7 {R.get('between_name','Group')}",
               _f(R.get("SS_interact",np.nan)),
               str((R.get("T",3)-1)*(R.get("k",2)-1)),
               _f(R.get("F_interact",np.nan)),_p(R.get("p_interact",np.nan)),
               "\u2014",_f(R.get("eta2_interact",np.nan)),
               _nc(R.get("F_interact",np.nan),(R.get("T",3)-1)*(R.get("k",2)-1))],
              [f"TIME \u00d7 {R.get('cov_name','COV')}",
               _f(R.get("SS_tc",np.nan)),str(R.get("T",3)-1),
               _f(R.get("F_tc",np.nan)),_p(R.get("p_tc",np.nan)),
               "\u2014",_f(R.get("eta2_tc",np.nan)),
               _nc(R.get("F_tc",np.nan), R.get("T",3)-1)]]
        st.markdown(html_tbl(wh, left_cols={0}), unsafe_allow_html=True)
        st.markdown(
            f'<p class="note-txt">Error df\u2009=\u2009{R.get("df_resid_within","?")} '
            f'= (T\u22121)(N\u2212k\u2212p) \u2014 SPSS formula.</p>',
            unsafe_allow_html=True)

        st.markdown('<div class="sec-title">Tests of Between-Subjects Effects</div>',
                    unsafe_allow_html=True)
        bh = [["Source","SS","df","F","Sig.","Partial \u03b7\u00b2","Noncent. Parameter"],
              [R.get("between_name","Group"),_f(R.get("SS_between",np.nan)),
               str(R.get("df_between","?")),_f(R.get("F_between",np.nan)),
               _p(R.get("p_between",np.nan)),_f(R.get("eta2_between",np.nan)),
               _nc(R.get("F_between",np.nan), R.get("df_between",1))],
              [R.get("cov_name","Covariate"),_f(R.get("SS_cov",np.nan)),"1",
               _f(R.get("F_cov",np.nan)),_p(R.get("p_cov",np.nan)),
               _f(R.get("eta2_cov",np.nan)),
               _nc(R.get("F_cov",np.nan), 1)],
              ["Error","\u2014",str(R.get("df_resid_between","?")),"\u2014","\u2014","\u2014","\u2014"]]
        st.markdown(html_tbl(bh, left_cols={0}), unsafe_allow_html=True)

        # Within-Subjects Contrasts
        _cdf = R.get("contrasts")
        if _cdf is not None and hasattr(_cdf,"empty") and not _cdf.empty:
            st.markdown('<div class="sec-title">Tests of Within-Subjects Contrasts</div>',
                        unsafe_allow_html=True)
            crows=[list(_cdf.columns)]+[[_f(v) if isinstance(v,float) else str(v) for v in _cdf.loc[i]] for i in _cdf.index]
            st.markdown(html_tbl(crows, left_cols={0,1}), unsafe_allow_html=True)


# ── Tab 3: EMMs & Post-Hoc ──────────────────────────────────────────────────
with tabs[3]:
    st.markdown('<div class="sec-title">Estimated Marginal Means</div>',
                unsafe_allow_html=True)
    st.markdown(
        f'<p class="note-txt">Computed at grand mean of covariate(s): '
        f'{_fmt_grand_cov(R)} \u2014 SPSS method.</p>',
        unsafe_allow_html=True)

    for k, lbl in [("emm","Estimated Marginal Means"),
                   ("emm_cell","Cell EMMs (Group \u00d7 Time)"),
                   ("emm_group","Group EMMs (averaged over time)"),
                   ("emm_time","Time EMMs (averaged over groups)"),
                   ("emm_a",f"Marginal Means \u2014 {R.get('fa_name','')} (averaged over {R.get('fb_name','')})"),
                   ("emm_b",f"Marginal Means \u2014 {R.get('fb_name','')} (averaged over {R.get('fa_name','')})")]:
        df_ = R.get(k)
        if df_ is not None and hasattr(df_,"empty") and not df_.empty:
            _lbl = ("Adjusted Means (EMMs) per Dependent Variable"
                    if (k == "emm" and R.get("type") == "MANCOVA") else lbl)
            st.markdown(f'<div class="sub-title">{_lbl}</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_df(df_), unsafe_allow_html=True)

    has_pw = any(
        R.get(k) is not None and hasattr(R.get(k),"empty") and not R[k].empty
        for k in ["pairwise","pairwise_a","pairwise_b","pairwise_time","pairwise_group"])
    if has_pw:
        st.markdown('<div class="sec-title">Pairwise Comparisons</div>',
                    unsafe_allow_html=True)
        for k, lbl in [("pairwise", f"Pairwise ({posthoc_method.title()})"),
                       ("pairwise_a", f"Pairwise \u2014 {R.get('fa_name','')} ({posthoc_method.title()})"),
                       ("pairwise_b", f"Pairwise \u2014 {R.get('fb_name','')} ({posthoc_method.title()})"),
                       ("pairwise_time",f"Pairwise TIME ({posthoc_method.title()})"),
                       ("pairwise_group",f"Pairwise GROUP ({posthoc_method.title()})")]:
            df_ = R.get(k)
            if df_ is not None and hasattr(df_,"empty") and not df_.empty:
                st.markdown(f'<div class="sub-title">{lbl}</div>',
                            unsafe_allow_html=True)
                st.markdown(_render_df(df_, {0,1}), unsafe_allow_html=True)
        st.markdown(
            '<p class="note-txt">* = significant at selected \u03b1. '
            'Two-tailed. 95% CI adjusted for family-wise error rate.</p>',
            unsafe_allow_html=True)
    else:
        st.info("Pairwise comparisons not available for this ANCOVA type.")


# ── Tab 4: Effect Size & Power ───────────────────────────────────────────────
with tabs[4]:
    st.markdown('<div class="sec-title">Effect Size &amp; Statistical Power</div>',
                unsafe_allow_html=True)
    from scipy import stats as sc
    def _pwr(eta2, df_num=1, df_den=None):
        if np.isnan(eta2) or eta2 >= 1: return np.nan
        f2 = eta2 / (1-eta2)
        dn = df_den or max(R.get("n",30)-2, 1)
        try:
            ncp = f2 * (df_num + dn + 1)
            fc  = sc.f.ppf(1-alpha, df_num, dn)
            return float(np.clip(sc.ncf.sf(fc, df_num, dn, ncp), 0, 1))
        except: return np.nan

    es_rows = [["Effect","Partial \u03b7\u00b2","Cohen's f","Interpretation","Power"]]
    def _add(lbl, eta2, dfn=1, dfd=None):
        if np.isnan(eta2): return
        f_val = float(np.sqrt(eta2/(1-eta2))) if eta2 < 1 else np.nan
        pwr   = _pwr(eta2, dfn, dfd or max(R.get("n",30)-2,1))
        es_rows.append([lbl, _f(eta2),
                        _f(f_val) if not np.isnan(f_val) else "\u2014",
                        _effect_label(eta2),
                        f"{pwr*100:.1f}%" if not np.isnan(pwr) else "\u2014"])
    for key, lbl in [("partial_eta2","Group (Factor)"),("eta2_a","Factor A"),
                     ("eta2_b","Factor B"),("eta2_ab","Interaction A\u00d7B"),
                     ("eta2_time","Time (Within)"),("eta2_between","Between-Subjects"),
                     ("eta2_interact","Interaction"),("eta2_cov","Covariate")]:
        v = R.get(key, np.nan)
        if v is not None and not np.isnan(v): _add(lbl, v)

    # MANCOVA: effect sizes live per DV inside the univariate ANCOVA table
    if t_type == "MANCOVA":
        univ = R.get("univariate", pd.DataFrame())
        if univ is not None and not univ.empty and "Partial \u03b7\u00b2" in univ.columns:
            _skip = {"Corrected Model", "Intercept", "Error", "Corrected Total", "Total"}
            for _, row in univ.iterrows():
                src = str(row.get("Source", ""))
                if src in _skip:
                    continue
                dv = row.get("Dependent Variable", "DV")
                try: eta = float(row.get("Partial \u03b7\u00b2", np.nan))
                except Exception: eta = np.nan
                try: dfn = float(row.get("df", 1))
                except Exception: dfn = 1
                _add(f"{dv} \u2014 {src}", eta, dfn=int(dfn) if dfn==dfn else 1)

    st.markdown(html_tbl(es_rows, left_cols={0,3}),
                unsafe_allow_html=True)
    if len(es_rows) == 1:
        st.info("Effect-size estimates are not available for this analysis.")
    st.markdown(
        '<p class="note-txt">Partial \u03b7\u00b2 benchmarks: '
        '\u2265.01 small, \u2265.06 medium, \u2265.14 large (Cohen, 1988). '
        'Power based on non-central F distribution at selected \u03b1.</p>',
        unsafe_allow_html=True)


# ── Tab 5: Plots ─────────────────────────────────────────────────────────────
with tabs[5]:
    if figs_b:
        for lbl, b64 in figs_b:
            st.markdown(f'<div class="sec-title">{lbl}</div>',
                        unsafe_allow_html=True)
            st.image(base64.b64decode(b64))
    else:
        st.info("No plots available for this analysis.")


# ── Tab 6: Interpretation ────────────────────────────────────────────────────
with tabs[6]:
    st.markdown('<div class="sec-title">Academic Interpretation</div>',
                unsafe_allow_html=True)
    st.markdown(
        '<p class="note-txt">Colour key: '
        '<span style="color:#16a34a;font-weight:700;">green</span> = significant / '
        'assumption met, '
        '<span style="color:#f59e0b;font-weight:700;">amber</span> = non-significant / '
        'assumption caution, '
        '<span style="color:#0284c7;font-weight:700;">blue</span> = summary.</p>',
        unsafe_allow_html=True)
    for line in interps:
        cls = _interp_cls(line)
        accent, bg = _INTERP_STYLE[cls]
        st.markdown(
            f'<div style="border-left:5px solid {accent};background:{bg};'
            f'padding:13px 18px;border-radius:0 10px 10px 0;margin:10px 0;'
            f'font-size:.92rem;line-height:1.85;color:#1e293b;">{line}</div>',
            unsafe_allow_html=True)

    # APA 7 reporting
    apa_lines = _apa_report(R, alpha)
    if apa_lines:
        st.markdown('<div class="sec-title">APA 7th-Edition Reporting</div>',
                    unsafe_allow_html=True)
        body = "<br><br>".join(apa_lines)
        st.markdown(
            f'<div style="background:#f8fafc;border:1px solid #e2e8f0;'
            f'border-radius:10px;padding:16px 20px;font-size:.9rem;line-height:1.9;'
            f'color:#1e293b;border-left:5px solid #1a1a2e;">'
            f'<div style="font-size:.72rem;font-weight:700;color:#64748b;'
            f'text-transform:uppercase;letter-spacing:.8px;margin-bottom:8px;">'
            f'Ready-to-paste APA 7 results</div>{body}</div>',
            unsafe_allow_html=True)
        st.markdown(
            '<p class="note-txt">Italicise statistical symbols (F, p, \u03b7\u00b2) when '
            'pasting into your manuscript, per APA 7th-edition style.</p>',
            unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# DOWNLOADS  (identical pattern to 2_anova.py)
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("---")
dc1, dc2 = st.columns(2)
ts = datetime.now().strftime("%Y%m%d_%H%M%S")
nm = test_type.replace(" ", "_")

with dc1:
    with st.spinner("Generating HTML report\u2026"):
        html_data = _build_html(R, meta, interps, figs_b, alpha)
    st.download_button(
        "&#127760; HTML Report (Full)",
        html_data,
        f"ANCOVA_{nm}_{ts}.html",
        "text/html", use_container_width=True)

with dc2:
    parts = [f"INFERENTIAL STATISTICS BY MA \u2014 ANCOVA\n"]
    parts.append(f"Generated: {datetime.now().strftime('%B %d, %Y %H:%M')}\n")
    parts.append("\n=== ANALYSIS INFORMATION ===\n"
                 + pd.DataFrame([{"Parameter": k, "Value": str(v)}
                                  for k, v in meta.items()]).to_csv(index=False))
    for k, lbl in [("anova_table","TESTS OF BETWEEN-SUBJECTS EFFECTS"),
                   ("univariate","TESTS OF BETWEEN-SUBJECTS EFFECTS (UNIVARIATE ANCOVAS)"),
                   ("param_estimates","PARAMETER ESTIMATES"),
                   ("univariate_tests","UNIVARIATE TESTS"),
                   ("contrasts","TESTS OF WITHIN-SUBJECTS CONTRASTS"),
                   ("levene_mancova","LEVENE'S TEST PER DEPENDENT VARIABLE"),
                   ("linearity","LINEARITY: COVARIATE VS DV"),
                   ("linearity_a","LINEARITY PER FACTOR A GROUP"),
                   ("linearity_b","LINEARITY PER FACTOR B GROUP"),
                   ("emm","ESTIMATED MARGINAL MEANS"),
                   ("emm_cell","CELL EMMs (GROUP x TIME)"),
                   ("emm_group","GROUP EMMs"), ("emm_time","TIME EMMs"),
                   ("emm_a","MARGINAL MEANS - FACTOR A"),
                   ("emm_b","MARGINAL MEANS - FACTOR B"),
                   ("pairwise","PAIRWISE COMPARISONS"),
                   ("pairwise_a","PAIRWISE COMPARISONS (FACTOR A)"),
                   ("pairwise_b","PAIRWISE COMPARISONS (FACTOR B)"),
                   ("pairwise_time","PAIRWISE COMPARISONS (TIME)"),
                   ("pairwise_group","PAIRWISE COMPARISONS (GROUP)"),
                   ("descriptives","DESCRIPTIVE STATISTICS")]:
        df_ = R.get(k)
        if df_ is not None and hasattr(df_, "empty") and not df_.empty:
            parts.append(f"\n=== {lbl} ===\n" + df_.to_csv(index=False))

    # Assumption tests stored as dicts (Levene univariate, homogeneity of slopes)
    _lev_u = R.get("levene", {})
    if _lev_u:
        parts.append("\n=== LEVENE'S TEST FOR EQUALITY OF VARIANCES ===\n"
                     + pd.DataFrame([{"F": _lev_u.get("F",""),
                                      "Sig.": _lev_u.get("p", _lev_u.get("Sig.","")),
                                      "Equal variances":
                                          _lev_u.get("passed", _lev_u.get("equal_var",""))}]
                                    ).to_csv(index=False))
    for _sk, _slbl in [("slopes","HOMOGENEITY OF REGRESSION SLOPES"),
                       ("slopes_a","REGRESSION SLOPES - FACTOR A"),
                       ("slopes_b","REGRESSION SLOPES - FACTOR B")]:
        _s = R.get(_sk)
        if _s:
            parts.append(f"\n=== {_slbl} ===\n"
                         + pd.DataFrame([{"F": _s.get("F",""), "Sig.": _s.get("p",""),
                                          "Satisfied": _s.get("passed","")}]
                                        ).to_csv(index=False))

    # Effect Size & Statistical Power table
    try:
        from scipy import stats as _scc
        def _pwc(e2, dfn=1):
            if e2 is None or (isinstance(e2,float) and np.isnan(e2)) or e2 >= 1: return ""
            f2 = e2/(1-e2); dn = max(R.get("n",30)-2,1)
            try:
                ncp = f2*(dfn+dn+1); fc = _scc.f.ppf(1-alpha, dfn, dn)
                return f"{float(np.clip(_scc.ncf.sf(fc,dfn,dn,ncp),0,1))*100:.1f}%"
            except Exception: return ""
        _esr = []
        for _k,_l in [("partial_eta2","Group (Factor)"),("eta2_a","Factor A"),
                      ("eta2_b","Factor B"),("eta2_ab","Interaction AxB"),
                      ("eta2_time","Time (Within)"),("eta2_between","Between-Subjects"),
                      ("eta2_interact","Interaction"),("eta2_cov","Covariate")]:
            _v = R.get(_k, np.nan)
            if _v is not None and not (isinstance(_v,float) and np.isnan(_v)):
                _f2 = float(np.sqrt(_v/(1-_v))) if _v < 1 else np.nan
                _esr.append({"Effect":_l,"Partial eta2":round(float(_v),3),
                             "Cohen's f": round(_f2,3) if not np.isnan(_f2) else "",
                             "Power": _pwc(_v)})
        if t == "MANCOVA":
            _u = R.get("univariate", pd.DataFrame())
            if _u is not None and not _u.empty and "Partial \u03b7\u00b2" in _u.columns:
                for _, _row in _u.iterrows():
                    if str(_row.get("Source","")) in {"Corrected Model","Intercept","Error","Corrected Total","Total"}:
                        continue
                    try: _e2 = float(_row.get("Partial \u03b7\u00b2", np.nan))
                    except Exception: _e2 = np.nan
                    if np.isnan(_e2): continue
                    _f2 = float(np.sqrt(_e2/(1-_e2))) if _e2 < 1 else np.nan
                    try: _dfn = int(float(_row.get("df",1)))
                    except Exception: _dfn = 1
                    _esr.append({"Effect": f"{_row.get('Dependent Variable','DV')} - {_row.get('Source','')}",
                                 "Partial eta2": round(_e2,3),
                                 "Cohen's f": round(_f2,3) if not np.isnan(_f2) else "",
                                 "Power": _pwc(_e2,_dfn)})
        if _esr:
            parts.append("\n=== EFFECT SIZE & STATISTICAL POWER ===\n"
                         + pd.DataFrame(_esr).to_csv(index=False))
    except Exception:
        pass

    # Multivariate tests (RM / Mixed / MANCOVA) — dicts → CSV rows
    def _mv_csv(mv, title):
        if not mv:
            return None
        hdr = ["Statistic", "Value", "F", "Hypothesis df", "Error df", "Sig.",
               "Partial eta2", "Noncent. Parameter"]
        rows = []
        for nm, key in [("Pillai's Trace","Pillai"), ("Wilks' Lambda","Wilks"),
                        ("Hotelling-Lawley Trace","Hotelling"),
                        ("Roy's Largest Root","Roy")]:
            sfx = {"Pillai":"Pillai","Wilks":"Wilks",
                   "Hotelling":"HL","Roy":"Roy"}[key]
            rows.append({
                hdr[0]: nm, hdr[1]: mv.get(key,""),
                hdr[2]: mv.get(f"F_{sfx}",""),
                hdr[3]: mv.get(f"df_hyp_{sfx}",""),
                hdr[4]: mv.get(f"df_err_{sfx}",""),
                hdr[5]: mv.get(f"p_{sfx}",""),
                hdr[6]: mv.get(f"eta2_{sfx}",""),
                hdr[7]: mv.get(f"noncent_{sfx}",""),
            })
        return f"\n=== {title} ===\n" + pd.DataFrame(rows).to_csv(index=False)

    for mv_key, mv_title in [
        ("mv_intercept", "MULTIVARIATE TESTS \u2014 INTERCEPT"),
        ("mv_cov",       f"MULTIVARIATE TESTS \u2014 {R.get('cov_name','COVARIATE')}"),
        ("mv_factor",    f"MULTIVARIATE TESTS \u2014 {R.get('factor_name','GROUP')}"),
        ("mv_time",      "MULTIVARIATE TESTS \u2014 TIME"),
        ("mv_tg",        "MULTIVARIATE TESTS \u2014 TIME \u00d7 GROUP"),
        ("mv_tc",        "MULTIVARIATE TESTS \u2014 TIME \u00d7 COVARIATE"),
    ]:
        seg = _mv_csv(R.get(mv_key), mv_title)
        if seg:
            parts.append(seg)

    # Box's M (Mixed / MANCOVA)
    bm = R.get("boxes_m")
    if bm:
        parts.append("\n=== BOX'S TEST OF EQUALITY OF COVARIANCE MATRICES ===\n"
                     + pd.DataFrame([{"Box's M": bm.get("M",""), "F": bm.get("F",""),
                                      "df1": bm.get("df1",""), "df2": bm.get("df2",""),
                                      "Sig.": bm.get("Sig.","")}]).to_csv(index=False))
    clean = [re.sub(r"<[^>]+>", "", ln) for ln in interps]
    parts.append("\n=== INTERPRETATION ===\n"
                 + pd.DataFrame({"Line": range(1, len(clean)+1), "Text": clean})
                 .to_csv(index=False))
    csv_data = "\n".join(parts).encode("utf-8")
    st.download_button(
        "&#128221; CSV Tables",
        csv_data,
        f"ANCOVA_{nm}_{ts}.csv",
        "text/csv", use_container_width=True)
